// test_coupled_normals_modified.cpp
//
// A diagnostic program to exercise the dyadic normal generator.  It uses
// the float‑input overloads of dyadic_lut_avx512_fp32/fp16, which handle
// the necessary sign/magnitude encoding internally.

#include "mlmc_rng.cpp"
#include <algorithm>
#include <vector>
#include <cmath>
#include <cstdio>

#include "dyadic_lut.h"        // LUT coefficients
#include "avx512_lut_dyadic.h" // dyadic_lut_avx512_fp32 / dyadic_lut_avx512_fp16

// Examine differences for very small or very large uniform inputs and
// report any large discrepancies.
void debug_coupling_extremes(int num_samples) {
    printf("Debugging coupling for extreme cases:\n");
    for (int i = 0; i < num_samples; ++i) {
        float u = uni01(rng_eng);
        float z32_single;
        dyadic_lut_avx512_fp32(1, &u, &z32_single);
        // FP16 path
        _Float16 z16_arr[1];
        dyadic_lut_avx512_fp16(1, &u, z16_arr);
        float z16_float = (float)z16_arr[0];
        float diff = z32_single - z16_float;
        if (std::fabs(diff) > 1e-3f || u < 0.001f || u > 0.999f) {
            printf("u=%.10f, z32=%.8f, z16=%.8f, diff=%.8f",
                   u, z32_single, z16_float, diff);
            if (std::fabs(diff) > 1e-3f) printf("  *** LARGE DIFF ***");
            printf("\n");
        }
    }
}

// Analyse the distribution of differences over a large sample.
void analyse_coupling_distribution(int num_samples) {
    std::vector<float> differences;
    std::vector<float> extreme_uniforms;
    differences.reserve(num_samples);
    extreme_uniforms.reserve(num_samples);

    int total_large_diffs = 0;
    double sum_diff = 0.0;
    double sum_diff_sq = 0.0;
    float max_diff = 0.0f;

    for (int i = 0; i < num_samples; ++i) {
        float u = uni01(rng_eng);
        float z32;
        dyadic_lut_avx512_fp32(1, &u, &z32);
        _Float16 z16_arr[1];
        dyadic_lut_avx512_fp16(1, &u, z16_arr);
        float z16_float = (float)z16_arr[0];
        float diff = z32 - z16_float;
        differences.push_back(diff);
        sum_diff += diff;
        sum_diff_sq += diff * diff;
        max_diff = std::max(max_diff, std::fabs(diff));
        if (std::fabs(diff) > 1e-3f) {
            total_large_diffs++;
            extreme_uniforms.push_back(u);
        }
    }

    double mean_diff = sum_diff / num_samples;
    double mean_sq_diff = sum_diff_sq / num_samples;
    double stddev_diff = std::sqrt(mean_sq_diff - mean_diff * mean_diff);

    printf("Coupling analysis (%d samples):\n", num_samples);
    printf("Mean difference:    %.6e\n", mean_diff);
    printf("Max difference:     %.6e\n", max_diff);
    printf("Variance:          %.6e\n", stddev_diff * stddev_diff);
    printf("Large diffs (>1e-3): %d (%.3f%%)\n",
           total_large_diffs, 100.0 * total_large_diffs / num_samples);

    if (!extreme_uniforms.empty()) {
        std::sort(extreme_uniforms.begin(), extreme_uniforms.end());
        printf("Extreme differences occur when u in [%.6f, %.6f]\n",
               extreme_uniforms.front(), extreme_uniforms.back());
        int near_zero = 0, near_one = 0, middle = 0;
        for (float val : extreme_uniforms) {
            if (val < 0.001f) near_zero++;
            else if (val > 0.999f) near_one++;
            else middle++;
        }
        printf("Extreme cases: near_zero=%d, near_one=%d, middle=%d\n",
               near_zero, near_one, middle);
    }

    std::sort(differences.begin(), differences.end(),
              [](float a, float b) { return std::fabs(a) < std::fabs(b); });
    printf("Difference percentiles (absolute):\n");
    printf("50%%: %.3e, 90%%: %.3e, 95%%: %.3e, 99%%: %.3e, 99.9%%: %.3e\n",
           std::fabs(differences[(int)(num_samples * 0.5f)]),
           std::fabs(differences[(int)(num_samples * 0.9f)]),
           std::fabs(differences[(int)(num_samples * 0.95f)]),
           std::fabs(differences[(int)(num_samples * 0.99f)]),
           std::fabs(differences[(int)(num_samples * 0.999f)]));
}

int main() {
    rng_initialisation();
    printf("\n\n");
    debug_coupling_extremes(10000000);    // test extreme cases
    analyse_coupling_distribution(10000000);
    printf("\n\n");
    rng_termination();
    return 0;
}


