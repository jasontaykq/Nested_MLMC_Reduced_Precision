// dyadic_lut_avx512.h

#pragma once

#include <immintrin.h>
#include <algorithm>
#include <cstdint>
#include <cstring>
#include <vector>              

#include "dyadic_lut.h"
#ifndef FP16_EXP_BIAS
#define FP16_EXP_BIAS 15
#endif
#ifndef FP16_M_BITS
#define FP16_M_BITS 10
#endif

#define VECTOR_LENGTH 32u
#define N_MANTISSA_32 23
#define FLOAT32_EXPONENT_BIAS_TABLE_OFFSET 127

constexpr int NUM_BINS = sizeof(DYADIC_U) / sizeof(float) - 1;
constexpr int TABLE_MAX_INDEX = NUM_BINS - 1;

//intialise FP32 LUT storage
alignas(64) static float poly_coef_0[16] = {};
alignas(64) static float poly_coef_1[16] = {};

inline void prepare_polynomial_coefs() {
    for (int i = 0; i < NUM_BINS; ++i) {
        poly_coef_0[i] = DYADIC_LUT_A_FP32[i];
        poly_coef_1[i] = DYADIC_LUT_B_FP32[i];
    }
    float a_last = DYADIC_LUT_A_FP32[NUM_BINS - 1];
    float b_last = DYADIC_LUT_B_FP32[NUM_BINS - 1];
    for (int i = NUM_BINS; i < 16; ++i) {
        poly_coef_0[i] = a_last;
        poly_coef_1[i] = b_last;
    }
}

//initialise FP16 LUT storage
alignas(64) static uint16_t LUT_A_BANK[32] = {};
alignas(64) static uint16_t LUT_B_BANK[32] = {};
static bool lut16_ready = false;

inline void prepare_polynomial_coefs_fp16() {
    if (lut16_ready) return;
    for (int i = 0; i < 32; ++i) {
        uint16_t a = 0, b = 0;
        if (i < NUM_BINS) {
            // reinterpret the FP16 coefficients as 16‑bit integers
            std::memcpy(&a, &DYADIC_LUT_A_FP16[i], sizeof(uint16_t));
            std::memcpy(&b, &DYADIC_LUT_B_FP16[i], sizeof(uint16_t));
        }
        LUT_A_BANK[i] = a;
        LUT_B_BANK[i] = b;
    }
    lut16_ready = true;
}


//Dyadic FP32 generation
inline void dyadic_lut_avx512_fp32(unsigned int n_samples,
                                   const uint16_t *input,
                                   float *output) {

    prepare_polynomial_coefs();
    const unsigned int step = VECTOR_LENGTH;
    const unsigned int n_iterations = n_samples / step;

    // FP32 constants 
    const float fp16_eps       = 6.1035e-5f;   // smallest positive normal FP16 (2^-14)
    const float fp16_half_meps = 0.5f;         // clamp upper at exactly 0.5
    const __m512 eps       = _mm512_set1_ps(fp16_eps);
    const __m512 max_clamp = _mm512_set1_ps(fp16_half_meps);
    const __m512 minus0    = _mm512_set1_ps(-0.0f);
    const __m512i bias     = _mm512_set1_epi32(FLOAT32_EXPONENT_BIAS_TABLE_OFFSET);
    const __m512i tbl_max  = _mm512_set1_epi32(TABLE_MAX_INDEX);
    const __m512i remap_base = _mm512_set1_epi32(TABLE_MAX_INDEX + 2);


    __m512 coef0 = _mm512_load_ps(poly_coef_0);
    __m512 coef1 = _mm512_load_ps(poly_coef_1);

    // Extract sign and magnitude bits
    const __m512i sign_mask16 = _mm512_set1_epi16((int16_t)0x8000);
    const __m512i abs_mask16  = _mm512_set1_epi16((int16_t)0x7FFF);

    for (unsigned int i = 0, off = 0; i < n_iterations; ++i, off += step) {
        // Load 32 uint16_t
        __m512i u16_all = _mm512_loadu_si512((const void *)(input + off));

        // Extract sign bits (MSB) and produce a mask per lane
        __m512i sign_bits = _mm512_and_si512(u16_all, sign_mask16);
        __mmask32 gt_mask_full = _mm512_test_epi16_mask(sign_bits, sign_bits);

        // Mask off the sign bit to obtain the 15‑bit magnitude
        __m512i mag_all = _mm512_and_si512(u16_all, abs_mask16);

        // Split the 32‑lane magnitude vector into two 16‑lane halves for conversion
        __m256i mag_lo_i = _mm512_castsi512_si256(mag_all);
        __m256i mag_hi_i = _mm512_extracti64x4_epi64(mag_all, 1);

        // Bit‑cast the 16‑bit magnitudes to half precision.  Sign bit is zero
        __m256h mag_lo_h = _mm256_castsi256_ph(mag_lo_i);
        __m256h mag_hi_h = _mm256_castsi256_ph(mag_hi_i);

        // Convert half precision to single precision
        __m512 u_ps_lo = _mm512_cvtph_ps(mag_lo_h);
        __m512 u_ps_hi = _mm512_cvtph_ps(mag_hi_h);

        // Extract the two 16‑lane sign masks from the 32‑lane mask
        __mmask16 gt_mask_lo = (uint16_t)(gt_mask_full & 0xFFFF);
        __mmask16 gt_mask_hi = (uint16_t)(gt_mask_full >> 16);

        // Clamping
        u_ps_lo = _mm512_max_ps(u_ps_lo, eps);
        u_ps_lo = _mm512_min_ps(u_ps_lo, max_clamp);
        u_ps_hi = _mm512_max_ps(u_ps_hi, eps);
        u_ps_hi = _mm512_min_ps(u_ps_hi, max_clamp);

        // Compute dyadic interval
        __m512i bits_lo = _mm512_castps_si512(u_ps_lo);
        __m512i bits_hi = _mm512_castps_si512(u_ps_hi);

        // Extract exponent
        bits_lo = _mm512_srli_epi32(bits_lo, N_MANTISSA_32);
        bits_lo = _mm512_and_epi32(bits_lo, _mm512_set1_epi32(0xFF));
        bits_hi = _mm512_srli_epi32(bits_hi, N_MANTISSA_32);
        bits_hi = _mm512_and_epi32(bits_hi, _mm512_set1_epi32(0xFF));

        // j = bias - exponent; idx = remap_base - j; clamp to [0, TABLE_MAX_INDEX]
        __m512i j_lo = _mm512_sub_epi32(bias, bits_lo);
        __m512i j_hi = _mm512_sub_epi32(bias, bits_hi);
        __m512i idx_lo = _mm512_sub_epi32(remap_base, j_lo);
        __m512i idx_hi = _mm512_sub_epi32(remap_base, j_hi);
        idx_lo = _mm512_max_epi32(idx_lo, _mm512_setzero_epi32());
        idx_lo = _mm512_min_epi32(idx_lo, tbl_max);
        idx_hi = _mm512_max_epi32(idx_hi, _mm512_setzero_epi32());
        idx_hi = _mm512_min_epi32(idx_hi, tbl_max);

        // Gather A and B coefficients by index.  
        __m512 c0_lo = _mm512_permutexvar_ps(idx_lo, coef0);
        __m512 c1_lo = _mm512_permutexvar_ps(idx_lo, coef1);
        __m512 c0_hi = _mm512_permutexvar_ps(idx_hi, coef0);
        __m512 c1_hi = _mm512_permutexvar_ps(idx_hi, coef1);

        // z = A + B * u 
        __m512 z_lo = _mm512_fmadd_ps(c1_lo, u_ps_lo, c0_lo);
        __m512 z_hi = _mm512_fmadd_ps(c1_hi, u_ps_hi, c0_hi);

        // Restore sign
        z_lo = _mm512_mask_xor_ps(z_lo, gt_mask_lo, minus0, z_lo);
        z_hi = _mm512_mask_xor_ps(z_hi, gt_mask_hi, minus0, z_hi);

        // Store results
        _mm512_storeu_ps(output + off,       z_lo);
        _mm512_storeu_ps(output + off + 16, z_hi);
    }

    // Scalar tail for remaining samples not divisible by vector length
    for (unsigned int t = n_iterations * step; t < n_samples; ++t) {
        uint16_t bits = input[t];
        bool gt = (bits & 0x8000u) != 0u;
        bits &= 0x7FFFu;

        _Float16 u_half;
        std::memcpy(&u_half, &bits, sizeof(uint16_t));
        float u = static_cast<float>(u_half);

        u = std::max(u, fp16_eps);
        u = std::min(u, fp16_half_meps);

        uint32_t u_bits;
        std::memcpy(&u_bits, &u, sizeof(float));
        u_bits >>= N_MANTISSA_32;
        u_bits &= 0xFFu;
        int j = FLOAT32_EXPONENT_BIAS_TABLE_OFFSET - static_cast<int>(u_bits);
        int idx = (TABLE_MAX_INDEX + 2) - j;
        idx = std::clamp(idx, 0, TABLE_MAX_INDEX);
        float z = poly_coef_0[idx] + poly_coef_1[idx] * u;
        output[t] = gt ? -z : z;
    }
}

// Dyadic FP16 generator
inline void dyadic_lut_avx512_fp16(unsigned int n_samples,
                                   const uint16_t* __restrict input,
                                   _Float16* __restrict output) {
    prepare_polynomial_coefs_fp16();

    const unsigned int step = VECTOR_LENGTH;
    const unsigned int n_iterations  = n_samples / step;

    // Constants for clamping
    const _Float16 fp16_eps       = (_Float16)6.1035e-5f;
    const _Float16 fp16_half_meps = (_Float16)0.5f;
    const __m512h eps_h       = _mm512_set1_ph(fp16_eps);
    const __m512h half_meps_h = _mm512_set1_ph(fp16_half_meps);
    const __m512h mone_h      = _mm512_set1_ph((_Float16)(-1.0f));

    // Constants for index calculation
    const __m512i tbl_max16  = _mm512_set1_epi16((int16_t)TABLE_MAX_INDEX);
    const __m512i idx_base16 = _mm512_set1_epi16((int16_t)(TABLE_MAX_INDEX + 2));
    const __m512i bias16     = _mm512_set1_epi16(FP16_EXP_BIAS);
    const __m512i exp_mask16 = _mm512_set1_epi16((int16_t)0x7C00);
    const __m512i abs_mask16 = _mm512_set1_epi16((int16_t)0x7FFF);
    const __m512i sign_mask16 = _mm512_set1_epi16((int16_t)0x8000);

    const __m512i A_bank = _mm512_load_si512((const __m512i *)LUT_A_BANK);
    const __m512i B_bank = _mm512_load_si512((const __m512i *)LUT_B_BANK);

    for (unsigned int i = 0, off = 0; i < n_iterations; ++i, off += step) {
        // Load 32 input samples
        __m512i u16_i = _mm512_loadu_si512((const void *)(input + off));
        // Extract sign mask
        __mmask32 gt = _mm512_test_epi16_mask(u16_i, sign_mask16);
        // Clear sign bit to obtain magnitude bits
        __m512i mag_i = _mm512_and_si512(u16_i, abs_mask16);
        __m512h u_h   = _mm512_castsi512_ph(mag_i);

        // Clamping
        u_h = _mm512_max_ph(u_h, eps_h);
        u_h = _mm512_min_ph(u_h, half_meps_h);

        // Compute exponent bits
        __m512i u_bits = _mm512_castph_si512(u_h);
        __m512i e      = _mm512_srli_epi16(_mm512_and_si512(u_bits, exp_mask16), FP16_M_BITS);  //and is not necessary? because shift right already removes the mantissa
        __m512i j      = _mm512_sub_epi16(bias16, e);
        __m512i idx    = _mm512_sub_epi16(idx_base16, j);
        idx            = _mm512_max_epi16(idx, _mm512_setzero_si512());
        idx            = _mm512_min_epi16(idx, tbl_max16);

        // Gather A and B coefficients 
        __m512i A_sel = _mm512_maskz_permutexvar_epi16((__mmask32)0xFFFFFFFFu, idx, A_bank);
        __m512i B_sel = _mm512_maskz_permutexvar_epi16((__mmask32)0xFFFFFFFFu, idx, B_bank);
        __m512h A_h   = _mm512_castsi512_ph(A_sel);
        __m512h B_h   = _mm512_castsi512_ph(B_sel);

        // z=A+Bu
        __m512h z_h = _mm512_fmadd_ph(B_h, u_h, A_h);

        // Apply sign: multiply by −1 where sign bit was set
        z_h = _mm512_mask_mul_ph(z_h, gt, z_h, mone_h);

        // Store results
        _mm512_storeu_ph(output + off, z_h);
    }

    // Scalar tail for remaining samples not divisible by vector length
    for (unsigned int t = n_iterations * step; t < n_samples; ++t) {
        uint16_t bits = input[t];
        bool gt = (bits & 0x8000u) != 0u;
        bits &= 0x7FFFu;
        _Float16 u;
        std::memcpy(&u, &bits, sizeof(uint16_t));

        u = std::max(u, (_Float16)fp16_eps);
        u = std::min(u, (_Float16)fp16_half_meps);
        int e   = ((bits & 0x7C00u) >> FP16_M_BITS);
        int j   = FP16_EXP_BIAS - e;
        int idx = (TABLE_MAX_INDEX + 2) - j;
        idx = std::min(std::max(idx, 0), TABLE_MAX_INDEX);
        _Float16 z = DYADIC_LUT_A_FP16[idx] + DYADIC_LUT_B_FP16[idx] * u;
        output[t]  = gt ? (_Float16)(-z) : z;
    }
}





