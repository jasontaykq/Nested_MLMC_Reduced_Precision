// test_coupled_normals.cpp

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <vector>

#include "mlmc_rng.cpp"                   // uni01(rng_eng), rng_initialisation(), rng_termination()
#include "avx512_lut_superdyadic.h"       // new superdyadic kernels (uint16_t input)

// -----------------------------------------------------------------------------
// Helper: pack a Uniform(0,1) into the 16-bit superdyadic input format.
//   bit15: sign (1 if u >= 0.5, else 0)
//   bits[14:0]: half-precision encoding of folded magnitude in (0, 0.5]
static inline uint16_t pack_folded_half_from_uniform(float u) {
    // Sign from upper half
    const bool neg = (u >= 0.5f);

    // Fold to [0, 0.5]; keep 0.5 exact to avoid bin drift
    float mag = neg ? (1.0f - u) : u;

    // Clamp to the domain the kernels assume
    if (mag < FP16_MIN_NORMAL) mag = FP16_MIN_NORMAL;
    if (mag > 0.5f)            mag = 0.5f;

    // Convert to FP16 bits with sign cleared
    _Float16 h = (_Float16)mag;
    uint16_t bits;
    std::memcpy(&bits, &h, sizeof(uint16_t));
    bits &= 0x7FFFu;                    // clear sign

    // Add sign in MSB if needed
    if (neg) bits |= 0x8000u;
    return bits;
}

// -----------------------------------------------------------------------------
// Debugging: print out cases where FP32/FP16 diverge noticeably.
void debug_coupling_extremes(int num_samples) {
    printf("Debugging coupling for extreme cases:\n");

    for (int i = 0; i < num_samples; ++i) {
        float u = uni01(rng_eng);

        uint16_t in = pack_folded_half_from_uniform(u);

        // FP32
        float z32_single;
        superdyadic_lut_avx512_fp32(1, &in, &z32_single);

        // FP16
        _Float16 z16_arr[1];
        superdyadic_lut_avx512_fp16(1, &in, z16_arr);
        float z16_float = (float)z16_arr[0];

        float diff = z32_single - z16_float;

        if (std::fabs(diff) > 1e-3f || u < 0.001f || u > 0.999f) {
            printf("u=%.10f, z32=%.8f, z16=%.8f, diff=%.8f",
                   u, z32_single, z16_float, diff);
            if (std::fabs(diff) > 1e-3f) printf("  *** LARGE DIFF ***");
            printf("\n");
        }
    }
}

// -----------------------------------------------------------------------------
// Analyse distribution of FP32–FP16 differences over a large sample.
void analyse_coupling_distribution(int num_samples) {
    std::vector<float> differences;
    differences.reserve(num_samples);

    std::vector<float> extreme_uniforms;
    extreme_uniforms.reserve(num_samples / 100);

    int total_large_diffs = 0;

    double sum_diff = 0.0;
    double sum_diff_sq = 0.0;
    float  max_diff = 0.0f;

    for (int i = 0; i < num_samples; ++i) {
        float u = uni01(rng_eng);
        uint16_t in = pack_folded_half_from_uniform(u);

        float z32;
        superdyadic_lut_avx512_fp32(1, &in, &z32);

        _Float16 z16_arr[1];
        superdyadic_lut_avx512_fp16(1, &in, z16_arr);
        float z16 = (float)z16_arr[0];

        float diff = z32 - z16;
        differences.push_back(diff);

        sum_diff     += diff;
        sum_diff_sq  += (double)diff * (double)diff;
        max_diff      = std::max(max_diff, std::fabs(diff));

        if (std::fabs(diff) > 1e-3f) {
            total_large_diffs++;
            extreme_uniforms.push_back(u);
        }
    }

    // Stats
    const double mean_diff    = sum_diff / num_samples;
    const double mean_sq_diff = sum_diff_sq / num_samples;
    const double var_diff     = mean_sq_diff - mean_diff * mean_diff;
    const double stddev_diff  = std::sqrt(std::max(0.0, var_diff));

    printf("Coupling analysis (%d samples):\n", num_samples);
    printf("Mean difference:    %.6e\n", mean_diff);
    printf("Max difference:     %.6e\n", (double)max_diff);
    printf("Variance:           %.6e\n", var_diff);
    printf("Large diffs (>1e-3): %d (%.3f%%)\n",
           total_large_diffs, 100.0 * total_large_diffs / num_samples);

    if (!extreme_uniforms.empty()) {
        std::sort(extreme_uniforms.begin(), extreme_uniforms.end());
        printf("Extreme differences occur when u in [%.6f, %.6f]\n",
               extreme_uniforms.front(), extreme_uniforms.back());

        int near_zero = 0, near_one = 0, middle = 0;
        for (float v : extreme_uniforms) {
            if (v < 0.001f)      near_zero++;
            else if (v > 0.999f) near_one++;
            else                 middle++;
        }
        printf("Extreme cases: near_zero=%d, near_one=%d, middle=%d\n",
               near_zero, near_one, middle);
    }

    // Percentiles of |diff|
    std::sort(differences.begin(), differences.end(),
              [](float a, float b) { return std::fabs(a) < std::fabs(b); });

    auto pct = [&](double p) -> float {
        size_t idx = (size_t)std::floor(p * (differences.size() - 1));
        return std::fabs(differences[idx]);
    };

    printf("Difference percentiles (absolute):\n");
    printf("50%%: %.3e, 90%%: %.3e, 95%%: %.3e, 99%%: %.3e, 99.9%%: %.3e\n",
           pct(0.50), pct(0.90), pct(0.95), pct(0.99), pct(0.999));
}

// -----------------------------------------------------------------------------

int main() {
    rng_initialisation();
    printf("\n\n");

    // Explore extremes and distribution using the *packed* input format
    debug_coupling_extremes(10000000);
    analyse_coupling_distribution(10000000);

    printf("\n\n");
    rng_termination();
    return 0;
}


