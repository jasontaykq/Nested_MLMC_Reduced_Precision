// gbm_dyadic.cpp — FP32/FP16 mixed‑precision level estimator using
// piecewise dyadic look‑up table (LUT) Gaussian generators.

#include "mlmc_test.cpp"   // implementation of mlmc_test()
#include "mlmc_rng.cpp"    // random number generator (serial or OpenMP)

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#ifdef _OPENMP
#include <omp.h>
#endif

// forward declaration of level estimator
void gbm_l(int l, int N, double *sums);

// cumulative distribution function for the standard normal
static inline float ncff(float x) {
  return 0.5f + 0.5f * erff(sqrtf(0.5f) * x);
}

int main(int argc, char **argv) {
  int N0   = 200;  // initial samples on each level
  int Lmin = 2;    // minimum refinement level
  int Lmax = 10;   // maximum refinement level

  int N    = 20000;    // samples for convergence tests
  int L    = 8;        // number of levels used in convergence tests
  float Eps[] = {0.005f, 0.01f, 0.02f, 0.05f, 0.1f, 0.0f};

  FILE *fp;

#ifdef _OPENMP
  // measure wall‑clock time in OpenMP builds
  double wtime = omp_get_wtime();
  // each thread must initialise its own RNG state
  #pragma omp parallel
  {
    rng_initialisation();
  }
#else
  // single thread build: initialise RNG once
  rng_initialisation();
#endif

  fp = fopen("gbm.txt", "w");
  if (!fp) {
    perror("fopen");
    exit(EXIT_FAILURE);
  }

  // run multilevel Monte‑Carlo test
  mlmc_test(gbm_l, N, L, N0, Eps, Lmin, Lmax, fp);
  fclose(fp);

#ifdef _OPENMP
  printf(" execution time = %f s\n", omp_get_wtime() - wtime);
#endif

#ifdef _OPENMP
  // free per‑thread RNG state in OpenMP builds
  #pragma omp parallel
  {
    rng_termination();
  }
#else
  rng_termination();
#endif

  // print analytic Black–Scholes call price for S0=K
  float T  = 1.0f, r = 0.05f, sig = 0.2f, sig2 = sig*sig, K = 100.0f;
  float d1 = (r + 0.5f*sig2)*T / (sig*sqrtf(T));
  float d2 = (r - 0.5f*sig2)*T / (sig*sqrtf(T));
  float val = K*( ncff(d1) - expf(-r*T)*ncff(d2) );
  printf("Analytic Black–Scholes call (discounted, S0=K): %.8f\n", val);

  return 0;
}

/*-------------------------------------------------------
%
%%  level‑l estimator (FP32/FP16 mixed precision) Classic nested MLMC with no switching
%
-------------------------------------------------------*/
void gbm_l(int l, int N, double *sums) {
  // zero out the sums array
  for (int k=0; k<7; ++k) sums[k] = 0.0;

  // number of fine and coarse timesteps
  int nf = 1 << (l / 2);
  int nc = nf / 2;
 

  float K   = 100.0f, T = 1.0f, r = 0.05f, sig = 0.2f;
  float hf  = T / (float)nf;
  float hc  = (nc > 0 ? T / (float)nc : 0.0f);
  float disc = expf(-r * T);

  // cast to FP16 once
  const _Float16 r16    = (_Float16)r;
  const _Float16 sig16  = (_Float16)sig;
  const _Float16 hf16   = (_Float16)hf;
  const _Float16 hc16   = (_Float16)hc;
  const _Float16 disc16 = (_Float16)disc;
  const _Float16 K16    = (_Float16)K;

  const float corr_cost_mult = 3.4f;  // cost scaling = (correction FP32 - FP16) / FP16

#ifdef _OPENMP
  // reduction on 7 contiguous array elements when using OpenMP
  #pragma omp parallel for reduction(+:sums[0:7])
#endif
  for (int np=0; np<N; ++np) {
    _Float16 Xf16, Xc16, dWc16, Pf16, Pc16, dP16;
    _Float16 dWf16[2];
    float    Xf32, Xc32, dWc32, Pf32, Pc32, dP32;
    float    dWf32[2];

    // initial values for fine/coarse paths
    Xf16 = K16;
    Xc16 = K16;
    Xf32 = K;
    Xc32 = K;

    if (l == 0) {
      // level 0: fine path only
      dWf16[0] = (_Float16)sqrt(hf) * next_normal_fp16();
      Xf16 = Xf16 + (r16*Xf16*hf16 + sig16*Xf16*dWf16[0]);
      Pf16 = disc16 * (_Float16)fmaxf(0.0f, (float)Xf16 - K);
      dP16 = Pf16;
    }
    else if (l == 1) {
      // level 1: correction between fine and coarse paths
      float    z32;
      _Float16 z16;
      next_coupled_normals(&z32, &z16);
      dWf16[0] = (_Float16)sqrt(hf) * z16;
      Xf16  = Xf16 + (r16*Xf16*hf16 + sig16*Xf16*dWf16[0]);
      dWf32[0] = sqrt(hf) * z32;
      Xf32  = Xf32 + r*Xf32*hf + sig*Xf32*dWf32[0];
      Pf16  = disc16*(_Float16)fmaxf(0.0f, (float)Xf16 - K);
      Pf32  = disc*fmaxf(0.0f, Xf32 - K);
      dP32  = Pf32;
      dP16  = Pf16;
      dP16  = dP32 - (float)dP16;
      Pf16  = dP16;
    }
    else if (l % 2 == 0) {
      // even l>0: pure fine/coarse estimator
      for (int n=0; n<nc; ++n) {
        dWf16[0] = (_Float16)sqrt(hf) * next_normal_fp16();
        Xf16  = Xf16 + r16*Xf16*hf16 + sig16*Xf16*dWf16[0];
        dWf16[1] = (_Float16)sqrt(hf) * next_normal_fp16();
        Xf16  = Xf16 + r16*Xf16*hf16 + sig16*Xf16*dWf16[1];
        dWc16 = dWf16[0] + dWf16[1];
        Xc16  = Xc16 + r16*Xc16*hc16 + sig16*Xc16*dWc16;
      }
      Pf16 = disc16*(_Float16)fmaxf(0.0f, (float)Xf16 - K);
      Pc16 = disc16*(_Float16)fmaxf(0.0f, (float)Xc16 - K);
      dP16 = Pf16 - Pc16;
    }
    else if (l % 2 == 1){
      // odd l>1: correction between fine and coarse
      for (int n=0; n<nc; ++n) {
        float    z32a, z32b;
        _Float16 z16a, z16b;
        next_coupled_normals(&z32a, &z16a);
        next_coupled_normals(&z32b, &z16b);

        dWf16[0] = (_Float16)sqrt(hf) * z16a;
        Xf16  = Xf16 + (r16*Xf16*hf16 + sig16*Xf16*dWf16[0]);
        dWf16[1] = (_Float16)sqrt(hf) * z16b;
        Xf16  = Xf16 + (r16*Xf16*hf16 + sig16*Xf16*dWf16[1]);
        dWc16 = dWf16[0] + dWf16[1];
        Xc16  = Xc16 + (r16*Xc16*hc16 + sig16*Xc16*dWc16);

        dWf32[0] = sqrt(hf) * z32a;
        Xf32  = Xf32 + r*Xf32*hf + sig*Xf32*dWf32[0];
        dWf32[1] = sqrt(hf) * z32b;
        Xf32  = Xf32 + r*Xf32*hf + sig*Xf32*dWf32[1];
        dWc32 = dWf32[0] + dWf32[1];
        Xc32  = Xc32 + r*Xc32*hc + sig*Xc32*dWc32;
      }
      Pf16 = disc16*(_Float16)fmaxf(0.0f,(float)Xf16 - K);
      Pc16 = disc16*(_Float16)fmaxf(0.0f,(float)Xc16 - K);
      dP16 = Pf16 - Pc16;
      Pf32 = disc*fmaxf(0.0f, Xf32 - K);
      Pc32 = disc*fmaxf(0.0f, Xc32 - K);
      dP32 = Pf32 - Pc32;
      Pf16 = Pf32 - (float)Pf16;
      dP16 = dP32 - (float)dP16;
    }
    
    

    // accumulate cost and moments
    if ((l % 2) == 0) {
      sums[0] += nf;
    } else {
      sums[0] += corr_cost_mult * nf;
    }
    double dPd = (double)dP16;
    double Pfd = (double)Pf16;
    sums[1] += dPd;
    sums[2] += dPd * dPd;
    sums[3] += dPd * dPd * dPd;
    sums[4] += dPd * dPd * dPd * dPd;
    sums[5] += Pfd;
    sums[6] += Pfd * Pfd;
  }
}






