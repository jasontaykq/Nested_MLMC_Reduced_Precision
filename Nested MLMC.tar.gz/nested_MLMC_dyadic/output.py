#!/usr/bin/env python3

import numpy as np
import pandas as pd

def parse_gbm_output(filepath):
    # Storage lists for convergence data
    levels = []
    ave_diff = []
    ave_pf = []
    var_diff = []
    var_pf = []
    kurtosis = []
    check = []
    cost = []

    # Storage for complexity sweep
    epsilons = []
    values = []
    mlmc_costs = []
    std_costs = []
    savings = []
    samples_per_eps = []

    with open(filepath, 'r') as f:
        lines = f.readlines()

    # Find convergence test block start
    start_idx = None
    for i, line in enumerate(lines):
        if line.strip().startswith('l   ave(Pf-Pc)'):
            start_idx = i + 2
            break
    if start_idx is None:
        raise ValueError("Could not find convergence test header in file")

    # Parse convergence test data
    for line in lines[start_idx:]:
        if not line.strip():
            break
        parts = line.split()
        if len(parts) < 8:
            break
        levels.append(int(parts[0]))
        ave_diff.append(float(parts[1]))
        ave_pf.append(float(parts[2]))
        var_diff.append(float(parts[3]))
        var_pf.append(float(parts[4]))
        kurtosis.append(float(parts[5]))
        check.append(float(parts[6]))
        cost.append(float(parts[7]))

    # Find complexity test block start
    complexity_idx = None
    for i, line in enumerate(lines):
        if line.strip().startswith('eps'):
            complexity_idx = i + 2  # data starts 2 lines after header
            break
    if complexity_idx is None:
        raise ValueError("Could not find complexity test header in file")

    # Parse complexity test data
    for line in lines[complexity_idx:]:
        if not line.strip():
            break
        parts = line.split()
        if len(parts) < 6:
            break
        epsilons.append(float(parts[0]))
        values.append(float(parts[1]))
        mlmc_costs.append(float(parts[2]))
        std_costs.append(float(parts[3]))
        savings.append(float(parts[4]))
        # Remaining parts are samples per level
        samples = list(map(int, parts[5:]))
        samples_per_eps.append(samples)

    data = {
        'level': np.array(levels),
        'ave_diff': np.array(ave_diff),
        'ave_pf': np.array(ave_pf),
        'var_diff': np.array(var_diff),
        'var_pf': np.array(var_pf),
        'kurtosis': np.array(kurtosis),
        'check': np.array(check),
        'cost': np.array(cost),
        'epsilons': np.array(epsilons),
        'values': np.array(values),
        'mlmc_costs': np.array(mlmc_costs),
        'std_costs': np.array(std_costs),
        'savings': np.array(savings),
        'samples_per_eps': samples_per_eps
    }

    return data

def save_data(data, filename_prefix='mlmc_data'):
    # Save main convergence data
    main_df = pd.DataFrame({
        'level': data['level'],
        'ave_diff': data['ave_diff'],
        'ave_pf': data['ave_pf'],
        'var_diff': data['var_diff'],
        'var_pf': data['var_pf'],
        'kurtosis': data['kurtosis'],
        'check': data['check'],
        'cost': data['cost']
    })
    main_df.to_csv(f'{filename_prefix}_convergence_dyadic.csv', index=False)

    # Save complexity sweep data
    complexity_df = pd.DataFrame({
        'epsilon': data['epsilons'],
        'value': data['values'],
        'mlmc_cost': data['mlmc_costs'],
        'std_cost': data['std_costs'],
        'savings': data['savings']
    })

    # Add samples per level as separate columns
    max_levels = max(len(s) for s in data['samples_per_eps'])
    for i in range(max_levels):
        complexity_df[f'N_level_{i}'] = [s[i] if i < len(s) else np.nan for s in data['samples_per_eps']]

    complexity_df.to_csv(f'{filename_prefix}_complexity_dyadic.csv', index=False)

if __name__ == "__main__":
    # Mixed precision output
    data_mp = parse_gbm_output('gbm.txt')
    save_data(data_mp, filename_prefix='mlmc_data_mp')
    print("Mixed precision data parsed and saved.")

    # Pure FP32 output
    data_fp32 = parse_gbm_output('gbm_fp32.txt')
    save_data(data_fp32, filename_prefix='mlmc_data_fp32')
    print("FP32 data parsed and saved.")


    # Adaptive Mixed Precision Output
    data_fp32 = parse_gbm_output('adaptive_gbm.txt')
    save_data(data_fp32, filename_prefix='mlmc_data_adaptive')
    print("FP32 data parsed and saved.")

    print("Simulation Data saved successfully for Dyadic LUT.")

