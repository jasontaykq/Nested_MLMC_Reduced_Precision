// mlmc_rng.cpp

#include <cstdlib>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <random>
#include <immintrin.h>
#include <algorithm>

#include "dyadic_lut.h"      // LUT coefficients
#include "avx512_lut_dyadic.h"   // dyadic_lut_avx512_fp32 / dyadic_lut_avx512_fp16  

#ifdef _OPENMP
  #include <mkl.h>
  #include <mkl_vsl.h>
  #include <omp.h>
#endif

#ifndef NRV
#define NRV 16384  
#endif

// ======================================================================
// ========================== non-OpenMP Path ================================
// ======================================================================
#ifndef _OPENMP

static std::mt19937 rng_eng(1234);
static std::uniform_real_distribution<float> uni01(0.0f, 1.0f);

static uint16_t *u_buffer    = nullptr;   // uniforms 
static float    *z32_buffer  = nullptr;   // normals FP32
static _Float16 *z16_buffer  = nullptr;   // normals FP16
static int       cache_count = 0;         // track number of samples reamining in current batch

static inline void* aligned_malloc(size_t n, size_t align) { return _mm_malloc(n, (int)align); }
static inline void  aligned_free(void* p) { _mm_free(p); }

void rng_initialisation() {
    rng_eng.seed(1234);

    u_buffer     = (uint16_t*) aligned_malloc(NRV * sizeof(uint16_t), 64);
    z32_buffer   = (float*   ) aligned_malloc(NRV * sizeof(float),    64);
    z16_buffer   = (_Float16*) aligned_malloc(NRV * sizeof(_Float16), 64);

    cache_count = 0;
}

void rng_termination() {
    if (u_buffer)   { aligned_free(u_buffer);   u_buffer = nullptr; }
    if (z32_buffer) { aligned_free(z32_buffer); z32_buffer = nullptr; }
    if (z16_buffer) { aligned_free(z16_buffer); z16_buffer = nullptr; }
    cache_count = 0;
}

static inline void refill_cache() {
    // Generate uniforms
    for (int i = 0; i < NRV; ++i) {
        float u = uni01(rng_eng);          
        bool sign = (u >= 0.5f);
        float mag = sign ? (u - 0.5f) : u; // mirror into [0,0.5)
        _Float16 h = static_cast<_Float16>(mag);
        uint16_t bits;
        std::memcpy(&bits, &h, sizeof(uint16_t));
        u_buffer[i] = (sign ? 0x8000u : 0u) | (bits & 0x7FFFu);
    }

    // LUT Transform (same uniforms to ensure coupling)
    dyadic_lut_avx512_fp32(NRV, u_buffer, z32_buffer);
    dyadic_lut_avx512_fp16(NRV, u_buffer, z16_buffer);

    cache_count = NRV;
}

float next_normal() {
    if (cache_count == 0) refill_cache();
    return z32_buffer[NRV - cache_count--];
}

_Float16 next_normal_fp16() {
    if (cache_count == 0) refill_cache();
    return z16_buffer[NRV - cache_count--];
}

inline void next_coupled_normals(float *z32, _Float16 *z16) {
    if (cache_count == 0) refill_cache();
    int idx = NRV - cache_count--;
    *z32 = z32_buffer[idx];
    *z16 = z16_buffer[idx];
}

// ======================================================================
// ========================= OpenMP / MKL path ==========================
// ======================================================================
#else

// Per-thread state
static VSLStreamStatePtr stream = nullptr;
static uint16_t *u_buffer      = nullptr;   // uniforms
static float    *z32_buffer    = nullptr;   // normals FP32
static _Float16 *z16_buffer    = nullptr;   // normals FP16
static float    *tmp_f         = nullptr;   // scratch buffer for uniform floats
static int       cache_count   = 0;

#pragma omp threadprivate(stream, u_buffer, z32_buffer, z16_buffer, tmp_f, cache_count)

void rng_initialisation() {
    int tid = omp_get_thread_num();

    vslNewStream(&stream, VSL_BRNG_MRG32K3A, 1337);
    long long skip = (static_cast<long long>(tid) + 1) << 48;
    vslSkipAheadStream(stream, skip);

    u_buffer     = (uint16_t*) mkl_malloc(NRV * sizeof(uint16_t), 64);
    z32_buffer   = (float*   ) mkl_malloc(NRV * sizeof(float),    64);
    z16_buffer   = (_Float16*) mkl_malloc(NRV * sizeof(_Float16), 64);
    tmp_f        = (float*   ) mkl_malloc(NRV * sizeof(float),    64);  

    cache_count = 0;
}

void rng_termination() {
    if (stream) { vslDeleteStream(&stream); stream = nullptr; }
    if (u_buffer)   { mkl_free(u_buffer);   u_buffer = nullptr; }
    if (z32_buffer) { mkl_free(z32_buffer); z32_buffer = nullptr; }
    if (z16_buffer) { mkl_free(z16_buffer); z16_buffer = nullptr; }
    if (tmp_f)      { mkl_free(tmp_f);      tmp_f = nullptr; }
    cache_count = 0;
}

static inline void refill_cache() {
    // Generate uniforms
    vsRngUniform(VSL_RNG_METHOD_UNIFORM_STD, stream, NRV, tmp_f, 0.0f, 1.0f);

    for (int i = 0; i < NRV; ++i) {
        float u = tmp_f[i];
        bool sign = (u >= 0.5f);
        float mag = sign ? (u - 0.5f) : u;
        _Float16 h = static_cast<_Float16>(mag);
        uint16_t bits;
        std::memcpy(&bits, &h, sizeof(uint16_t));
        u_buffer[i] = (sign ? 0x8000u : 0u) | (bits & 0x7FFFu);
    }

    // LUT Transform (same uniforms to ensure coupling)
    dyadic_lut_avx512_fp32(NRV, u_buffer, z32_buffer);
    dyadic_lut_avx512_fp16(NRV, u_buffer, z16_buffer);

    cache_count = NRV;
}

float next_normal() {
    if (cache_count == 0) refill_cache();
    return z32_buffer[NRV - cache_count--];
}

_Float16 next_normal_fp16() {
    if (cache_count == 0) refill_cache();
    return z16_buffer[NRV - cache_count--];
}

inline void next_coupled_normals(float *z32, _Float16 *z16) {
    if (cache_count == 0) refill_cache();
    int idx = NRV - cache_count--;
    *z32 = z32_buffer[idx];
    *z16 = z16_buffer[idx];
}

#endif // _OPENMP

