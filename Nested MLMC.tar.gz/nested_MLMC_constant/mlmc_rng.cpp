// mlmc_rng.cpp  (uses LUT-based FP32/FP16 generators)

#include <cstdlib>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <random>
#include <immintrin.h>

#include "fp16x32.h"               // Prof Giles's gather_fp16
#include "constant_lut_512.h"      // LUT coefficients 
#include "avx512_lut_constant.h"   // lut_piecewise_constant_fp32_avx512 / _fp16_avx512   -- vectorised and fully functional

#ifdef _OPENMP
  #include <mkl.h>
  #include <mkl_vsl.h>
  #include <omp.h>
#endif

#ifndef NRV
#define NRV 16384  // batch size per refill
#endif

// ======================================================================
// ========================== Serial path ================================
// ======================================================================
#ifndef _OPENMP

static std::mt19937 rng_eng(1234);
static std::uniform_real_distribution<float> uni01(0.0f, 1.0f);

// Buffers (serial)
static float    *u_buffer    = nullptr;   // uniforms (FP32)
static float    *z32_buffer  = nullptr;   // normals FP32
static _Float16 *z16_buffer  = nullptr;   // normals FP16
static uint32_t *lut_fp16_dup= nullptr;   // duplicated FP16 LUT
static int       cache_count = 0;

// aligned alloc helpers (portable with immintrin)
static inline void* aligned_malloc(size_t n, size_t align) { return _mm_malloc(n, (int)align); }
static inline void  aligned_free(void* p) { _mm_free(p); }

void rng_initialisation() {
    rng_eng.seed(1234);

    u_buffer     = (float*   ) aligned_malloc(NRV * sizeof(float),    64);
    z32_buffer   = (float*   ) aligned_malloc(NRV * sizeof(float),    64);
    z16_buffer   = (_Float16*) aligned_malloc(NRV * sizeof(_Float16), 64);

    lut_fp16_dup = (uint32_t*) aligned_malloc(N_LUT * sizeof(uint32_t), 64);
    build_fp16_duplicated_lut(lut_fp16_dup, GAUSS_LUT, N_LUT);

    cache_count = 0;
}

void rng_termination() {
    if (u_buffer)      { aligned_free(u_buffer);      u_buffer = nullptr; }
    if (z32_buffer)    { aligned_free(z32_buffer);    z32_buffer = nullptr; }
    if (z16_buffer)    { aligned_free(z16_buffer);    z16_buffer = nullptr; }
    if (lut_fp16_dup)  { aligned_free(lut_fp16_dup);  lut_fp16_dup = nullptr; }
    cache_count = 0;
}

static inline void refill_cache() {
    // 1) Make uniforms once
    for (int i = 0; i < NRV; ++i) u_buffer[i] = uni01(rng_eng);
    for (int i = 0; i < NRV; ++i) u_buffer[i] = (_Float16)u_buffer[i];

    // 2) Transform with LUTs (same uniforms, hence, coupled)
    lut_piecewise_constant_fp32_avx512(NRV, u_buffer,  z32_buffer);
    lut_piecewise_constant_fp16_avx512(NRV, u_buffer, z16_buffer, lut_fp16_dup);

    cache_count = NRV;
}

float next_normal() {
    if (cache_count == 0) refill_cache();
    return z32_buffer[NRV - cache_count--];
}

_Float16 next_normal_fp16() {
    if (cache_count == 0) refill_cache();
    return z16_buffer[NRV - cache_count--];
}

inline void next_coupled_normals(float *z32, _Float16 *z16) {
    if (cache_count == 0) refill_cache();
    int idx = NRV - cache_count--;
    *z32 = z32_buffer[idx];
    *z16 = z16_buffer[idx];
}

// ======================================================================
// ========================= OpenMP / MKL path ==========================
// ======================================================================
#else

// Per-thread state
static VSLStreamStatePtr stream = nullptr;
static float    *u_buffer       = nullptr;   // uniforms FP32
static float    *z32_buffer     = nullptr;   // normals FP32
static _Float16 *z16_buffer     = nullptr;   // normals FP16
static uint32_t *lut_fp16_dup   = nullptr;   // duplicated FP16 LUT
static int       cache_count    = 0;

#pragma omp threadprivate(stream, u_buffer, z32_buffer, z16_buffer, lut_fp16_dup, cache_count)

void rng_initialisation() {
    int tid = omp_get_thread_num();

    // One stream per thread: common seed + large skip for independence
    vslNewStream(&stream, VSL_BRNG_MRG32K3A, 1337);
    long long skip = (static_cast<long long>(tid) + 1) << 48;
    vslSkipAheadStream(stream, skip);

    u_buffer     = (float*   ) mkl_malloc(NRV * sizeof(float),    64);
    z32_buffer   = (float*   ) mkl_malloc(NRV * sizeof(float),    64);
    z16_buffer   = (_Float16*) mkl_malloc(NRV * sizeof(_Float16), 64);

    lut_fp16_dup = (uint32_t*) mkl_malloc(N_LUT * sizeof(uint32_t), 64);
    build_fp16_duplicated_lut(lut_fp16_dup, GAUSS_LUT, N_LUT);

    cache_count = 0;
}

void rng_termination() {
    if (stream) { vslDeleteStream(&stream); stream = nullptr; }
    if (u_buffer)     { mkl_free(u_buffer);     u_buffer = nullptr; }
    if (z32_buffer)   { mkl_free(z32_buffer);   z32_buffer = nullptr; }
    if (z16_buffer)   { mkl_free(z16_buffer);   z16_buffer = nullptr; }
    if (lut_fp16_dup) { mkl_free(lut_fp16_dup); lut_fp16_dup = nullptr; }
    cache_count = 0;
}

static inline void refill_cache() {
    // 1) Uniforms in FP32 (fast MKL)
    vsRngUniform(VSL_RNG_METHOD_UNIFORM_STD, stream, NRV, u_buffer, 0.0f, 1.0f);


    // 2) Transform with LUTs (shared uniforms ⇒ perfect coupling)
    lut_piecewise_constant_fp32_avx512(NRV, u_buffer,   z32_buffer);
    lut_piecewise_constant_fp16_avx512(NRV, u_buffer, z16_buffer, lut_fp16_dup);

    cache_count = NRV;
}

float next_normal() {
    if (cache_count == 0) refill_cache();
    return z32_buffer[NRV - cache_count--];
}

_Float16 next_normal_fp16() {
    if (cache_count == 0) refill_cache();
    return z16_buffer[NRV - cache_count--];
}

inline void next_coupled_normals(float *z32, _Float16 *z16) {
    if (cache_count == 0) refill_cache();
    int idx = NRV - cache_count--;
    *z32 = z32_buffer[idx];
    *z16 = z16_buffer[idx];
}

#endif // _OPENMP




