// gbm_constant_fp32.cpp — pure FP32 MLMC (no nesting)
// with piecewise constant look‑up table (LUT) Gaussian generators.

#include "mlmc_test_fp32.cpp"   // implementation of mlmc_test()
#include "mlmc_rng.cpp"    // random number generator (serial or OpenMP)

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#ifdef _OPENMP
#include <omp.h>
#endif

// forward declaration of level estimator
void gbm_l(int l, int N, double *sums);

// cumulative distribution function for the standard normal
static inline float ncff(float x) {
  return 0.5f + 0.5f * erff(sqrtf(0.5f) * x);
}

static inline double per_level_cost(int l){
    if (l == 0) return 2.26;   // FP32 is 2.26x (mean) more expensive than FP16 
    return 3*2.26 * static_cast<double>(1u << (l - 1));    // Correction term (FP32 Fine - Coarse) measured to be 2.29x (mean) more expensive than FP32 Coarse
}


int main(int argc, char **argv) {
  int N0   = 200;  // initial samples on each level
  int Lmin = 2;    // minimum refinement level
  int Lmax = 10;   // maximum refinement level

  int N    = 20000;    // samples for convergence tests
  int L    = 10;        // number of levels used in convergence tests
  float Eps[] = {0.005f, 0.01f, 0.02f, 0.05f, 0.1f, 0.0f};

  FILE *fp;

#ifdef _OPENMP
  // measure wall‑clock time in OpenMP builds
  double wtime = omp_get_wtime();
  // each thread must initialise its own RNG state
  #pragma omp parallel
  {
    rng_initialisation();
  }
#else
  // single thread build: initialise RNG once
  rng_initialisation();
#endif

  fp = fopen("gbm_fp32.txt", "w");
  if (!fp) {
    perror("fopen");
    exit(EXIT_FAILURE);
  }

  // run multilevel Monte‑Carlo test
  mlmc_test(gbm_l, N, L, N0, Eps, Lmin, Lmax, fp);
  fclose(fp);

#ifdef _OPENMP
  printf(" execution time = %f s\n", omp_get_wtime() - wtime);
#endif

#ifdef _OPENMP
  // free per‑thread RNG state in OpenMP builds
  #pragma omp parallel
  {
    rng_termination();
  }
#else
  rng_termination();
#endif

  // print analytic Black–Scholes call price for S0=K
  float T  = 1.0f, r = 0.05f, sig = 0.2f, sig2 = sig*sig, K = 100.0f;
  float d1 = (r + 0.5f*sig2)*T / (sig*sqrtf(T));
  float d2 = (r - 0.5f*sig2)*T / (sig*sqrtf(T));
  float val = K*( ncff(d1) - expf(-r*T)*ncff(d2) );
  printf("Analytic Black–Scholes call (discounted, S0=K): %.8f\n", val);

  return 0;
}

/*-------------------------------------------------------
%
%%  level‑l MLMC estimator (FP32 only)
%
%  Estimates E[P0] when l == 0, and E[Pl − Pl−1] when l > 0,
%  as required for the telescoping identity:contentReference[oaicite:1]{index=1}.
%
%  N   – number of Monte‑Carlo samples
%  sums[0] – accumulated cost
%  sums[1:4] – raw moments of the estimator
%  sums[5:6] – raw moments of the fine‑level payoff  (for diagnostics)
%
-------------------------------------------------------*/
void gbm_l(int l, int N, double *sums) {
    // zero the sums array
    for (int k = 0; k < 7; ++k) sums[k] = 0.0;

    // number of fine and coarse time steps
    int nf = 1 << l;           // 2^l fine steps
    int nc = (l > 0 ? nf / 2 : 0);  // coarse steps (none when l = 0)

    // GBM parameters
    float K   = 100.0f;
    float T   = 1.0f;
    float r   = 0.05f;
    float sig = 0.2f;

    float hf  = T / static_cast<float>(nf);
    float hc  = (l > 0 ? T / static_cast<float>(nc) : 0.0f);
    float disc = std::exp(-r * T);


#ifdef _OPENMP
    #pragma omp parallel for reduction(+:sums[0:7])
#endif
    for (int np = 0; np < N; ++np) {
        float Xf = K;  // fine path
        float Xc = K;  // coarse path
        float Pf = 0.0f;
        float Pc = 0.0f;
        float dP = 0.0f;

        if (l == 0) {
            // base level: simulate only the fine path with nf steps
            for (int n = 0; n < nf; ++n) {
                float dW = std::sqrt(hf) * next_normal();
                Xf += r * Xf * hf + sig * Xf * dW;
            }
            Pf = disc * std::max(0.0f, Xf - K);
            dP = Pf;  // estimator = P0
        } else {
            // levels l > 0: simulate both fine and coarse paths
            for (int n = 0; n < nc; ++n) {
                // two fine increments share the same random normals for coupling
                float z1 = next_normal();
                float z2 = next_normal();

                float dWf1 = std::sqrt(hf) * z1;
                Xf += r * Xf * hf + sig * Xf * dWf1;

                float dWf2 = std::sqrt(hf) * z2;
                Xf += r * Xf * hf + sig * Xf * dWf2;

                // coarse increment is the sum of the two fine increments
                float dWc = dWf1 + dWf2;
                Xc += r * Xc * hc + sig * Xc * dWc;
            }
            Pf = disc * std::max(0.0f, Xf - K);
            Pc = disc * std::max(0.0f, Xc - K);
            dP = Pf - Pc;  // estimator = P_l − P_{l−1}
        }

        sums[0] += per_level_cost(l);       
                 
        double dPd = static_cast<double>(dP);
        double Pfd = static_cast<double>(Pf);
        sums[1] += dPd;
        sums[2] += dPd * dPd;
        sums[3] += dPd * dPd * dPd;
        sums[4] += dPd * dPd * dPd * dPd;
        sums[5] += Pfd;            // for diagnostics: E[Pl]
        sums[6] += Pfd * Pfd;
    }
}





