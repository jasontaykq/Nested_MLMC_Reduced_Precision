// adaptive_gbm.cpp — Nested MLMC with FP16/FP32 mix at low levels,

#include "mlmc_test_adaptive.cpp"   // implementation of mlmc_test()
#include "mlmc_rng.cpp"    // RNG: next_normal(), next_normal_fp16(), next_coupled_normals()

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#ifdef _OPENMP
  #include <omp.h>
#endif

// forward declaration
void gbm_l(int l, int N, double *sums);

// standard normal CDF (float)
static inline float ncff(float x) {
  return 0.5f + 0.5f * erff(sqrtf(0.5f) * x);
}

int main(int argc, char **argv) {
  int N0   = 200;     // initial samples on each level
  int Lmin = 2;       // minimum refinement level
  int Lmax = 10;      // maximum refinement level   - original Lmax = 10   ;16

  int N    = 20000;   // samples for convergence tests
  int L    = 9;       // number of levels used in convergence tests - original L = 8     ; 12
  float Eps[] = {0.005f, 0.01f, 0.02f, 0.05f, 0.1f, 0.0f};

  FILE *fp;

#ifdef _OPENMP
  double wtime = omp_get_wtime();
  #pragma omp parallel
  { rng_initialisation(); }
#else
  rng_initialisation();
#endif

  fp = fopen("adaptive_gbm.txt", "w");
  if (!fp) { perror("fopen"); exit(EXIT_FAILURE); }

  mlmc_test(gbm_l, N, L, N0, Eps, Lmin, Lmax, fp);
  fclose(fp);

#ifdef _OPENMP
  printf(" execution time = %f s\n", omp_get_wtime() - wtime);
#endif

#ifdef _OPENMP
  #pragma omp parallel
  { rng_termination(); }
#else
  rng_termination();
#endif

  // Analytic Black–Scholes call (discounted) for S0=K
  float T  = 1.0f, r = 0.05f, sig = 0.2f, sig2 = sig*sig, K = 100.0f;
  float d1 = (r + 0.5f*sig2)*T / (sig*sqrtf(T));
  float d2 = (r - 0.5f*sig2)*T / (sig*sqrtf(T));
  float val = K*( ncff(d1) - expf(-r*T)*ncff(d2) );
  printf("Analytic Black–Scholes call (discounted, S0=K): %.8f\n", val);

  return 0;
}

/*-------------------------------------------------------
%
%%  level-l estimator (adaptive mixed precision)
%
-------------------------------------------------------*/
void gbm_l(int l, int N, double *sums) {
  // zero out the sums array
  for (int k=0; k<7; ++k) sums[k] = 0.0;

  // number of fine and coarse timesteps
  int nf = 1 << (l / 2);
  int nc = nf / 2;

  // problem parameters
  float K   = 100.0f, T = 1.0f, r = 0.05f, sig = 0.2f;
  float hf  = T / (float)nf;
  float hc  = (nc > 0 ? T / (float)nc : 0.0f);
  float disc = expf(-r * T);

  // cast constants to FP16 once
  const _Float16 r16    = (_Float16)r;
  const _Float16 sig16  = (_Float16)sig;
  const _Float16 hf16   = (_Float16)hf;
  const _Float16 hc16   = (_Float16)hc;
  const _Float16 disc16 = (_Float16)disc;
  const _Float16 K16    = (_Float16)K;

  const float corr_cost_mult = 3.26f;

  static const int PATH_FP32_SWITCH_LEVEL = 10;    //level switch
  
  const bool path_fp32 = (PATH_FP32_SWITCH_LEVEL >= 0 && l >= PATH_FP32_SWITCH_LEVEL);

#ifdef _OPENMP
  #pragma omp parallel for reduction(+:sums[0:7])
#endif
  for (int np=0; np<N; ++np) {
    if (!path_fp32) {
      // Original mixed‑precision implementation
      _Float16 Xf16, Xc16, dWc16, Pf16, Pc16, dP16;
      _Float16 dWf16[2];
      float    Xf32, Xc32, dWc32, Pf32, Pc32, dP32;
      float    dWf32[2];

      // initial values for fine/coarse paths
      Xf16 = K16;
      Xc16 = K16;
      Xf32 = K;
      Xc32 = K;

      if (l == 0) {
        // level 0: fine path only
        dWf16[0] = (_Float16)sqrt(hf) * next_normal_fp16();
        Xf16 = Xf16 + (r16*Xf16*hf16 + sig16*Xf16*dWf16[0]);
        Pf16 = disc16 * (_Float16)fmaxf(0.0f, (float)Xf16 - K);
        dP16 = Pf16;
      }
      else if (l == 1) {
        // level 1: correction between fine and coarse paths
        float    z32;
        _Float16 z16;
        next_coupled_normals(&z32, &z16);
        dWf16[0] = (_Float16)sqrt(hf) * z16;
        Xf16  = Xf16 + (r16*Xf16*hf16 + sig16*Xf16*dWf16[0]);
        dWf32[0] = sqrt(hf) * z32;
        Xf32  = Xf32 + r*Xf32*hf + sig*Xf32*dWf32[0];
        Pf16  = disc16*(_Float16)fmaxf(0.0f, (float)Xf16 - K);
        Pf32  = disc*fmaxf(0.0f, Xf32 - K);
        dP32  = Pf32;
        dP16  = Pf16;
        dP16  = dP32 - (float)dP16;
        Pf16  = dP16;
      }
      else if (l % 2 == 0) {
        // even l>1: pure fine/coarse estimator
        for (int n=0; n<nc; ++n) {
          dWf16[0] = (_Float16)sqrt(hf) * next_normal_fp16();
          Xf16  = Xf16 + r16*Xf16*hf16 + sig16*Xf16*dWf16[0];
          dWf16[1] = (_Float16)sqrt(hf) * next_normal_fp16();
          Xf16  = Xf16 + r16*Xf16*hf16 + sig16*Xf16*dWf16[1];
          dWc16 = dWf16[0] + dWf16[1];
          Xc16  = Xc16 + r16*Xc16*hc16 + sig16*Xc16*dWc16;
        }
        Pf16 = disc16*(_Float16)fmaxf(0.0f, (float)Xf16 - K);
        Pc16 = disc16*(_Float16)fmaxf(0.0f, (float)Xc16 - K);
        dP16 = Pf16 - Pc16;
      }
      else {
        // odd l>1: correction between fine and coarse
        for (int n=0; n<nc; ++n) {
          float    z32a, z32b;
          _Float16 z16a, z16b;
          next_coupled_normals(&z32a, &z16a);
          next_coupled_normals(&z32b, &z16b);

          dWf16[0] = (_Float16)sqrt(hf) * z16a;
          Xf16  = Xf16 + (r16*Xf16*hf16 + sig16*Xf16*dWf16[0]);
          dWf16[1] = (_Float16)sqrt(hf) * z16b;
          Xf16  = Xf16 + (r16*Xf16*hf16 + sig16*Xf16*dWf16[1]);
          dWc16 = dWf16[0] + dWf16[1];
          Xc16  = Xc16 + (r16*Xc16*hc16 + sig16*Xc16*dWc16);

          dWf32[0] = sqrt(hf) * z32a;
          Xf32  = Xf32 + r*Xf32*hf + sig*Xf32*dWf32[0];
          dWf32[1] = sqrt(hf) * z32b;
          Xf32  = Xf32 + r*Xf32*hf + sig*Xf32*dWf32[1];
          dWc32 = dWf32[0] + dWf32[1];
          Xc32  = Xc32 + r*Xc32*hc + sig*Xc32*dWc32;
        }
        Pf16 = disc16*(_Float16)fmaxf(0.0f,(float)Xf16 - K);
        Pc16 = disc16*(_Float16)fmaxf(0.0f,(float)Xc16 - K);
        dP16 = Pf16 - Pc16;
        Pf32 = disc*fmaxf(0.0f, Xf32 - K);
        Pc32 = disc*fmaxf(0.0f, Xc32 - K);
        dP32 = Pf32 - Pc32;
        Pf16 = Pf32 - (float)Pf16;
        dP16 = dP32 - (float)dP16;
      }

      // accumulate cost and moments
      if ((l % 2) == 0) {
        sums[0] += nf;
      } else {
        sums[0] += corr_cost_mult * nf;
      }
      double dPd = (double)dP16;
      double Pfd = (double)Pf16;
      sums[1] += dPd;
      sums[2] += dPd * dPd;
      sums[3] += dPd * dPd * dPd;
      sums[4] += dPd * dPd * dPd * dPd;
      sums[5] += Pfd;
      sums[6] += Pfd * Pfd;
    } else {
      // -----------------------------------------------------------------
      // switch to single-precision only (standard FP32 MLMC with no mixed-precision)

    float Xf32 = K, Xc32 = K;
    float Pf32, Pc32, dP32;

    for (int n = 0; n < nc; ++n) {
        float z1  = next_normal();
        float z2  = next_normal();

        float dW1 = sqrtf(hf) * z1;
        Xf32 += r*Xf32*hf + sig*Xf32*dW1;
        
        float dW2 = sqrtf(hf) * z2;
        Xf32 +=  r*Xf32*hf + sig*Xf32*dW2;

        float dWc = dW1 + dW2;
        Xc32 +=  r*Xc32*hc + sig*Xc32*dWc;
    }

    Pf32 = disc * fmaxf(0.0f, Xf32 - K);
    Pc32 = disc * fmaxf(0.0f, Xc32 - K);
    dP32 = Pf32 - Pc32;
    

{
    const int Ls = PATH_FP32_SWITCH_LEVEL;     // e.g., 10
    const int delta = l - Ls;                  // 0 at switch level, 1 next level, etc.


    const int nf_Ls_m2 = 1 << ((Ls - 2) / 2);
    const double cost_Ls_m2 = (((Ls - 2) & 1) == 0)
                              ? (double)nf_Ls_m2
                              : (double)corr_cost_mult * (double)nf_Ls_m2;

    const double cost_Ls = (2.0 * 2.0 * 1.13) * cost_Ls_m2;

    const double cost_now = cost_Ls * (double)(1ULL << delta);

    sums[0] += cost_now;
}
    double dPd = (double)dP32;
    double Pfd = (double)Pf32;
    sums[1] += dPd;
    sums[2] += dPd*dPd;
    sums[3] += dPd*dPd*dPd;
    sums[4] += dPd*dPd*dPd*dPd;
    sums[5] += Pfd;
    sums[6] += Pfd*Pfd;
}
}}

