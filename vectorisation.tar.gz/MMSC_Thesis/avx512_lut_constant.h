//avx512_lut_constant.h

#ifndef AVX512_LUT_H_
#define AVX512_LUT_H_

#include <immintrin.h>
#include <cmath>
#include <cstring>
#include "constant_lut_512.h" //LUT coefficient arrays in FP32 and FP16 
#include "fp16x32.h"  // Header file consisting of gather_fp16 functions

#ifndef N_LUT
#define N_LUT 512u
#endif

// FP32 piecewise-constant LUT (vectorised) 
static inline void lut_piecewise_constant_fp32_avx512(unsigned int n_samples,
                                        const float *input,
                                        float       *output)
{
    const unsigned int VECTOR_LENGTH = 16u;
    unsigned int n_iterations = n_samples / VECTOR_LENGTH;
    
    __m512     lut_scale      = _mm512_set1_ps(static_cast<float>(N_LUT) / 0.5f);
    __m512     lut_half       = _mm512_set1_ps(0.5f);
    __m512i    lut_max        = _mm512_set1_epi32(N_LUT - 1);

    for (unsigned int i = 0, offset = 0;
         i < n_iterations;
         ++i, offset += VECTOR_LENGTH)
    {
        __m512  u           = _mm512_loadu_ps(input + offset);
        __mmask16 mask_lower = _mm512_cmp_ps_mask(u, lut_half, _CMP_LT_OS);

        // lower-half indices
        __m512  idx_f_lower = _mm512_mul_ps(u, lut_scale);
        __m512i idx_lower   = _mm512_cvttps_epi32(idx_f_lower);
                 idx_lower   = _mm512_min_epi32(idx_lower, lut_max);

        // upper-half indices
        __m512  one          = _mm512_set1_ps(1.0f);
        __m512  u_mirrored   = _mm512_sub_ps(one, u);
        __m512  idx_f_upper  = _mm512_mul_ps(u_mirrored, lut_scale);
        __m512i idx_upper    = _mm512_cvttps_epi32(idx_f_upper);
                 idx_upper    = _mm512_min_epi32(idx_upper, lut_max);

        // gather & blend
        __m512 z_lower = _mm512_i32gather_ps(idx_lower, GAUSS_LUT, sizeof(float));
        __m512 z_upper = _mm512_i32gather_ps(idx_upper, GAUSS_LUT, sizeof(float));
                z_upper = _mm512_sub_ps(_mm512_setzero_ps(), z_upper);

        __m512 gauss = _mm512_mask_blend_ps(mask_lower, z_upper, z_lower);
        _mm512_storeu_ps(output + offset, gauss);
    }

    // tail handling
    for (unsigned int i = n_iterations * VECTOR_LENGTH;
         i < n_samples;
         ++i)
    {
        float u = input[i];
        // clamp to avoid hitting exactly 0 or 1
        if (u < 1e-7f)        u = 1e-7f;
        if (u > 1.0f - 1e-7f) u = 1.0f - 1e-7f;

        int   idx;
        float z;
        if (u < 0.5f) {
            idx = static_cast<int>(u * N_LUT / 0.5f);
            if (idx >= static_cast<int>(N_LUT)) idx = N_LUT - 1;
            z = GAUSS_LUT[idx];
        } else {
            idx = static_cast<int>((1.0f - u) * N_LUT / 0.5f);
            if (idx >= static_cast<int>(N_LUT)) idx = N_LUT - 1;
            z = -GAUSS_LUT[idx];
        }

        output[i] = z;
    }
}


//Build duplicated FP16 LUT
static inline void build_fp16_duplicated_lut(uint32_t* out_dup, const float* src_float, size_t n) {
    for (size_t i = 0; i < n; ++i) {
        _Float16 h = static_cast<_Float16>(src_float[i]);
        uint16_t bits;
        memcpy(&bits, &h, sizeof(bits));  // Now works with <cstring>
        out_dup[i] = (static_cast<uint32_t>(bits) << 16) | bits;
    }
}

//Split fp16x32 into two __m512 FP32 vectors
static inline void fp16x32_to_two_m512(const fp16x32& x, __m512& lo, __m512& hi) {
    alignas(64) _Float16 tmp[32];
    _mm512_storeu_ph(tmp, x.data);
    lo = _mm512_cvtph_ps(_mm256_loadu_ph(tmp));
    hi = _mm512_cvtph_ps(_mm256_loadu_ph(tmp + 16));
}

// FP16 piecewise-constant LUT (vectorised) 
static inline void lut_piecewise_constant_fp16_avx512(
    unsigned int n_samples,
    const float * __restrict__ u_fp32,          // NOTE: FP32 uniforms
    _Float16   * __restrict__ output,
    const uint32_t * __restrict__ GAUSS_LUT_FP16_DUP)  // duplicated FP16 LUT (positive branch)
{
    const unsigned int VECTOR_LENGTH = 32u;               // 32 halfs per iteration
    const unsigned int n_iters = n_samples / VECTOR_LENGTH;

    const __m512  vscale    = _mm512_set1_ps(static_cast<float>(N_LUT) * 2.0f); // = N_LUT/0.5
    const __m512  vhalf     = _mm512_set1_ps(0.5f);
    const __m512  vone      = _mm512_set1_ps(1.0f);
    const __m512i vmax_idx  = _mm512_set1_epi32((int)N_LUT - 1);
    const __m512  vzero     = _mm512_setzero_ps();
    const __m512  vnegzero  = _mm512_set1_ps(-0.0f); // for sign-flip via XOR if desired

    for (unsigned int it = 0; it < n_iters; ++it) {
        const float   *in_ptr  = u_fp32 + it * VECTOR_LENGTH;
        _Float16      *out_ptr = output + it * VECTOR_LENGTH;

        // Load 32 FP32 uniforms as two 16-wide vectors
        __m512 u_lo = _mm512_loadu_ps(in_ptr);           // first 16
        __m512 u_hi = _mm512_loadu_ps(in_ptr + 16);      // second 16

        // Masks for u < 0.5
        __mmask16 m_lo = _mm512_cmp_ps_mask(u_lo, vhalf, _CMP_LT_OS);
        __mmask16 m_hi = _mm512_cmp_ps_mask(u_hi, vhalf, _CMP_LT_OS);

        // Mirror to [0,0.5]: t = (u < 0.5 ? u : 1-u)
        __m512 t_lo = _mm512_mask_blend_ps(m_lo, _mm512_sub_ps(vone, u_lo), u_lo);
        __m512 t_hi = _mm512_mask_blend_ps(m_hi, _mm512_sub_ps(vone, u_hi), u_hi);

        // Index = floor(t * 2*N_LUT); clamp to [0, N_LUT-1]
        __m512i idx_lo = _mm512_cvttps_epi32(_mm512_mul_ps(t_lo, vscale));
        __m512i idx_hi = _mm512_cvttps_epi32(_mm512_mul_ps(t_hi, vscale));
        idx_lo = _mm512_min_epi32(idx_lo, vmax_idx);
        idx_hi = _mm512_min_epi32(idx_hi, vmax_idx);
        // (no lower clamp needed; t>=0)

        // Convert epi32 -> epi16
        __m256i idx_lo_256 = _mm512_cvtepi32_epi16(idx_lo);
        __m256i idx_hi_256 = _mm512_cvtepi32_epi16(idx_hi);
        __m512i indices16  = _mm512_inserti64x4(_mm512_castsi256_si512(idx_lo_256), idx_hi_256, 1);

        // Gather positive-branch FP16 LUT values → fp16x32 → two __m512
        fp16x32 z_fp16x32 = gather_fp16(reinterpret_cast<const _Float16*>(GAUSS_LUT_FP16_DUP), indices16);
        __m512 z_lo, z_hi;
        fp16x32_to_two_m512(z_fp16x32, z_lo, z_hi);

        // Apply sign: if (u >= 0.5) negate. Use blend to match FP32 kernel.
        __m512 z_signed_lo = _mm512_mask_blend_ps(m_lo, _mm512_sub_ps(vzero, z_lo), z_lo);
        __m512 z_signed_hi = _mm512_mask_blend_ps(m_hi, _mm512_sub_ps(vzero, z_hi), z_hi);

        // Pack to FP16 and store
        __m256h z_h_lo = _mm512_cvtps_ph(z_signed_lo, _MM_FROUND_TO_NEAREST_INT | _MM_FROUND_NO_EXC);
        __m256h z_h_hi = _mm512_cvtps_ph(z_signed_hi, _MM_FROUND_TO_NEAREST_INT | _MM_FROUND_NO_EXC);
        _mm512_storeu_ph(out_ptr,      _mm512_castph256_ph512(z_h_lo));
        _mm512_storeu_ph(out_ptr + 16, _mm512_castph256_ph512(z_h_hi));
    }

    // Scalar tail (FP32 u → FP16 value, same binning & sign as FP32 kernel)
    for (unsigned int i = n_iters * VECTOR_LENGTH; i < n_samples; ++i) {
        float u = u_fp32[i];
        int idx;
        float zpos;
        if (u < 0.5f) {
            idx = (int)(u * (float)(2 * N_LUT));
            if (idx > (int)N_LUT - 1) idx = (int)N_LUT - 1;
            zpos = (float)GAUSS_LUT_FP16[idx];
        } else {
            idx = (int)((1.0f - u) * (float)(2 * N_LUT));
            if (idx > (int)N_LUT - 1) idx = (int)N_LUT - 1;
            zpos = - (float)GAUSS_LUT_FP16[idx];
        }
        output[i] = (_Float16)zpos;
    }
}

#endif

