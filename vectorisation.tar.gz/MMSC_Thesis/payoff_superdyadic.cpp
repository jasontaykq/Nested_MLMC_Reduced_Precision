// payoff_superdyadic.cpp

#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <ctime>
#include <algorithm>
#include <immintrin.h>
#include <mkl.h>
#include "superdyadic_lut_52.h"
#include "avx512_lut_superdyadic.h"

#define N_EM_SAMPLES 10000000u  // Monte Carlo samples
#define M             1      // Time steps


// Vector widths
static const unsigned int V_F32 = 16u;  // 16 floats in 512 bits
static const unsigned int V_F16 = 32u;  // 32 half-floats in 512 bits

// Timing helper
static inline double get_time() {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + ts.tv_nsec * 1e-9;
}

// FP32 AVX-512 kernel
void compute_fp32_payoffs(
    const float* all_z,
    float* out_payoffs,
    unsigned int N_samples,
    float S0,
    float K,
    float r,
    float sigma,
    float sqrt_h,
    float discount_factor)
{
    __m512 r_h          = _mm512_set1_ps(r * (sqrt_h*sqrt_h));
    __m512 sigma_sqrt_h = _mm512_set1_ps(sigma * sqrt_h);
    __m512 one_v        = _mm512_set1_ps(1.0f);
    __m512 K_v          = _mm512_set1_ps(K);
    __m512 disc_v       = _mm512_set1_ps(discount_factor);

    unsigned int i = 0;
    for (; i + V_F32 <= N_samples; i += V_F32) {
        __m512 S = _mm512_set1_ps(S0);
        for (int step = 0; step < M; ++step) {
            const float* z_ptr = all_z + step * N_samples + i;
            __m512 z = _mm512_loadu_ps(z_ptr);
            __m512 tmp = _mm512_fmadd_ps(sigma_sqrt_h, z, r_h);
            tmp = _mm512_add_ps(tmp, one_v);
            S = _mm512_mul_ps(S, tmp);
        }
        __m512 diff = _mm512_sub_ps(S, K_v);
        __mmask16 m  = _mm512_cmp_ps_mask(diff, _mm512_setzero_ps(), _CMP_GT_OS);
        __m512 payoff = _mm512_mask_mul_ps(_mm512_setzero_ps(), m, diff, disc_v);
        _mm512_storeu_ps(out_payoffs + i, payoff);
    }
    for (; i < N_samples; ++i) {
        float S = S0;
        for (int step = 0; step < M; ++step) {
            float z = all_z[step * N_samples + i];
            S *= (1.0f + r * (sqrt_h*sqrt_h) + sigma * sqrt_h * z);
        }
        out_payoffs[i] = fmaxf(S - K, 0.0f) * discount_factor;
    }
}




// FP16 AVX-512 kernel
void compute_fp16_payoffs(
    const _Float16* all_z,
    _Float16* out_payoffs,
    unsigned int N_samples,
    _Float16 S0,
    _Float16 K,
    _Float16 r,
    _Float16 sigma,
    _Float16 sqrt_h,
    _Float16 discount_factor)
{
    __m512 S0_v       = _mm512_set1_ps((float)S0);
    __m512 K_v        = _mm512_set1_ps((float)K);
    __m512 r_h_v      = _mm512_set1_ps((float)(r * (_Float16)(sqrt_h*sqrt_h)));
    __m512 sigma_sqrt = _mm512_set1_ps((float)(sigma * sqrt_h));
    __m512 one_v      = _mm512_set1_ps(1.0f);
    __m512 disc_v     = _mm512_set1_ps((float)discount_factor);

    unsigned int i = 0;
    for (; i + V_F16 <= N_samples; i += V_F16) {
        __m512 S0_chunk = S0_v;
        __m512 S1_chunk = S0_v;
        for (int step = 0; step < M; ++step) {
            const _Float16* base = all_z + step * N_samples + i;
            __m256i half0 = _mm256_loadu_si256((const __m256i*)base);
            __m512 z0 = _mm512_cvtph_ps(half0);
            __m512 tmp0 = _mm512_fmadd_ps(sigma_sqrt, z0, r_h_v);
            tmp0 = _mm512_add_ps(tmp0, one_v);
            S0_chunk = _mm512_mul_ps(S0_chunk, tmp0);
            __m256i half1 = _mm256_loadu_si256((const __m256i*)(base + 16));
            __m512 z1 = _mm512_cvtph_ps(half1);
            __m512 tmp1 = _mm512_fmadd_ps(sigma_sqrt, z1, r_h_v);
            tmp1 = _mm512_add_ps(tmp1, one_v);
            S1_chunk = _mm512_mul_ps(S1_chunk, tmp1);
        }
        __m512 diff0 = _mm512_sub_ps(S0_chunk, K_v);
        __m512 diff1 = _mm512_sub_ps(S1_chunk, K_v);
        __mmask16 m0 = _mm512_cmp_ps_mask(diff0, _mm512_setzero_ps(), _CMP_GT_OS);
        __mmask16 m1 = _mm512_cmp_ps_mask(diff1, _mm512_setzero_ps(), _CMP_GT_OS);
        __m512 payoff0 = _mm512_mask_mul_ps(_mm512_setzero_ps(), m0, diff0, disc_v);
        __m512 payoff1 = _mm512_mask_mul_ps(_mm512_setzero_ps(), m1, diff1, disc_v);
        __m256i ph0 = _mm512_cvtps_ph(payoff0, _MM_FROUND_TO_NEAREST_INT | _MM_FROUND_NO_EXC);
        __m256i ph1 = _mm512_cvtps_ph(payoff1, _MM_FROUND_TO_NEAREST_INT | _MM_FROUND_NO_EXC);
        _mm256_storeu_si256((__m256i*)(out_payoffs + i), ph0);
        _mm256_storeu_si256((__m256i*)(out_payoffs + i + 16), ph1);
    }
    for (; i < N_samples; ++i) {
        _Float16 S = S0;
        for (int step = 0; step < M; ++step) {
            _Float16 z = all_z[step * N_samples + i];
            S = S * ((_Float16)(1.0) + r * (_Float16)(sqrt_h*sqrt_h) + sigma * sqrt_h * z);
        }
        _Float16 diff = S - K;
        out_payoffs[i] = (diff > 0) ? diff * discount_factor : (_Float16)0;
    }
}


// for Black-Scholes comparison
double norm_cdf(double x) {
    return 0.5 * erfc(-x * M_SQRT1_2); // M_SQRT1_2 = 1/sqrt(2)
}

double BSCallPrice(double S0, double K, double r, double sigma, double T) {
    double d1 = (log(S0 / K) + (r + 0.5 * sigma * sigma) * T) / (sigma * sqrt(T));
    double d2 = d1 - sigma * sqrt(T);
    return S0 * norm_cdf(d1) - K * exp(-r * T) * norm_cdf(d2);
}


int main() {
    // Parameters
    const unsigned int N = M * N_EM_SAMPLES;   // total uniforms / normals
    const float T = 1.0f;
    const float h = T / M;
    const float sqrt_h = std::sqrt(h);
    const float r = 0.05f;
    const float sigma = 0.2f;
    const float S0_f32 = 100.0f;
    const float K_f32  =  100.0f;

    // FP16 constants
    const _Float16 r_f16 = (_Float16)r;
    const _Float16 sigma_f16 = (_Float16)sigma;
    const _Float16 sqrt_h_f16 = (_Float16)sqrt_h;
    const _Float16 S0_f16 = (_Float16)S0_f32;
    const _Float16 K_f16  = (_Float16)K_f32;

    // Discount factors
    float discount_f32 = std::exp(-r * T);
    _Float16 discount_f16 = (_Float16)discount_f32;

    // Allocate and generate Gaussians
    uint16_t*  all_u     = (uint16_t*) mkl_malloc(N * sizeof(uint16_t), 64);          // uint16_t inputs to LUTs


    float*  all_z_f32  = (float*) mkl_malloc(M * N_EM_SAMPLES * sizeof(float), 64);
    _Float16* all_z_f16 = (_Float16*) mkl_malloc(M * N_EM_SAMPLES * sizeof(_Float16), 64);
    // Allocate payoff arrays
    float* payoff_f32 = (float*) mkl_malloc(N_EM_SAMPLES * sizeof(float), 64);
    _Float16* payoff_f16 = (_Float16*) mkl_malloc(N_EM_SAMPLES * sizeof(_Float16), 64);

    
            
    if (!all_u || !all_z_f32 || !all_z_f16) {
        fprintf(stderr, "Allocation failed\n");
        return 1;
    }

    // RNG stream
    VSLStreamStatePtr stream;
    vslNewStream(&stream, VSL_BRNG_MT19937, 123456789);

    // generate uniform ints in [0,65536) and encode them
    int* tmp_i = (int*)mkl_malloc(N * sizeof(int), 64);
    viRngUniform(VSL_RNG_METHOD_UNIFORM_STD, stream, (int)N, tmp_i, 0, 65536);

    // encode each value: MSB = sign, low bits = FP16 magnitude in [0,0.5)
    const float inv_65536 = 1.0f / 65536.0f;
    for (unsigned int i = 0; i < N; ++i) {
        float u    = (float)tmp_i[i] * inv_65536;   // [0,1)
        bool sign  = u >= 0.5f;
        float mag  = sign ? (u - 0.5f) : u;
        _Float16 h = static_cast<_Float16>(mag);
        uint16_t bits;
        std::memcpy(&bits, &h, sizeof(uint16_t));
        all_u[i] = (sign ? 0x8000u : 0u) | (bits & 0x7FFFu);
    }
    mkl_free(tmp_i);
    


    double t_lut32_start = get_time();
    superdyadic_lut_avx512_fp32(M* N_EM_SAMPLES, all_u, all_z_f32);
    double t_lut32_end = get_time();
    double total_time_lut32 = 1e3 * (t_lut32_end - t_lut32_start);

    double t_lut16_start = get_time();
    superdyadic_lut_avx512_fp16(M * N_EM_SAMPLES, all_u, all_z_f16);
    double t_lut16_end = get_time();
    double total_time_lut16 = 1e3 * (t_lut16_end - t_lut16_start);
    
    // Time vector 
    double t0 = get_time();
    compute_fp32_payoffs(all_z_f32, payoff_f32,
                         N_EM_SAMPLES, S0_f32, K_f32,
                         r, sigma, sqrt_h, discount_f32);
    double t1 = get_time();
    compute_fp16_payoffs(all_z_f16, payoff_f16,
                         N_EM_SAMPLES, S0_f16, K_f16,
                         r_f16, sigma_f16, sqrt_h_f16, discount_f16);
    double t2 = get_time();
    
    double time_fp32_path=(t1 - t0) * 1e3;
    double time_fp16_path=(t2 - t1) * 1e3;
    
    printf("Inputs: Samples=%u, Steps=%d (h=%.6f), S0=%.1f, K=%.1f, r=%.1f, sigma=%.1f, T=%.1f\n\n",
       N_EM_SAMPLES, M, h, S0_f32, K_f32, r, sigma, T);
       
    
    printf("===Linear-Superdyadic Generation===\n");
    printf("Avg. time per sample (FP32 Gaussian gen): %.7f ns\n", (total_time_lut32)/ N_EM_SAMPLES*1e6); //+time_u16_ms
    printf("Avg. time per sample (FP16 Gaussian gen): %.7f ns\n\n", (total_time_lut16 )/ N_EM_SAMPLES*1e6); //+time_u16_ms


    // Accumulate stats
    double sum32 = 0, sum32_sq = 0;
    double sum16 = 0, sum16_sq = 0;
    double sumY = 0, sumY_sq = 0;

    double t_corr_start = get_time();
    for (unsigned int i = 0; i < N_EM_SAMPLES; ++i) {
        float c32 = payoff_f32[i];
        float c16 = (float)payoff_f16[i];
        float Y = c32 - c16; 
    }
    double t_corr_end = get_time();
    double total_corr_time = 1e3 * (t_corr_end - t_corr_start);

    for (unsigned int i = 0; i < N_EM_SAMPLES; ++i) {
        float c32 = payoff_f32[i];
        float c16 = (float)payoff_f16[i];
        float Y   = c32 - c16;
        sumY     += Y;
        sum32    += c32;
        sum32_sq += c32 * c32;
        sum16    += c16;
        sum16_sq += c16 * c16;
        sumY_sq  += Y * Y;
    }

    printf("===Random Paths Calculation===\n");
    printf("Avg. time per sample (FP32 path, excl. gen): %.7f ns\n", (time_fp32_path/ N_EM_SAMPLES)*1e6);
    printf("Avg. time per sample (FP16 path, excl. gen): %.7f ns\n", (time_fp16_path/ N_EM_SAMPLES)*1e6);
    printf("Avg. time per sample (FP32-FP16 correction, excl. gen): %.7f ns\n\n", ((time_fp32_path+time_fp16_path+total_corr_time)/N_EM_SAMPLES)*1e6);
    

    auto print_stats = [&](const char* label,
                            double s, double ss){
        double m = s / N_EM_SAMPLES;
        double v = ss / N_EM_SAMPLES - m*m;
        if (v < 0) v = 0;
        printf("[%s] mean=%.6f var=%.6f stddev=%.6f\n",
               label, m, v, std::sqrt(v));
    };

    printf("===Statistical Result===\n");
    print_stats("FP32 path", sum32, sum32_sq);
    print_stats("FP16 path", sum16, sum16_sq);
    print_stats("FP32-FP16 Correction",  sumY,  sumY_sq);

    printf("\nBlack-Scholes Call Price (Discounted): %.6f\n\n",
           BSCallPrice(S0_f32, K_f32, r, sigma, T));


    // Cleanup
    
    mkl_free(all_u);  
    mkl_free(all_z_f32);  
    mkl_free(all_z_f16);
    mkl_free(payoff_f32);
    mkl_free(payoff_f16);

}
