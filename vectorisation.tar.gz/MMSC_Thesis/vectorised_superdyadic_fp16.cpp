// vectorised_superdyadic_fp16.cpp

#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <ctime>
#include <immintrin.h>
#include <mkl.h>
#include <algorithm>
#include "superdyadic_lut_52.h" // must define SUPERDYADIC_LUT_A_FP16, SUPERDYADIC_LUT_B_FP16, SUPERDYADIC_U

#define VECTOR_LENGTH_16   32u
#define N_SAMPLES       10000000u

// derive counts from LUT:
constexpr int NUM_BREAKS = sizeof(SUPERDYADIC_U) / sizeof(float);
constexpr int NUM_BINS   = NUM_BREAKS - 1;

// global pre-converted coefficient registers (27 entries = 16 + 11)
static __m512 lutA_0_fp32;
static __m512 lutA_1_fp32;
static __m512 lutB_0_fp32;
static __m512 lutB_1_fp32;
static bool lut_prepared = false;

void prepare_superdyadic_coefs_fp16()
{
    if (lut_prepared) return;

    // Load first 16 FP16 entries of A, convert to FP32
    __m256i a_block0 = _mm256_load_si256((__m256i const*)(SUPERDYADIC_LUT_A_FP16));       // 16 * _Float16 = 32 bytes
    lutA_0_fp32 = _mm512_cvtph_ps(a_block0); // expands to 16 floats

    // Load next (remaining) entries: since total is 27 (or 26 depending), we load 16 starting at offset 16.
    __m256i a_block1 = _mm256_loadu_si256((__m256i const*)(SUPERDYADIC_LUT_A_FP16 + 16)); // may read past real data; safe if constexpr array is tightly laid out
    lutA_1_fp32 = _mm512_cvtph_ps(a_block1);

    // Same for B
    __m256i b_block0 = _mm256_load_si256((__m256i const*)(SUPERDYADIC_LUT_B_FP16));
    lutB_0_fp32 = _mm512_cvtph_ps(b_block0);
    __m256i b_block1 = _mm256_loadu_si256((__m256i const*)(SUPERDYADIC_LUT_B_FP16 + 16));
    lutB_1_fp32 = _mm512_cvtph_ps(b_block1);

    lut_prepared = true;
}

// Scalar utilities for stats
void fp16_to_fp32(const _Float16* h, float* f, size_t n) {
    for (size_t i = 0; i < n; ++i)
        f[i] = static_cast<float>(h[i]);
}

void compute_stats(const float* x, size_t n, float& mean, float& var) {
    double m = 0.0, s = 0.0;
    for (size_t i = 0; i < n; ++i) {
        double delta = x[i] - m;
        m += delta / (i + 1);
        s += delta * (x[i] - m);
    }
    mean = static_cast<float>(m);
    var  = (n > 1) ? static_cast<float>(s / (n - 1)) : 0.0f;
}

void piecewise_superdyadic_approx_fp16(const unsigned int n_samples,
                                      const _Float16 *input,
                                      int *segs,
                                      _Float16 *output)
{
    // Ensure LUT registers are prepared
    prepare_superdyadic_coefs_fp16();

    const unsigned int n_iters = n_samples / VECTOR_LENGTH_16;

    const __m512 one_f     = _mm512_set1_ps(1.0f);
    const __m512 half      = _mm512_set1_ps(0.5f);
    const __m512 minus0    = _mm512_set1_ps(-0.0f);
    const __m512 eps       = _mm512_set1_ps(1e-7f);
    const __m512 one_eps   = _mm512_set1_ps(1.0f - 1e-7f);
    const __m512i zero_i   = _mm512_setzero_epi32();
    const __m512i one_i    = _mm512_set1_epi32(1);
    const __m512i tbl_max  = _mm512_set1_epi32(NUM_BINS - 1);
    const __m512i sixteen_i= _mm512_set1_epi32(16);

    for (unsigned int it = 0, off = 0; it < n_iters; ++it, off += VECTOR_LENGTH_16) {
        // Load 32 FP16 values => packed as two 256-bit halves in a 512-bit register
        __m512i raw = _mm512_loadu_si512((__m512i const*)(input + off));
        
        // Split and convert each half to FP32 vectors of 16 lanes
        __m512 u0 = _mm512_cvtph_ps(_mm512_extracti32x8_epi32(raw, 0));
        __m512 u1 = _mm512_cvtph_ps(_mm512_extracti32x8_epi32(raw, 1));

        // Fold into [0,0.5], clamp for both halves
        __mmask16 gt0 = _mm512_cmp_ps_mask(u0, half, _CMP_GT_OS);
        u0 = _mm512_mask_sub_ps(u0, gt0, one_f, u0);
        u0 = _mm512_max_ps(u0, eps);
        u0 = _mm512_min_ps(u0, one_eps);

        __mmask16 gt1 = _mm512_cmp_ps_mask(u1, half, _CMP_GT_OS);
        u1 = _mm512_mask_sub_ps(u1, gt1, one_f, u1);
        u1 = _mm512_max_ps(u1, eps);
        u1 = _mm512_min_ps(u1, one_eps);

        // Linear search for bin index (as in original)
        __m512i idx0 = zero_i;
        __m512i idx1 = zero_i;
        for (int b = 0; b < NUM_BREAKS; ++b) {
            __m512 bp = _mm512_set1_ps(SUPERDYADIC_U[b]);
            __mmask16 m0 = _mm512_cmp_ps_mask(u0, bp, _CMP_GT_OS);
            __mmask16 m1 = _mm512_cmp_ps_mask(u1, bp, _CMP_GT_OS);
            idx0 = _mm512_mask_add_epi32(idx0, m0, idx0, one_i);
            idx1 = _mm512_mask_add_epi32(idx1, m1, idx1, one_i);
        }
        idx0 = _mm512_min_epi32(idx0, tbl_max);
        idx1 = _mm512_min_epi32(idx1, tbl_max);

        // First vector (u0)
        __mmask16 use_high0 = _mm512_cmpge_epi32_mask(idx0, sixteen_i);
        __m512i idx0_lo = idx0;
        __m512i idx0_hi = _mm512_mask_sub_epi32(idx0, use_high0, idx0, sixteen_i); // idx0 - 16 when use_high0

        __m512 c0_0_low = _mm512_permutexvar_ps(idx0_lo, lutA_0_fp32);
        __m512 c0_0_high = _mm512_permutexvar_ps(idx0_hi, lutA_1_fp32);
        __m512 c0 = _mm512_mask_blend_ps(use_high0, c0_0_low, c0_0_high);

        __m512 c1_0_low = _mm512_permutexvar_ps(idx0_lo, lutB_0_fp32);
        __m512 c1_0_high = _mm512_permutexvar_ps(idx0_hi, lutB_1_fp32);
        __m512 c1 = _mm512_mask_blend_ps(use_high0, c1_0_low, c1_0_high);

        __m512 z0 = _mm512_fmadd_ps(c1, u0, c0);
        z0 = _mm512_mask_xor_ps(z0, gt0, minus0, z0);

        // Second vector (u1)
        __mmask16 use_high1 = _mm512_cmpge_epi32_mask(idx1, sixteen_i);
        __m512i idx1_lo = idx1;
        __m512i idx1_hi = _mm512_mask_sub_epi32(idx1, use_high1, idx1, sixteen_i);

        __m512 c0_1_low = _mm512_permutexvar_ps(idx1_lo, lutA_0_fp32);
        __m512 c0_1_high = _mm512_permutexvar_ps(idx1_hi, lutA_1_fp32);
        __m512 c0_1 = _mm512_mask_blend_ps(use_high1, c0_1_low, c0_1_high);

        __m512 c1_1_low = _mm512_permutexvar_ps(idx1_lo, lutB_0_fp32);
        __m512 c1_1_high = _mm512_permutexvar_ps(idx1_hi, lutB_1_fp32);
        __m512 c1_1 = _mm512_mask_blend_ps(use_high1, c1_1_low, c1_1_high);

        __m512 z1 = _mm512_fmadd_ps(c1_1, u1, c0_1);
        z1 = _mm512_mask_xor_ps(z1, gt1, minus0, z1);

        // Pack back to FP16
        __m256i packed0 = _mm512_cvtps_ph(z0, _MM_FROUND_TO_NEAREST_INT |_MM_FROUND_NO_EXC);
        __m256i packed1 = _mm512_cvtps_ph(z1, _MM_FROUND_TO_NEAREST_INT |_MM_FROUND_NO_EXC);
        __m512i packed = _mm512_inserti32x8(_mm512_castsi256_si512(packed0), packed1, 1);
        _mm512_storeu_si512((__m512i*)(output + off), packed);

        // Store segment indices
        __m512i segs_i0 = _mm512_add_epi32(idx0, one_i);
        __m512i segs_i1 = _mm512_add_epi32(idx1, one_i);
        _mm512_storeu_si512(reinterpret_cast<void*>(segs + off), segs_i0);
        _mm512_storeu_si512(reinterpret_cast<void*>(segs + off + 16), segs_i1);
    }

    // Scalar tail
    for (unsigned int i = n_iters * VECTOR_LENGTH_16; i < n_samples; ++i) {
        float u = static_cast<float>(input[i]);
        bool gt = (u > 0.5f);
        float u0 = gt ? (1.0f - u) : u;
        u0 = std::clamp(u0, 1e-7f, 1.0f - 1e-7f);

        int idx = 0;
        for (int b = 0; b < NUM_BREAKS; ++b) {
            if (u0 > SUPERDYADIC_U[b]) idx++;
        }
        idx = std::min(idx, NUM_BINS - 1);

        // Fetch coefficients from the original FP16 tables, convert on the fly (cheap in scalar path)
        float c0 = static_cast<float>(SUPERDYADIC_LUT_A_FP16[idx]);
        float c1 = static_cast<float>(SUPERDYADIC_LUT_B_FP16[idx]);
        float z = c0 + c1 * u0;
        if (gt) z = -z;

        output[i] = static_cast<_Float16>(z);
        segs[i] = idx + 1;
    }
}

static double get_time() {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + ts.tv_nsec * 1e-9;
}

int main() {
    const int nSamples = N_SAMPLES;

    float    *output_mkl   = static_cast<float*>( mkl_malloc(nSamples*sizeof(float), 64));
    _Float16 *output_mkl_fp16 = static_cast<_Float16*>(mkl_malloc(N_SAMPLES * sizeof(_Float16), 64));
    _Float16 *out_fp16     = static_cast<_Float16*>(mkl_malloc(nSamples*sizeof(_Float16), 64));
    int      *segs         = static_cast<int*>(     mkl_malloc(nSamples*sizeof(int),   64));
    float    *u_vals       = static_cast<float*>( mkl_malloc(nSamples*sizeof(float), 64));
    _Float16 *u_vals16     = static_cast<_Float16*>(mkl_malloc(nSamples*sizeof(_Float16),64));

    float* out_mkl_fp32   = (float*)mkl_malloc(N_SAMPLES * sizeof(float), 64);
    float* approx_fp32    = (float*)mkl_malloc(N_SAMPLES * sizeof(float), 64);

    VSLStreamStatePtr st;
    vslNewStream(&st, VSL_BRNG_MT19937, 1234);

    std::srand(1234);
    for (int i = 0; i < nSamples; ++i) {
        float u = std::rand()/(RAND_MAX+1.0f);
        u = std::clamp(u, 1e-7f, 1.0f-1e-7f);
        u_vals[i]   = u;
        u_vals16[i] = static_cast<_Float16>(u);
    }

    // Prepare LUT (FP16 -> FP32 registers)
    prepare_superdyadic_coefs_fp16();

    // Benchmark MKL Gaussian RNG (cast to fp16)
    double t0 = get_time();
    vsRngGaussian(VSL_RNG_METHOD_GAUSSIAN_BOXMULLER,
                  st,
                  N_SAMPLES,
                  output_mkl,
                  0.0f,
                  1.0f);
    for (unsigned int i = 0; i < N_SAMPLES; ++i) {
        output_mkl_fp16[i] = static_cast<_Float16>(output_mkl[i]);
    }
    double t1 = get_time();
    printf("MKL vsRngGaussian (FP16): %.3f ms for %u samples\n",
           1e3 * (t1 - t0), N_SAMPLES);

    // benchmark superdyadic
    t0 = get_time(); piecewise_superdyadic_approx_fp16(nSamples,u_vals16,segs,out_fp16);
    t1 = get_time();
    printf("Vectorised Superdyadic (FP16): %.3f ms for %d samples\n",
           1e3*(t1-t0), nSamples);

    const int N_REPEATS=4;
    double total_time_lut=0.0;

    for (int pass = 0; pass < N_REPEATS; ++pass) {
        // MKL RNG
        double t0_inner = get_time();
        vsRngGaussian(VSL_RNG_METHOD_GAUSSIAN_BOXMULLER,
                      st,
                      N_SAMPLES,
                      output_mkl,
                      0.0f,
                      1.0f);
        for (unsigned int i = 0; i < N_SAMPLES; ++i) {
            output_mkl_fp16[i] = static_cast<_Float16>(output_mkl[i]);
        }
        double t1_inner = get_time();
        printf("MKL vsRngGaussian (FP16): %.3f ms for %u samples\n",
               1e3 * (t1_inner - t0_inner), N_SAMPLES);

        // superdyadic
        double t2 = get_time();
        piecewise_superdyadic_approx_fp16(nSamples,u_vals16,segs,out_fp16);
        double t3 = get_time();
        double lut_time = 1e3 * (t3 - t2);
        printf("Vectorised Superdyadic (FP16): %.3f ms for %d samples\n",
               lut_time, nSamples);
        total_time_lut += lut_time;
    }

    printf("\nVectorised Superdyadic - Average Run Time (FP16):     %.3f ms per run\n",
           total_time_lut / N_REPEATS);

    // Convert to FP32 to compute statistics
    fp16_to_fp32(output_mkl_fp16, out_mkl_fp32, N_SAMPLES);
    fp16_to_fp32(out_fp16, approx_fp32, N_SAMPLES);

    float mkl_mean, mkl_var;
    float approx_mean, approx_var;

    compute_stats(out_mkl_fp32, N_SAMPLES, mkl_mean, mkl_var);
    compute_stats(approx_fp32, N_SAMPLES, approx_mean, approx_var);

    printf("\nMKL Gaussian (Reference):\n");
    printf("  Mean    = %+.6f\n", mkl_mean);
    printf("  Variance=  %.6f\n", mkl_var);

    printf("\nPiecewise Polynomial Approximation:\n");
    printf("  Mean    = %+.6f\n", approx_mean);
    printf("  Variance=  %.6f\n", approx_var);

    printf("\nFirst 10 LUT approximations (fp16):\n");
    for (int i = 0; i < 10; ++i) {
        float u     = static_cast<float>(u_vals16[i]);
        float z_lut = static_cast<float>(out_fp16[i]);
        printf("  %2d) u = %.6f,   z_lut = %.6f\n",
               i+1, u, z_lut);
    }
    printf("\n");

    vslDeleteStream(&st);
    mkl_free(output_mkl);
    mkl_free(output_mkl_fp16);
    mkl_free(out_fp16);
    mkl_free(u_vals);
    mkl_free(u_vals16);
    mkl_free(segs);
    mkl_free(out_mkl_fp32);
    mkl_free(approx_fp32);
    return 0;
}





