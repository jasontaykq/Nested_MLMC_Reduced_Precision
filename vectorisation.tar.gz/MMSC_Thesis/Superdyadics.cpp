//Superdyadics.cpp

//Successful Gaussian sample generation using piecewise linear approximation on superdyadic intervals

#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <algorithm>
#include <ctime>
#include <immintrin.h>
#include <mkl.h>
#include "superdyadic_lut_52.h"     //LUT coefficient array in FP16 and FP32
#include "avx512_lut_superdyadic.h"    


#define N_EM_SAMPLES 10000000u  // Monte Carlo samples
#define M             1      // Time steps

int main() {
    const unsigned int N = M * N_EM_SAMPLES;   // total uniforms / normals
    // Allocate and generate Gaussians

    // Allocate random input as 16‑bit integers.  Each element has one
    // sign bit and a 15‑bit magnitude encoding a half precision value.
    uint16_t* all_u   = (uint16_t*)mkl_malloc(N * sizeof(uint16_t), 64);
    // Temporary buffer to generate floats for RNG
    float*     all_u_tmp = (float*)    mkl_malloc(N * sizeof(float),    64);


    float*    all_z_f32  = (float*)    mkl_malloc(M * N_EM_SAMPLES * sizeof(float),    64);
    _Float16* all_z_f16  = (_Float16*) mkl_malloc(M * N_EM_SAMPLES * sizeof(_Float16), 64);


    // ---- RNG (fixed seed for reproducibility) ----
    VSLStreamStatePtr stream;
    vslNewStream(&stream, VSL_BRNG_MT19937, 123456789);
    vsRngUniform(VSL_RNG_METHOD_UNIFORM_STD, stream, N, all_u_tmp, 0.0f, 1.0f);

    // Convert uniform floats to 16‑bit sign/magnitude encoding.  The MSB
    // encodes the sign (whether the sample lies in the upper half of the
    // unit interval) and the remaining bits encode a half precision
    // magnitude in [0,0.5].  Clamping to FP16‑representable limits avoids
    // index underflow/overflow.
    const float fp16_eps      = 6.1035e-5f;
    // When storing the folded magnitude we clamp it into the open interval
    // (eps, 0.5‑eps).  Using 0.5 rather than 1.0 here prevents very large
    // magnitudes from being generated when a second fold would occur.
    const float fp16_half_meps = 0.5f - fp16_eps;
    for (int i = 0; i < N; ++i) {
        float uf = all_u_tmp[i];
        bool sign = uf > 0.5f;
        float u_mag = sign ? (1.0f - uf) : uf;
        u_mag = std::max(u_mag, fp16_eps);
        u_mag = std::min(u_mag, fp16_half_meps);
        _Float16 h = (_Float16)u_mag;
        uint16_t bits;
        std::memcpy(&bits, &h, sizeof(uint16_t));
        if (sign) bits |= 0x8000u;
        all_u[i] = bits;
    }
    // Free the temporary float buffer
    mkl_free(all_u_tmp);

    // Generate normals via LUTs
    superdyadic_lut_avx512_fp32(N, all_u,all_z_f32);
    superdyadic_lut_avx512_fp16(N, all_u,all_z_f16);

    // ---- Sanity sweep for u in [0,1] in steps of 0.01 ----
    alignas(64) float    u_test[101];
    alignas(64) uint16_t u_test_int[101];
    alignas(64) float    z32_test[101];
    alignas(64) _Float16 z16_test[101];
    for (int i = 0; i <= 100; ++i) {
        float uf = i * 0.01f;
        u_test[i] = uf;
        bool sign = uf > 0.5f;
        float u_mag = sign ? (1.0f - uf) : uf;
        u_mag = std::max(u_mag, fp16_eps);
        u_mag = std::min(u_mag, fp16_half_meps);
        _Float16 h = (_Float16)u_mag;
        uint16_t bits;
        std::memcpy(&bits, &h, sizeof(uint16_t));
        if (sign) bits |= 0x8000u;
        u_test_int[i] = bits;
    }
    // Evaluate dyadic LUTs on the fixed uniforms
    superdyadic_lut_avx512_fp32(101, u_test_int, z32_test);
    superdyadic_lut_avx512_fp16(101, u_test_int, z16_test);

    // Print results (all 101 points)
    printf("\nSanity sweep (u = 0.00..1.00 step 0.01)\n");
    for (int i = 0; i <= 100; ++i) {
        float u   = u_test[i];
        float z32 = z32_test[i];
        float z16 = (float)z16_test[i]; // promote for printing
        printf("u=%6.2f  z_fp32=% .6f  z_fp16=% .6f\n", u, z32, z16);
    }
    

    // -------- Correlation + error stats --------
    // Use FP64 accumulators for stability.
    double sum32 = 0.0, sum16 = 0.0, sum32sq = 0.0, sum16sq = 0.0, cross = 0.0;
    double rmse_acc = 0.0, max_abs_err = 0.0;

    for (int i = 0; i < N; ++i) {
        double z32 = (double)all_z_f32[i];
        double z16 = (double)all_z_f16[i];     // promote for stats only

        sum32   += z32;
        sum16   += z16;
        sum32sq += z32 * z32;
        sum16sq += z16 * z16;
        cross   += z32 * z16;

        double e = z16 - z32;
        rmse_acc    += e * e;
        double ae = fabs(e);
        if (ae > max_abs_err) max_abs_err = ae;
    }

    double n     = (double)N;
    double mean32 = sum32 / n;
    double mean16 = sum16 / n;
    double var32  = (sum32sq - n * mean32 * mean32) / (n - 1.0);
    double var16  = (sum16sq - n * mean16 * mean16) / (n - 1.0);
    double cov    = (cross - n * mean32 * mean16) / (n - 1.0);
    double corr   = cov / sqrt(var32 * var16);
    double rmse   = sqrt(rmse_acc / n);

    printf("\n==== FP32 vs FP16 normal streams (Linear-Superdyadic Generation) ====\n");
    printf("N = %d\n", N);
    printf("mean32 = %.6e, var32 = %.6e\n", mean32, var32);
    printf("mean16 = %.6e, var16 = %.6e\n", mean16, var16);
    printf("cov    = %.6e, corr  = %.8f\n", cov, corr);
    printf("RMSE(z16 - z32) = %.6e,  max|z16 - z32| = %.6e\n", rmse, max_abs_err);

    
    // Cleanup
    vslDeleteStream(&stream);
    mkl_free(all_u);
    mkl_free(all_z_f32);
    mkl_free(all_z_f16);

    return 0;
}
