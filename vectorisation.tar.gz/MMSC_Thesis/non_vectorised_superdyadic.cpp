//non_vectorised_superdyadic.cpp
#define _POSIX_C_SOURCE 199309L

#include <iostream>
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <iomanip>
#include <cstdint>
#include <cstring>

#include "mkl.h"
#include "superdyadic_lut_52.h"

// High-resolution timer
static double get_time() {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + ts.tv_nsec * 1e-9;
}

void superdyadic_lookup_fp32(const float* x_vals,
                       int           num_points,
                       int*          segs,
                       float*        approx)
{
    constexpr int  num_superdyadic = sizeof(SUPERDYADIC_U) / sizeof(float);
    constexpr int  num_bins   = num_superdyadic - 1;     // == NUM_BINS
    constexpr int  tbl_max    = num_bins - 1;       // == TABLE_MAX_INDEX
    constexpr int  bias       = 127;                // float32 exponent bias
    constexpr int  mant_bits  = 23;

    const float eps     = 1e-7f;
    const float one_eps = 1.0f - 1e-7f;

    for (int k = 0; k < num_points; ++k) {
        float x    = x_vals[k];
        float u0   = std::min(x, 1.0f - x);
        float sign = (x > 0.5f ? -1.0f : 1.0f);

        // Clamp like your vector path
        u0 = std::clamp(u0, eps, one_eps);

        // Extract exponent bits (safe bit-cast)
        uint32_t bits;
        std::memcpy(&bits, &u0, sizeof(bits));
        int e = static_cast<int>((bits >> mant_bits) & 0xFF);  // unbiased later

        // j = bias - e; idx = (tbl_max + 2) - j; then clamp
        int j   = bias - e;
        int idx = (tbl_max + 2) - j;
        if (idx < 0)        idx = 0;
        if (idx > tbl_max)  idx = tbl_max;

        float z0 = SUPERDYADIC_LUT_A_FP32[idx] + SUPERDYADIC_LUT_B_FP32[idx] * u0;
        approx[k] = sign * z0;
        segs  [k] = idx + 1;
    }
}

// ——— fp16 version (using half‑precision LUTs) ———
void superdyadic_lookup_fp16(const float* x_vals_fp32,
                                      int          num_points,
                                      int*         segs,
                                      _Float16*      approx)
{
    constexpr int num_superdyadic = sizeof(SUPERDYADIC_U) / sizeof(float);
    constexpr int num_bins   = num_superdyadic - 1;        // == NUM_BINS
    constexpr int tbl_max    = num_bins - 1;          // == TABLE_MAX_INDEX
    constexpr int bias       = 127;                   // IEEE754 float32 exponent bias
    constexpr int mant_bits  = 23;

    const float eps     = 1e-7f;
    const float one_eps = 1.0f - 1e-7f;

    for (int k = 0; k < num_points; ++k) {
        // fold & sign in FP32 (shared with FP32 pipeline)
        float x    = x_vals_fp32[k];
        float u0f  = std::min(x, 1.0f - x);
        float sgnf = (x > 0.5f ? -1.0f : 1.0f);

        // clamp like your AVX512 path to keep exponent logic well-defined
        u0f = std::clamp(u0f, eps, one_eps);

        // exponent-based O(1) bin index from the FLOAT view
        uint32_t bits;
        std::memcpy(&bits, &u0f, sizeof(bits));
        int e   = static_cast<int>((bits >> mant_bits) & 0xFF);
        int j   = bias - e;
        int idx = (tbl_max + 2) - j;
        if (idx < 0)       idx = 0;
        if (idx > tbl_max) idx = tbl_max;

        // do LUT math in FP16
        __fp16 a   = SUPERDYADIC_LUT_A_FP16[idx];
        __fp16 b   = SUPERDYADIC_LUT_B_FP16[idx];
        __fp16 u0h = static_cast<__fp16>(u0f);
        __fp16 z0  = a + b * u0h;

        approx[k] = static_cast<__fp16>(sgnf) * z0;
        segs  [k] = idx + 1;
    }
}

int main() {
    const int nSamples = 10'000'000;
    const int N_REPEATS = 4;

    // Allocate buffers
    float *out_mkl = static_cast<float*>(mkl_malloc(nSamples * sizeof(float), 64));
    float *out_superdy_fp32 = static_cast<float*>(std::malloc(nSamples * sizeof(float)));
    _Float16 *out_superdy_fp16 = static_cast<_Float16*>(std::malloc(nSamples * sizeof(_Float16)));
    int *segs = static_cast<int*>(std::malloc(nSamples * sizeof(int)));

    // Initialize MKL RNG
    VSLStreamStatePtr stream;
    vslNewStream(&stream, VSL_BRNG_MT19937, 9988);

    // --- Benchmark Intel MKL Gaussian ---
    double t0 = get_time();
    vsRngGaussian(VSL_RNG_METHOD_GAUSSIAN_BOXMULLER,
                 stream, nSamples, out_mkl, 0.0f, 1.0f);
    double t1 = get_time();
    std::cout << "MKL vsRngGaussian (FP32): "
             << std::fixed << std::setprecision(3)
             << (1e3 * (t1 - t0)) << " ms for "
             << nSamples << " samples\n";

    // --- Prepare uniform samples ---
    float*  all_u_f32  = (float*) mkl_malloc(nSamples * sizeof(float), 64);
    vsRngUniform(VSL_RNG_METHOD_UNIFORM_STD, stream,
                 nSamples, all_u_f32, 0.0f, 1.0f);


    // --- Benchmark FP32 Superdyadic lookup ---
    t0 = get_time();
    superdyadic_lookup_fp32(all_u_f32, nSamples, segs, out_superdy_fp32);
    t1 = get_time();
    std::cout << "Non-Vectorised Superdyadic (FP32): "
             << std::fixed << std::setprecision(3)
             << (1e3 * (t1 - t0)) << " ms for "
             << nSamples << " samples\n";

    // --- Benchmark FP16 Superdyadic lookup ---
    t0 = get_time();
    superdyadic_lookup_fp16(all_u_f32, nSamples, segs, out_superdy_fp16);
    t1 = get_time();
    std::cout << "Non-Vectorised Superdyadic (FP16): "
             << std::fixed << std::setprecision(3)
             << (1e3 * (t1 - t0)) << " ms for "
             << nSamples << " samples\n";

    // Repeat benchmarks for averaging
    double total_time_fp32 = 0.0;
    double total_time_fp16 = 0.0;

    for (int run = 0; run < N_REPEATS; ++run) {
        // MKL benchmark
        t0 = get_time();
        vsRngGaussian(VSL_RNG_METHOD_GAUSSIAN_BOXMULLER,
                     stream, nSamples, out_mkl, 0.0f, 1.0f);
        t1 = get_time();
        std::cout << "MKL vsRngGaussian (FP32): "
                 << std::fixed << std::setprecision(3)
                 << (1e3 * (t1 - t0)) << " ms for "
                 << nSamples << " samples\n";

        // FP32 Superdyadic
        t0 = get_time();
        superdyadic_lookup_fp32(all_u_f32, nSamples, segs, out_superdy_fp32);
        t1 = get_time();
        double time_fp32 = 1e3 * (t1 - t0);
        std::cout << "Non-Vectorised Superdyadic (FP32): "
                 << std::fixed << std::setprecision(3)
                 << time_fp32 << " ms for "
                 << nSamples << " samples\n";
        total_time_fp32 += time_fp32;

        // FP16 Superdyadic
        t0 = get_time();
        superdyadic_lookup_fp16(all_u_f32, nSamples, segs, out_superdy_fp16);
        t1 = get_time();
        double time_fp16 = 1e3 * (t1 - t0);
        std::cout << "Non-Vectorised Superdyadic (FP16): "
                 << std::fixed << std::setprecision(3)
                 << time_fp16 << " ms for "
                 << nSamples << " samples\n";
        total_time_fp16 += time_fp16;
    }

    // Print averages
    printf("\n\n");
    printf("Non-vectorised Superdyadic - Average Run Time (FP32): %.3f ms per run\n", 
           total_time_fp32 / N_REPEATS);
    printf("Non-vectorised Superdyadic - Average Run Time (FP16): %.3f ms per run\n", 
           total_time_fp16 / N_REPEATS);

    // Sample outputs (using FP32 results for display)
    std::cout << "\nSample outputs (first 10):\n";
    std::cout << "Index |    u      |  seg  |  approx z  |\n";
    for (int i = 0; i < 10; ++i) {
        std::cout << std::setw(5) << (i+1)
                 << std::setw(12) << std::fixed << std::setprecision(6) << all_u_f32[i]
                 << std::setw(7) << segs[i]
                 << std::setw(12) << out_superdy_fp32[i] << "\n";
    }
    printf("\n\n");

    // Cleanup
    vslDeleteStream(&stream);
    mkl_free(out_mkl);
    std::free(out_superdy_fp32);
    std::free(out_superdy_fp16);
    std::free(all_u_f32);
    std::free(segs);

    return 0;
}

