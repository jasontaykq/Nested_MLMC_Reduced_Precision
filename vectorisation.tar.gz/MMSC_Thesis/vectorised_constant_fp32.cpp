// vectorised_constant_fp32.cpp

#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <ctime>
#include <immintrin.h>
#include <mkl.h>
#include "constant_lut_512.h"

#define VECTOR_LENGTH 16u
#define N_LUT         512u
#define N_SAMPLES     10000000u


//Welford's Algorithm
void compute_mean_variance(const float* data, size_t n, float& mean, float& variance) {
    if (n == 0) {
        mean = 0.0f;
        variance = 0.0f;
        return;
    }

    double m = 0.0;
    double s = 0.0;
    for (size_t i = 0; i < n; ++i) {
        double x = data[i];
        double delta = x - m;
        m += delta / (i + 1);
        s += delta * (x - m);
    }

    mean = static_cast<float>(m);
    variance = (n > 1) ? static_cast<float>(s / (n - 1)) : 0.0f;
}

// Vectorised AVX-512 FP32 LUT implementation
void lut_piecewise_constant_fp32_avx512(unsigned int n_samples,
                                        const float *input,
                                        float       *output)
{
    unsigned int n_iterations = n_samples / VECTOR_LENGTH;
    __m512     lut_scale      = _mm512_set1_ps(static_cast<float>(N_LUT) / 0.5f);
    __m512     lut_half       = _mm512_set1_ps(0.5f);
    __m512i    lut_max        = _mm512_set1_epi32(N_LUT - 1);

    for (unsigned int i = 0, offset = 0;
         i < n_iterations;
         ++i, offset += VECTOR_LENGTH)
    {
        __m512  u           = _mm512_loadu_ps(input + offset);
        __mmask16 mask_lower = _mm512_cmp_ps_mask(u, lut_half, _CMP_LT_OS);

        // lower-half indices
        __m512  idx_f_lower = _mm512_mul_ps(u, lut_scale);
        __m512i idx_lower   = _mm512_cvttps_epi32(idx_f_lower);
                 idx_lower   = _mm512_min_epi32(idx_lower, lut_max);

        // upper-half indices
        __m512  one          = _mm512_set1_ps(1.0f);
        __m512  u_mirrored   = _mm512_sub_ps(one, u);
        __m512  idx_f_upper  = _mm512_mul_ps(u_mirrored, lut_scale);
        __m512i idx_upper    = _mm512_cvttps_epi32(idx_f_upper);
                 idx_upper    = _mm512_min_epi32(idx_upper, lut_max);

        // gather & blend
        __m512 z_lower = _mm512_i32gather_ps(idx_lower, GAUSS_LUT, sizeof(float));
        __m512 z_upper = _mm512_i32gather_ps(idx_upper, GAUSS_LUT, sizeof(float));
                z_upper = _mm512_sub_ps(_mm512_setzero_ps(), z_upper);

        __m512 gauss = _mm512_mask_blend_ps(mask_lower, z_upper, z_lower);
        _mm512_storeu_ps(output + offset, gauss);
    }

    // tail handling
    for (unsigned int i = n_iterations * VECTOR_LENGTH;
         i < n_samples;
         ++i)
    {
        float u = input[i];
        // clamp to avoid hitting exactly 0 or 1
        if (u < 1e-7f)        u = 1e-7f;
        if (u > 1.0f - 1e-7f) u = 1.0f - 1e-7f;

        int   idx;
        float z;
        if (u < 0.5f) {
            idx = static_cast<int>(u * N_LUT / 0.5f);
            if (idx >= static_cast<int>(N_LUT)) idx = N_LUT - 1;
            z = GAUSS_LUT[idx];
        } else {
            idx = static_cast<int>((1.0f - u) * N_LUT / 0.5f);
            if (idx >= static_cast<int>(N_LUT)) idx = N_LUT - 1;
            z = -GAUSS_LUT[idx];
        }

        output[i] = z;
    }
}

// High-resolution timer
static double get_time() {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + ts.tv_nsec * 1e-9;
}

int main() {
    // Allocate buffers
    float *uniforms   = static_cast<float*>(mkl_malloc(N_SAMPLES * sizeof(float), 64));
    float *output_lut = static_cast<float*>(mkl_malloc(N_SAMPLES * sizeof(float), 64));
    float *output_mkl = static_cast<float*>(mkl_malloc(N_SAMPLES * sizeof(float), 64));
    float mkl_mean, mkl_var;
    float approx_mean, approx_var;
    
    
    // Initialize MKL RNG
    VSLStreamStatePtr stream;
    vslNewStream(&stream, VSL_BRNG_MT19937, 1234);
    vsRngUniform(VSL_RNG_METHOD_UNIFORM_STD, stream, N_SAMPLES, uniforms, 0.0f, 1.0f);

    // Benchmark Intel MKL Gaussian
    double t0 = get_time();
    vsRngGaussian(VSL_RNG_METHOD_GAUSSIAN_BOXMULLER,
                  stream, N_SAMPLES, output_mkl, 0.0f, 1.0f);
    double t1 = get_time();
    printf("Intel MKL vsRngGaussian (FP32): %.3f ms for %u samples\n",
           1e3 * (t1 - t0), N_SAMPLES);

    // Benchmark LUT Method
    t0 = get_time();
    lut_piecewise_constant_fp32_avx512(N_SAMPLES, uniforms, output_lut);
    t1 = get_time();
    printf("Vectorised Constant (FP32): %.3f ms for %u samples\n",
           1e3 * (t1 - t0), N_SAMPLES);


    const int N_REPEATS=4;
    double total_time_lut=0.0;
    // Additional runs to account for warm-up
    for (int i = 0; i < N_REPEATS; ++i) {
        t0 = get_time();
        vsRngGaussian(VSL_RNG_METHOD_GAUSSIAN_BOXMULLER,
                      stream, N_SAMPLES, output_mkl, 0.0f, 1.0f);
        t1 = get_time();
        printf("Intel MKL vsRngGaussian (FP32): %.3f ms for %u samples\n",
               1e3 * (t1 - t0), N_SAMPLES);       
        

        t0 = get_time();
        lut_piecewise_constant_fp32_avx512(N_SAMPLES, uniforms, output_lut);
        t1 = get_time();
        double lut_time = 1e3 *(t1-t0); 
        printf("Vectorised Constant (FP32): %.3f ms for %u samples\n",
               1e3 * (t1 - t0), N_SAMPLES);
        total_time_lut += lut_time;
               
    }

    printf("\n\n");
    printf("Vectorised Constant - Average Run Time (FP32):     %.5f ms per run\n", total_time_lut / N_REPEATS);
    
    compute_mean_variance(output_mkl, N_SAMPLES, mkl_mean, mkl_var);
    compute_mean_variance(output_lut, N_SAMPLES, approx_mean, approx_var);

    printf("\nStatistical Validation:\n");
    printf("MKL Gaussian (Reference):\n");
    printf("  Mean    = %+.6f\n", mkl_mean);
    printf("  Variance=  %.6f\n", mkl_var);

    printf("\nPiecewise Constant Approximation:\n");
    printf("  Mean    = %+.6f\n", approx_mean);
    printf("  Variance=  %.6f", approx_var);
    
    // Display first 10 LUT samples
    printf("\n\nFirst 10 LUT approximations (fp32):\n");
    for (int i = 0; i < 10; ++i) {
        printf("  %2d) u = %.6f,   z_lut = %.6f\n",
               i+1,
               uniforms[i],
               output_lut[i]);
    }
    printf("\n");

    // Cleanup
    vslDeleteStream(&stream);
    mkl_free(uniforms);
    mkl_free(output_lut);
    mkl_free(output_mkl);
    return 0;
}

