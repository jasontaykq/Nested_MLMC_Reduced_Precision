// conversion_test_dyadic.cpp
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <cstdint>
#include <cstring>   // for memcpy (safe bit-cast pre-C++20)

#include "dyadic_lut.h"

// ===================== Scalar dyadic lookup (FP32) =====================
static inline void dyadic_lookup_scalar_one_fp32(float x, float& out, int& seg)
{
    constexpr int  num_dyadic = sizeof(DYADIC_U) / sizeof(float);
    constexpr int  num_bins   = num_dyadic - 1;     // == NUM_BINS
    constexpr int  tbl_max    = num_bins - 1;       // == TABLE_MAX_INDEX
    constexpr int  bias       = 127;                // float32 exponent bias
    constexpr int  mant_bits  = 23;

    const float eps     = 1e-7f;
    const float one_eps = 1.0f - 1e-7f;

    // Fold to (0, 0.5] and keep sign
    float u0   = std::min(x, 1.0f - x);
    float sign = (x > 0.5f ? -1.0f : 1.0f);

    // Clamp for well-defined exponent behavior
    u0 = std::clamp(u0, eps, one_eps);

    // Extract exponent from IEEE-754 bits (biased)
    uint32_t bits;
    std::memcpy(&bits, &u0, sizeof(bits));
    int e = static_cast<int>((bits >> mant_bits) & 0xFF);

    // Map exponent to dyadic bin:
    // j ~ -ilogb(u0), idx = (tbl_max + 2) - j, then clamp
    int j   = bias - e;
    int idx = (tbl_max + 2) - j;
    if (idx < 0)        idx = 0;
    if (idx > tbl_max)  idx = tbl_max;

    // Piecewise-linear evaluation
    float z0 = DYADIC_LUT_A_FP32[idx] + DYADIC_LUT_B_FP32[idx] * u0;

    out = sign * z0;
    seg = idx + 1;
}

static inline void dyadic_lookup_array_fp32(const float* xs, int n, float* zs, int* segs)
{
    for (int i = 0; i < n; ++i) {
        dyadic_lookup_scalar_one_fp32(xs[i], zs[i], segs[i]);
    }
}

// ===================== Scalar dyadic lookup (FP16) =====================
static inline void dyadic_lookup_scalar_one_fp16(float x, _Float16& out, int& seg)
{
    constexpr int  num_dyadic = sizeof(DYADIC_U) / sizeof(float);
    constexpr int  num_bins   = num_dyadic - 1;     // == NUM_BINS
    constexpr int  tbl_max    = num_bins - 1;       // == TABLE_MAX_INDEX
    constexpr int  bias       = 127;                // IEEE754 float32 exponent bias
    constexpr int  mant_bits  = 23;

    const float eps     = 1e-7f;
    const float one_eps = 1.0f - 1e-7f;

    // Fold & sign in FP32
    float u0f  = std::min(x, 1.0f - x);
    float sgnf = (x > 0.5f ? -1.0f : 1.0f);
    u0f = std::clamp(u0f, eps, one_eps);

    // Exponent-based O(1) bin index from the FLOAT view
    uint32_t bits;
    std::memcpy(&bits, &u0f, sizeof(bits));
    int e   = static_cast<int>((bits >> mant_bits) & 0xFF);
    int j   = bias - e;
    int idx = (tbl_max + 2) - j;
    if (idx < 0)       idx = 0;
    if (idx > tbl_max) idx = tbl_max;

    // LUT math in FP16 (LUTs declared as __fp16 in dyadic_lut.h)
    __fp16 a   = DYADIC_LUT_A_FP16[idx];
    __fp16 b   = DYADIC_LUT_B_FP16[idx];
    __fp16 u0h = static_cast<__fp16>(u0f);
    __fp16 z0  = a + b * u0h;

    // Write out (buffer is _Float16)
    out = static_cast<_Float16>(static_cast<__fp16>(sgnf) * z0);
    seg = idx + 1;
}

static inline void dyadic_lookup_array_fp16(const float* xs, int n, _Float16* zs, int* segs)
{
    for (int i = 0; i < n; ++i) {
        dyadic_lookup_scalar_one_fp16(xs[i], zs[i], segs[i]);
    }
}

// =============================== Simple test driver ===============================
int main()
{
    // Uniform grid x = 0:0.01:1.00 (101 points)
    constexpr int N = 101;
    float    x [N];
    int      seg32 [N];
    float    z32 [N];
    int      seg16 [N];
    _Float16 z16 [N];

    for (int i = 0; i < N; ++i) x[i] = i * 0.01f;

    // FP32 test
    dyadic_lookup_array_fp32(x, N, z32, seg32);
    std::printf("Uniform grid float32 (0:0.01:1.0):\n");
    for (int i = 0; i < N; ++i) {
        std::printf("  x=%.2f, idx=%2d, approx=% .5f\n", x[i], seg32[i], z32[i]);
    }
    std::puts("");

    // FP16 test
    dyadic_lookup_array_fp16(x, N, z16, seg16);
    std::printf("Uniform grid fp16 (0:0.01:1.0):\n");
    for (int i = 0; i < N; ++i) {
        std::printf("  x=%.2f, idx=%2d, approx=% .5f\n", x[i], seg16[i], (float)z16[i]);
    }
    std::puts("");

    return 0;
}



