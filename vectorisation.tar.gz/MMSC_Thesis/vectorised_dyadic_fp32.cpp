//vectorised_dyadic_fp32.cpp
#define _POSIX_C_SOURCE 199309L

#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <ctime>
#include <algorithm>
#include <immintrin.h>
#include <mkl.h>
#include "dyadic_lut.h"

#define VECTOR_LENGTH_32   16u
#define N_SAMPLES       10000000u
#define N_MANTISSA_32   23
#define FLOAT32_EXPONENT_BIAS_TABLE_OFFSET 127

constexpr int NUM_BINS = sizeof(DYADIC_U) / sizeof(float) - 1;
constexpr int TABLE_MAX_INDEX = NUM_BINS - 1;


alignas(64) float poly_coef_0[NUM_BINS];
alignas(64) float poly_coef_1[NUM_BINS];

// Prepare polynomial coefficients based on your LUT
void prepare_polynomial_coefs() {
    for (int i = 0; i < NUM_BINS; ++i) {
        poly_coef_0[i] = DYADIC_LUT_A_FP32[i];
        poly_coef_1[i] = DYADIC_LUT_B_FP32[i];
    }
}

void piecewise_polynomial_approximation(unsigned int n_samples,
                                        const float *input,
                                        float *output) {
    const unsigned int n_iterations = n_samples / VECTOR_LENGTH_32;

    const __m512 half     = _mm512_set1_ps(0.5f);
    const __m512 one      = _mm512_set1_ps(1.0f);
    const __m512 minus0   = _mm512_set1_ps(-0.0f);
    const __m512 eps      = _mm512_set1_ps(1e-7f);
    const __m512 one_eps  = _mm512_set1_ps(1.0f - 1e-7f);

    const __m512i bias       = _mm512_set1_epi32(FLOAT32_EXPONENT_BIAS_TABLE_OFFSET);
    const __m512i tbl_max    = _mm512_set1_epi32(TABLE_MAX_INDEX);
    
    const __m512i remap_base = _mm512_set1_epi32(TABLE_MAX_INDEX+2);

    // load the whole LUT into two 512‑bit registers
    const __m512 coef0 = _mm512_load_ps(poly_coef_0);
    const __m512 coef1 = _mm512_load_ps(poly_coef_1);

    __m512 u, z, c0, c1;
    __m512i bits, idx, tmp;

    for (unsigned int i = 0, off = 0; i < n_iterations; ++i, off += VECTOR_LENGTH_32) {
        u = _mm512_loadu_ps(input + off);

        // fold into [0,0.5]
        __mmask16 gt = _mm512_cmp_ps_mask(u, half, _CMP_GT_OS);
        u = _mm512_mask_sub_ps(u, gt, one, u);

        // clamp exactly like scalar:
        u = _mm512_max_ps(u, eps);
        u = _mm512_min_ps(u, one_eps);

        // extract exponent bits
        bits = _mm512_castps_si512(u);
        bits = _mm512_srli_epi32(bits, N_MANTISSA_32);     // now contains (sign<<8)|exponent
        bits = _mm512_and_epi32(bits, _mm512_set1_epi32(0xFF));  // mask off sign, keep exponent only
        // j = bias - exponent
        bits = _mm512_sub_epi32(bias, bits);

        // remap j → idx so that idx=0 for the *smallest* bin, up to TABLE_MAX_INDEX
        idx = _mm512_sub_epi32(remap_base, bits);

        // clamp to [0, TABLE_MAX_INDEX]
        idx = _mm512_max_epi32(idx, _mm512_setzero_epi32());
        idx = _mm512_min_epi32(idx, tbl_max);

        // gather A and B
        tmp = _mm512_castps_si512(coef0);
        tmp = _mm512_permutexvar_epi32(idx, tmp);
        c0  = _mm512_castsi512_ps(tmp);

        tmp = _mm512_castps_si512(coef1);
        tmp = _mm512_permutexvar_epi32(idx, tmp);
        c1  = _mm512_castsi512_ps(tmp);

        // z = A + B * u
        z = _mm512_fmadd_ps(c1, u, c0);

        // restore sign
        z = _mm512_mask_xor_ps(z, gt, minus0, z);

        _mm512_storeu_ps(output + off, z);
    }
     // ---- Scalar Tail ----
    for (unsigned int i = n_iterations * VECTOR_LENGTH_32; i < n_samples; ++i) {
        float u = input[i];
        bool gt = u > 0.5f;
        if (gt) u = 1.0f - u;
        u = std::clamp(u, 1e-7f, 1.0f - 1e-7f);

        uint32_t bits = reinterpret_cast<const uint32_t&>(u) >> N_MANTISSA_32;
        bits &= 0xFF;  // Keep exponent only
        int j = FLOAT32_EXPONENT_BIAS_TABLE_OFFSET - static_cast<int>(bits);
        int idx = (TABLE_MAX_INDEX + 2) - j;
        idx = std::clamp(idx, 0, TABLE_MAX_INDEX);

        float z = poly_coef_0[idx] + poly_coef_1[idx] * u;
        if (gt) z = -z;  

        output[i] = z;
    }   
}

static double get_time() {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + ts.tv_nsec * 1e-9;
}

//Welford's Algorithm
void compute_mean_variance(const float* data, size_t n, float& mean, float& variance) {
    if (n == 0) {
        mean = 0.0f;
        variance = 0.0f;
        return;
    }

    double m = 0.0;
    double s = 0.0;
    for (size_t i = 0; i < n; ++i) {
        double x = data[i];
        double delta = x - m;
        m += delta / (i + 1);
        s += delta * (x - m);
    }

    mean = static_cast<float>(m);
    variance = (n > 1) ? static_cast<float>(s / (n - 1)) : 0.0f;
}


int main() {
    float *uniforms = static_cast<float*>(mkl_malloc(N_SAMPLES * sizeof(float), 64));
    float *approx = static_cast<float*>(mkl_malloc(N_SAMPLES * sizeof(float), 64));
    float *out_mkl    = static_cast<float*>(mkl_malloc(N_SAMPLES * sizeof(float), 64));
    float mkl_mean, mkl_var;
    float approx_mean, approx_var;

    prepare_polynomial_coefs();

    VSLStreamStatePtr stream;
    vslNewStream(&stream, VSL_BRNG_MT19937, 1234);
    vsRngUniform(VSL_RNG_METHOD_UNIFORM_STD, stream, N_SAMPLES, uniforms, 0.0f, 1.0f);

    // ---- Benchmark Intel MKL Gaussian ----
    double t0 = get_time();
    vsRngGaussian(VSL_RNG_METHOD_GAUSSIAN_BOXMULLER,
                  stream, N_SAMPLES, out_mkl, 0.0f, 1.0f);
    double t1 = get_time();
    printf("MKL vsRngGaussian (FP32): %.3f ms for %u samples\n",
           1e3 * (t1 - t0), N_SAMPLES);
          
    // ---- Benchmark Vectorised Dyadic ----
    t0 = get_time();
    piecewise_polynomial_approximation(N_SAMPLES, uniforms, approx);
    t1 = get_time();

    printf("Vectorised Dyadic (FP32): %.3f ms for %u samples\n", 1e3*(t1-t0), N_SAMPLES);


    const int N_REPEATS=4;
    double total_time_lut=0.0;
    
    // Re-runs to amortize startup costs
    for (int run = 0; run < N_REPEATS; ++run) {
    // ---- Benchmark Intel MKL Gaussian ----
    t0 = get_time();
    vsRngGaussian(VSL_RNG_METHOD_GAUSSIAN_BOXMULLER,
                  stream, N_SAMPLES, out_mkl, 0.0f, 1.0f);
    t1 = get_time();
    printf("MKL vsRngGaussian (FP32): %.3f ms for %u samples\n",
           1e3 * (t1 - t0), N_SAMPLES);
          
    // ---- Benchmark Vectorised Dyadic ----
    t0 = get_time();
    piecewise_polynomial_approximation(N_SAMPLES, uniforms, approx);
    t1 = get_time();
    double lut_time = 1e3 *(t1-t0); 
    printf("Vectorised Dyadic (FP32): %.3f ms for %u samples\n", 1e3*(t1-t0), N_SAMPLES);
    total_time_lut += lut_time;
    }

    printf("\n\n");
    printf("Vectorised Dyadic - Average Run Time (FP32):     %.3f ms per run\n", total_time_lut / N_REPEATS);
    
    
    
    compute_mean_variance(out_mkl, N_SAMPLES, mkl_mean, mkl_var);
    compute_mean_variance(approx, N_SAMPLES, approx_mean, approx_var);

    printf("\nMKL Gaussian (Reference):\n");
    printf("  Mean    = %+.6f\n", mkl_mean);
    printf("  Variance=  %.6f\n", mkl_var);

    printf("\nPiecewise Polynomial Approximation:\n");
    printf("  Mean    = %+.6f\n", approx_mean);
    printf("  Variance=  %.6f\n", approx_var);


    // Output first 10 samples for verification
    printf("\nFirst 10 results:\n idx |      u      | approx \n");
    for (int i = 0; i < 10; ++i)
        printf("%4d | %10.6f | %10.6f\n", i+1, uniforms[i], approx[i]);

    vslDeleteStream(&stream);
    mkl_free(uniforms);
    mkl_free(approx);

    return 0;
}



