// conversion_test_superdyadic.cpp
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <omp.h>
#include <cstdint>
#include <cstring>

#include "superdyadic_lut_52.h"

// ——— float32 version (unchanged) ———
// ——— float32 version (unchanged) ———
void superdyadic_lookup_fp32(const float* x_vals,
                       int           num_points,
                       int*          segs,
                       float*        approx)
{
    constexpr int  num_superdyadic = sizeof(SUPERDYADIC_U) / sizeof(float);
    constexpr int  num_bins   = num_superdyadic - 1;     // == NUM_BINS
    constexpr int  tbl_max    = num_bins - 1;       // == TABLE_MAX_INDEX
    constexpr int  bias       = 127;                // float32 exponent bias
    constexpr int  mant_bits  = 23;

    const float eps     = 1e-7f;
    const float one_eps = 1.0f - 1e-7f;

    for (int k = 0; k < num_points; ++k) {
        float x    = x_vals[k];
        float u0   = std::min(x, 1.0f - x);
        float sign = (x > 0.5f ? -1.0f : 1.0f);

        // Clamp like your vector path
        u0 = std::clamp(u0, eps, one_eps);

        // Extract exponent bits (safe bit-cast)
        uint32_t bits;
        std::memcpy(&bits, &u0, sizeof(bits));
        int e = static_cast<int>((bits >> mant_bits) & 0xFF);  // unbiased later

        // j = bias - e; idx = (tbl_max + 2) - j; then clamp
        int j   = bias - e;
        int idx = (tbl_max + 2) - j;
        if (idx < 0)        idx = 0;
        if (idx > tbl_max)  idx = tbl_max;

        float z0 = SUPERDYADIC_LUT_A_FP32[idx] + SUPERDYADIC_LUT_B_FP32[idx] * u0;
        approx[k] = sign * z0;
        segs  [k] = idx + 1;
    }
}

// ——— fp16 version (using half‑precision LUTs) ———
void superdyadic_lookup_fp16(const float* x_vals_fp32,
                                      int          num_points,
                                      int*         segs,
                                      __fp16*      approx)
{
    constexpr int num_superdyadic = sizeof(SUPERDYADIC_U) / sizeof(float);
    constexpr int num_bins   = num_superdyadic - 1;        // == NUM_BINS
    constexpr int tbl_max    = num_bins - 1;          // == TABLE_MAX_INDEX
    constexpr int bias       = 127;                   // IEEE754 float32 exponent bias
    constexpr int mant_bits  = 23;

    const float eps     = 1e-7f;
    const float one_eps = 1.0f - 1e-7f;

    for (int k = 0; k < num_points; ++k) {
        // fold & sign in FP32 (shared with FP32 pipeline)
        float x    = x_vals_fp32[k];
        float u0f  = std::min(x, 1.0f - x);
        float sgnf = (x > 0.5f ? -1.0f : 1.0f);

        // clamp like your AVX512 path to keep exponent logic well-defined
        u0f = std::clamp(u0f, eps, one_eps);

        // exponent-based O(1) bin index from the FLOAT view
        uint32_t bits;
        std::memcpy(&bits, &u0f, sizeof(bits));
        int e   = static_cast<int>((bits >> mant_bits) & 0xFF);
        int j   = bias - e;
        int idx = (tbl_max + 2) - j;
        if (idx < 0)       idx = 0;
        if (idx > tbl_max) idx = tbl_max;

        // do LUT math in FP16
        __fp16 a   = SUPERDYADIC_LUT_A_FP16[idx];
        __fp16 b   = SUPERDYADIC_LUT_B_FP16[idx];
        __fp16 u0h = static_cast<__fp16>(u0f);
        __fp16 z0  = a + b * u0h;

        approx[k] = static_cast<__fp16>(sgnf) * z0;
        segs  [k] = idx + 1;
    }
}


int main()
{
    std::srand(std::time(nullptr));

    // ——— Test #1: float32 uniform x = 0:0.01:1.0 ———
    {
        constexpr int N1 = 101;
        float   x1   [N1];
        int     seg1 [N1];
        float   z1   [N1];

        for (int i = 0; i < N1; ++i)
            x1[i] = i * 0.01f;

        superdyadic_lookup_fp32(x1, N1, seg1, z1);

        std::printf("Uniform grid float32 (0:0.01:1.0):\n");
        for (int i = 0; i < N1; ++i) {
            std::printf("  x=%.2f, idx=%2d, approx=% .5f\n",
                        x1[i], seg1[i], z1[i]);
        }
        std::puts("");
    }

/*
    // ——— Test #2: fp16 uniform x = 0:0.01:1.0 ———
    {
        constexpr int N2 = 101;
        __fp16 x2   [N2];
        int    seg2 [N2];
        __fp16 z2   [N2];

        for (int i = 0; i < N2; ++i)
            x2[i] = (__fp16)(i * 0.01f);

        superdyadic_lookup_fp16(x2, N2, seg2, z2);

        std::printf("Uniform grid fp16 (0:0.01:1.0):\n");
        for (int i = 0; i < N2; ++i) {
            std::printf("  x=%.2f, idx=%2d, approx=% .5f\n",
                        (float)x2[i], seg2[i], (float)z2[i]);
        }
        std::puts("");
    }
*/
    return 0;
}

