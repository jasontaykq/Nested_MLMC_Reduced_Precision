//Constants.cpp

//Successful Gaussian sample generation using piecewise constant approximation on uniform intervals
//Files to include: constant_lut_512.h; avx512_lut_constant.h; fp16x32.h

#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <ctime>
#include <immintrin.h>
#include <mkl.h>
#include "constant_lut_512.h"     //LUT coefficient array in FP16 and FP32
#include "avx512_lut_constant.h"    //Piecewise constant approximation of Inverse CDF on Uniform Intervals (Gaussian sample generator) - FP16 and FP32
#include "fp16x32.h"   //Header file consisting Mike Gile's emulated gather_fp16

#define N_EM_SAMPLES 10000000u  // Monte Carlo samples
#define M             1      // Time steps

int main() {
    // Allocate and generate Gaussians
    float*    all_u_f32  = (float*)    mkl_malloc(M * N_EM_SAMPLES * sizeof(float),    64);
    _Float16* all_u_f16  = (_Float16*) mkl_malloc(M * N_EM_SAMPLES * sizeof(_Float16), 64);
    float*    all_z_f32  = (float*)    mkl_malloc(M * N_EM_SAMPLES * sizeof(float),    64);
    _Float16* all_z_f16  = (_Float16*) mkl_malloc(M * N_EM_SAMPLES * sizeof(_Float16), 64);

    // LUT for FP16
    uint32_t* lut_fp16 = (uint32_t*) mkl_malloc(N_LUT * sizeof(uint32_t), 64);
    build_fp16_duplicated_lut(lut_fp16, GAUSS_LUT, N_LUT);

    // ---- RNG (fixed seed for reproducibility) ----
    VSLStreamStatePtr stream;
    vslNewStream(&stream, VSL_BRNG_MT19937, 123456789);

    const int N = M * N_EM_SAMPLES;
    vsRngUniform(VSL_RNG_METHOD_UNIFORM_STD, stream, N, all_u_f32, 0.0f, 1.0f);
    for (int i = 0; i < N; ++i) all_u_f16[i] = (_Float16)all_u_f32[i];

    // Generate normals via LUTs
    lut_piecewise_constant_fp32_avx512(N, all_u_f32, all_z_f32);
    lut_piecewise_constant_fp16_avx512(N, all_u_f32, all_z_f16, lut_fp16);



    alignas(64) float    u_test[101];
    alignas(64) float    z32_test[101];
    alignas(64) _Float16 z16_test[101];
    alignas(64) uint32_t lut_fp16_test[101];
    build_fp16_duplicated_lut(lut_fp16_test, GAUSS_LUT, N_LUT);


    for (int i = 0; i <= 100; ++i) {
        u_test[i] = i * 0.01f;
    }
    
// Evaluate dyadic LUTs on the fixed uniforms
    lut_piecewise_constant_fp32_avx512(101, u_test, z32_test);
    lut_piecewise_constant_fp16_avx512(101, u_test, z16_test, lut_fp16_test);

    // Print results (all 101 points)
    printf("\nSanity sweep (u = 0.00..1.00 step 0.01)\n");
    for (int i = 0; i <= 100; ++i) {
        const float u   = u_test[i];
        const float z32 = z32_test[i];
        const float z16 = (float)z16_test[i]; // promote for printing
        printf("u=%6.2f  z_fp32=% .6f  z_fp16=% .6f\n", u, z32, z16);
    
}


    // -------- Correlation + error stats --------
    // Use FP64 accumulators for stability.
    double sum32 = 0.0, sum16 = 0.0, sum32sq = 0.0, sum16sq = 0.0, cross = 0.0;
    double rmse_acc = 0.0, max_abs_err = 0.0;

    for (int i = 0; i < N; ++i) {
        double z32 = (double)all_z_f32[i];
        double z16 = (double)all_z_f16[i];     // promote for stats only

        sum32   += z32;
        sum16   += z16;
        sum32sq += z32 * z32;
        sum16sq += z16 * z16;
        cross   += z32 * z16;

        double e = z16 - z32;
        rmse_acc    += e * e;
        double ae = fabs(e);
        if (ae > max_abs_err) max_abs_err = ae;
    }

    double n     = (double)N;
    double mean32 = sum32 / n;
    double mean16 = sum16 / n;
    double var32  = (sum32sq - n * mean32 * mean32) / (n - 1.0);
    double var16  = (sum16sq - n * mean16 * mean16) / (n - 1.0);
    double cov    = (cross - n * mean32 * mean16) / (n - 1.0);
    double corr   = cov / sqrt(var32 * var16);
    double rmse   = sqrt(rmse_acc / n);

    printf("\n==== FP32 vs FP16 normal streams (Constant-Uniform) ====\n");
    printf("N = %d\n", N);
    printf("mean32 = %.6e, var32 = %.6e\n", mean32, var32);
    printf("mean16 = %.6e, var16 = %.6e\n", mean16, var16);
    printf("cov    = %.6e, corr  = %.8f\n", cov, corr);
    printf("RMSE(z16 - z32) = %.6e,  max|z16 - z32| = %.6e\n", rmse, max_abs_err);

    
    // Cleanup
    vslDeleteStream(&stream);
    mkl_free(all_u_f32);
    mkl_free(all_u_f16);
    mkl_free(all_z_f32);
    mkl_free(all_z_f16);
    mkl_free(lut_fp16);

    return 0;
}



/* #Makefile
LIB := -lmkl_intel_lp64 -lmkl_sequential -lmkl_core -lpthread -lm -ldl

# uncomment these lines for the Gnu gcc compiler
# CC	:= gcc
# FLAGS	:= -std=c99 -O3 -march=native -fopenmp

# uncomment these lines for the Intel icx compiler
# -- the default for -qopt-report is 2, the range is 1-5
#CC	:= icx    //(unused for C)
CXX := icpx


#FLAGS   := -std=c99 -O3 -xHost -qopenmp -qopt-report=1 -qopt-report-file=stdout -mavx512fp16  //unused (for C)
CXXFLAGS := -std=c++17 -O3 -xHost -mavx512fp16


all:	Constants


Constants: Constants.cpp
	$(CXX) $(CXXFLAGS) Constants.cpp -o Constants $(LIB)
		
clean:	Constants



*/
    
