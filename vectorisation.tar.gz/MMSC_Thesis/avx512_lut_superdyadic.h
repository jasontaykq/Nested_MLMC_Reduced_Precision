// avx512_lut_superdyadic.h

#pragma once

#include <immintrin.h>
#include <algorithm>
#include <cstdint>
#include <cstring>
#include <vector>
#include "superdyadic_lut_52.h"


#ifndef FP16_EXP_BIAS
#define FP16_EXP_BIAS 15
#endif
#ifndef FP16_M_BITS
#define FP16_M_BITS 10
#endif

constexpr int SUPER_NUM_BINS  = 26;
constexpr int SUPER_MAX_INDEX = SUPER_NUM_BINS - 1;

#define FP16_SQRT2_FRAC  424
#define FP32_SQRT2_FRAC  0x3504F3
#ifndef FP16_SQRT2_MANT
#define FP16_SQRT2_MANT 424
#endif

// Consistent clamping values
constexpr float FP16_MIN_NORMAL = 6.1035156e-05f; // 2^-14
constexpr float FP16_MAX_CLAMP  = 0.5f;           // After folding

alignas(64) static float super_coef_0_fp32[SUPER_NUM_BINS];
alignas(64) static float super_coef_1_fp32[SUPER_NUM_BINS];
static bool super32_ready = false;

inline void prepare_superdyadic_coefs_fp32() {
    if (super32_ready) return;
    for (int i = 0; i < SUPER_NUM_BINS; ++i) {
        super_coef_0_fp32[i] = SUPERDYADIC_LUT_A_FP32[i];
        super_coef_1_fp32[i] = SUPERDYADIC_LUT_B_FP32[i];
    }
    super32_ready = true;
}

inline void superdyadic_lut_avx512_fp32(unsigned int n_samples,
                                        const uint16_t* __restrict input,
                                        float* __restrict output)
{
    prepare_superdyadic_coefs_fp32();

    const unsigned VL = 16u;
    const unsigned iters = n_samples / VL;

    // Constants for clamping and sign restoration.
    const __m512 min_clamp = _mm512_set1_ps(FP16_MIN_NORMAL);
    const float half_meps = 0.5f;
    const __m512 max_clamp = _mm512_set1_ps(half_meps);
    const __m512 minus0   = _mm512_set1_ps(-0.0f);
    const __m512i mant_mask  = _mm512_set1_epi32(0x7FFFFF);

    // Sign and magnitude masks for 16-bit inputs
    const __m256i sign_mask16 = _mm256_set1_epi16(0x8000);
    const __m256i abs_mask16  = _mm256_set1_epi16(0x7FFF);

    for (unsigned i = 0, off = 0; i < iters; ++i, off += VL) {
        // Load 16 16-bit samples
        __m256i u16_i = _mm256_loadu_si256((const __m256i*)(input + off));

        // Extract sign bits and create a 16-lane mask
        __m256i sign_bits = _mm256_and_si256(u16_i, sign_mask16);
        __m512i sign_bits_512 = _mm512_castsi256_si512(sign_bits);
        __mmask32 gt_mask32 = _mm512_test_epi16_mask(sign_bits_512, sign_bits_512);
        __mmask16 gt_mask = (uint16_t)(gt_mask32 & 0xFFFF);

        // Clear the sign bit to obtain the magnitude bits and convert to half
        __m256i mag_i   = _mm256_and_si256(u16_i, abs_mask16);
        __m256h mag_h   = _mm256_castsi256_ph(mag_i);
        // Convert the half precision magnitudes to single precision
        __m512 u        = _mm512_cvtph_ps(mag_h);

        // Clamp to (FP16_MIN_NORMAL, 0.5]
        u = _mm512_max_ps(u, min_clamp);
        u = _mm512_min_ps(u, max_clamp);

        // Compute exponent and mantissa bits from the FP32 value
        __m512i ubits = _mm512_castps_si512(u);
        __m512i exp   = _mm512_srli_epi32(ubits, 23);
        __m512i mant  = _mm512_and_epi32(ubits, mant_mask);

        // dy = clamp(exp - 113, 0..12)
        __m512i dy    = _mm512_sub_epi32(exp, _mm512_set1_epi32(113));
        dy            = _mm512_max_epi32(dy, _mm512_setzero_epi32());
        dy            = _mm512_min_epi32(dy, _mm512_set1_epi32(12));

        // --- Exponent-of-squares split ---
        // y = u^2, e_y (biased) = exponent(y)
        __m512  y     = _mm512_mul_ps(u, u);
        __m512i ybits = _mm512_castps_si512(y);
        __m512i e_y   = _mm512_srli_epi32(ybits, 23);
        // Threshold: e_y >= 126 - 2*j  (FP32 bias=127)
        __m512i thr   = _mm512_sub_epi32(_mm512_set1_epi32(126),
                                         _mm512_slli_epi32(dy, 1));
        __mmask16 hi  = _mm512_cmp_epi32_mask(e_y, thr, _MM_CMPINT_GE);

        // superdyadic index: idx = min(2*dy + hi, SUPER_MAX_INDEX)
        __m512i idx   = _mm512_slli_epi32(dy, 1);
        idx           = _mm512_mask_add_epi32(idx, hi, idx, _mm512_set1_epi32(1));
        idx           = _mm512_min_epi32(idx, _mm512_set1_epi32(SUPER_MAX_INDEX));

        // Gather A and B coefficients
        __m512 c0 = _mm512_i32gather_ps(idx, super_coef_0_fp32, 4);
        __m512 c1 = _mm512_i32gather_ps(idx, super_coef_1_fp32, 4);
        __m512 z  = _mm512_fmadd_ps(c1, u, c0);

        // Restore the sign by flipping the sign bit where gt_mask is set
        z = _mm512_mask_xor_ps(z, gt_mask, minus0, z);

        _mm512_storeu_ps(output + off, z);
    }

    // Scalar tail
    for (unsigned t = iters * VL; t < n_samples; ++t) {
        uint16_t bits = input[t];
        bool g    = (bits & 0x8000u) != 0u;
        bits &= 0x7FFFu;
        _Float16 h;
        std::memcpy(&h, &bits, sizeof(uint16_t));
        float u = static_cast<float>(h);
        u = std::max(u, FP16_MIN_NORMAL);
        u = std::min(u, half_meps);
        uint32_t ubits;
        std::memcpy(&ubits, &u, sizeof(float));
        int e    = (ubits >> 23) & 0xFF;
        int mant = ubits & 0x7FFFFF;
        int dy   = std::min(std::max(e - 113, 0), 12);

        // exponent-of-squares split
        float y = u * u;
        uint32_t ybits;
        std::memcpy(&ybits, &y, sizeof(float));
        int e_y = (ybits >> 23) & 0xFF;
        int thr = 126 - (dy << 1);
        int hi  = (e_y >= thr) ? 1 : 0;

        int idx  = std::min(2*dy + hi, SUPER_MAX_INDEX);
        float z  = super_coef_0_fp32[idx] + super_coef_1_fp32[idx] * u;
        output[t] = g ? -z : z;
    }
}


alignas(64) static uint16_t SUPER_A_BANK16[32];
alignas(64) static uint16_t SUPER_B_BANK16[32];
static bool super16_ready = false;

inline void prepare_superdyadic_coefs_fp16_banks() {
    if (super16_ready) return;
    for (int i = 0; i < 32; ++i) {
        uint16_t a = 0, b = 0;
        if (i < SUPER_NUM_BINS) {
            std::memcpy(&a, &SUPERDYADIC_LUT_A_FP16[i], sizeof(uint16_t));
            std::memcpy(&b, &SUPERDYADIC_LUT_B_FP16[i], sizeof(uint16_t));
        }
        SUPER_A_BANK16[i] = a;
        SUPER_B_BANK16[i] = b;
    }
    super16_ready = true;
}

inline void superdyadic_lut_avx512_fp16(unsigned int n_samples,
                                        const uint16_t* __restrict input,
                                        _Float16* __restrict output)
{
    prepare_superdyadic_coefs_fp16_banks();

    const unsigned VL    = 32u;
    const unsigned iters = n_samples / VL;

    // FP16 constants for clamping and sign restore
    const _Float16 fp16_eps        = (_Float16)FP16_MIN_NORMAL;
    const _Float16 fp16_half_meps  = (_Float16)0.5f;
    const __m512h eps_h      = _mm512_set1_ph(fp16_eps);
    const __m512h half_meps_h= _mm512_set1_ph(fp16_half_meps);
    const __m512h mone_h     = _mm512_set1_ph((_Float16)(-1.0f));
    const __m512i zero16     = _mm512_setzero_si512();
    const __m512i twelve16   = _mm512_set1_epi16(12);
    const __m512i abs_mask   = _mm512_set1_epi16(0x7FFF);
    const __m512i sign_mask  = _mm512_set1_epi16(0x8000);

    // Load LUT banks
    const __m512i A_bank = _mm512_load_si512((const __m512i*)SUPER_A_BANK16);
    const __m512i B_bank = _mm512_load_si512((const __m512i*)SUPER_B_BANK16);

    for (unsigned i = 0, off = 0; i < iters; ++i, off += VL) {
        // Load 32 16-bit samples
        __m512i u16_i = _mm512_loadu_si512((const void*)(input + off));
        // Extract sign mask (MSB)
        __mmask32 gt = _mm512_test_epi16_mask(u16_i, sign_mask);
        // Clear sign bit
        __m512i mag_i = _mm512_and_si512(u16_i, abs_mask);
        __m512h u_h   = _mm512_castsi512_ph(mag_i);
        // Clamp to (eps, 0.5] in half precision
        u_h = _mm512_max_ph(u_h, eps_h);
        u_h = _mm512_min_ph(u_h, half_meps_h);

        // Extract exponent (biased) from half bits
        __m512i u_bits = _mm512_castph_si512(u_h);
        __m512i exp16  = _mm512_srli_epi16(_mm512_and_si512(u_bits, _mm512_set1_epi16(0x7C00)), FP16_M_BITS);

        // dy = clamp(exp - 1, 0..12)
        __m512i dy = _mm512_sub_epi16(exp16, _mm512_set1_epi16(1));
        dy         = _mm512_max_epi16(dy, zero16);
        dy         = _mm512_min_epi16(dy, twelve16);

        // --- Exponent-of-squares split for FP16 ---
        __m512h  y_h   = _mm512_mul_ph(u_h, u_h);
        __m512i  ybits = _mm512_castph_si512(y_h);
        __m512i  e_y16 = _mm512_srli_epi16(_mm512_and_si512(ybits, _mm512_set1_epi16(0x7C00)), FP16_M_BITS);
        // Threshold: e_y16 >= 14 - 2*j  (FP16 bias=15)
        __m512i  thr16 = _mm512_sub_epi16(_mm512_set1_epi16(14),
                                          _mm512_slli_epi16(dy, 1));
        __mmask32 hi_m = _mm512_cmp_epi16_mask(e_y16, thr16, _MM_CMPINT_GE);

        // idx = min(2*dy + hi, 25)
        __m512i idx = _mm512_slli_epi16(dy, 1);
        idx         = _mm512_mask_add_epi16(idx, hi_m, idx, _mm512_set1_epi16(1));
        idx         = _mm512_min_epi16(idx, _mm512_set1_epi16(SUPER_MAX_INDEX));

        // Gather FP16 coefficients
        __m512i A_sel = _mm512_maskz_permutexvar_epi16((__mmask32)0xFFFFFFFFu, idx, A_bank);
        __m512i B_sel = _mm512_maskz_permutexvar_epi16((__mmask32)0xFFFFFFFFu, idx, B_bank);
        __m512h A_h   = _mm512_castsi512_ph(A_sel);
        __m512h B_h   = _mm512_castsi512_ph(B_sel);

        // Evaluate polynomial
        __m512h z = _mm512_fmadd_ph(B_h, u_h, A_h);
        // Restore sign
        z = _mm512_mask_mul_ph(z, gt, z, mone_h);
        // Store result
        _mm512_storeu_ph(output + off, z);
    }

    // Scalar tail
    for (unsigned t = iters * VL; t < n_samples; ++t) {
        uint16_t bits = input[t];
        bool g    = (bits & 0x8000u) != 0u;
        bits &= 0x7FFFu;

        _Float16 u;
        std::memcpy(&u, &bits, sizeof(uint16_t));
        // Clamp to (eps, 0.5] in half precision
        if (u < fp16_eps) u = fp16_eps;
        if (u > fp16_half_meps) u = fp16_half_meps;

        int e   = ((bits & 0x7C00u) >> FP16_M_BITS);
        int dy  = std::min(std::max(e - 1, 0), 12);

        // exponent-of-squares split for scalar half
        _Float16 y = (_Float16)(u * u);
        uint16_t ybits;
        std::memcpy(&ybits, &y, sizeof(uint16_t));
        int e_y16 = (ybits & 0x7C00u) >> FP16_M_BITS;
        int thr16 = 14 - (dy << 1);
        int hi    = (e_y16 >= thr16) ? 1 : 0;

        int idx = std::min(2*dy + hi, SUPER_MAX_INDEX);
        _Float16 z = SUPERDYADIC_LUT_A_FP16[idx] + SUPERDYADIC_LUT_B_FP16[idx] * u;
        output[t]  = g ? (_Float16)(-z) : z;
    }
}

