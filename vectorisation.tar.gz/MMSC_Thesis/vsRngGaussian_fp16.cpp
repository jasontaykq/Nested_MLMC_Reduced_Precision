//vsRngGaussian_timings.cpp      ---testing FP32 and FP16



#include <iostream>
#include <cstdint>
#include <cstdlib>
#include <ctime>
#include <iomanip>

#include "mkl.h"

// Get high-resolution time in seconds
static double get_time() {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + ts.tv_nsec * 1e-9;
}

int main() {
    const int nSamples = 10000000; // 10 million samples
    // Initialize MKL RNG stream
    VSLStreamStatePtr stream;
    vslNewStream(&stream, VSL_BRNG_MT19937, time(NULL));

    // ---- Benchmark Intel MKL Method in FP32 ----
    float *output_f32_BM = (float*)mkl_malloc(nSamples * sizeof(float), 64);
    float *output_f32_BM2 = (float*)mkl_malloc(nSamples * sizeof(float), 64);
    float *output_f32_ICDF = (float*)mkl_malloc(nSamples * sizeof(float), 64);
    
    _Float16  *output_fp16_BM  = (_Float16*)mkl_malloc(nSamples * sizeof(_Float16), 64);
    _Float16  *output_fp16_BM2  = (_Float16*)mkl_malloc(nSamples * sizeof(_Float16), 64);
    _Float16  *output_fp16_ICDF  = (_Float16*)mkl_malloc(nSamples * sizeof(_Float16), 64);

 
    double t0_BM_32 = get_time();
    vsRngGaussian(VSL_RNG_METHOD_GAUSSIAN_BOXMULLER, stream,
                  nSamples, output_f32_BM, 0.0f, 1.0f);
    double t1_BM_32 = get_time();
    printf("Avg. time per sample (Box Muller) FP32: %.7f ns\n", (1e9 * (t1_BM_32 - t0_BM_32))/nSamples);    
    
    
    double t0_BM2_32 = get_time();
    vsRngGaussian(VSL_RNG_METHOD_GAUSSIAN_BOXMULLER2, stream,
                  nSamples, output_f32_BM2, 0.0f, 1.0f);
    double t1_BM2_32 = get_time();
    printf("Avg. time per sample (Box Muller 2) FP32: %.7f ns\n", (1e9 * (t1_BM2_32 - t0_BM2_32))/nSamples);   
    
    
    double t0_ICDF_32 = get_time();
    vsRngGaussian(VSL_RNG_METHOD_GAUSSIAN_ICDF, stream,
                  nSamples, output_f32_ICDF, 0.0f, 1.0f);
    double t1_ICDF_32 = get_time();
    printf("Avg. time per sample (ICDF) FP32: %.7f ns\n", (1e9 * (t1_ICDF_32 - t0_ICDF_32))/nSamples);    


    double t0_BM = get_time();
    vsRngGaussian(VSL_RNG_METHOD_GAUSSIAN_BOXMULLER, stream,
                  nSamples, output_f32_BM, 0.0f, 1.0f);
    for (unsigned int i = 0; i < nSamples; ++i) {
        output_fp16_BM[i] = static_cast<_Float16>(output_f32_BM[i]);
    }
    double t1_BM = get_time();
    printf("Avg. time per sample (Box Muller) FP16: %.7f ns\n", (1e9 * (t1_BM - t0_BM))/nSamples);     

    double t0_BM2 = get_time();
    vsRngGaussian(VSL_RNG_METHOD_GAUSSIAN_BOXMULLER2, stream,
                  nSamples, output_f32_BM2, 0.0f, 1.0f);
    for (unsigned int i = 0; i < nSamples; ++i) {
        output_fp16_BM2[i] = static_cast<_Float16>(output_f32_BM2[i]);
    }
    double t1_BM2 = get_time();
    printf("Avg. time per sample (Box Muller 2) FP16: %.7f ns\n", (1e9 * (t1_BM2 - t0_BM2))/nSamples);    
    
    
    double t0_ICDF = get_time();
    vsRngGaussian(VSL_RNG_METHOD_GAUSSIAN_ICDF, stream,
                  nSamples, output_f32_ICDF, 0.0f, 1.0f);
    for (unsigned int i = 0; i < nSamples; ++i) {
        output_fp16_ICDF[i] = static_cast<_Float16>(output_f32_ICDF[i]);
    }
    double t1_ICDF = get_time();
    printf("Avg. time per sample (ICDF) FP16: %.7f ns\n", (1e9 * (t1_ICDF - t0_ICDF))/nSamples);    
    
                  
                  

    printf("\n\n");

    // Cleanup
    vslDeleteStream(&stream);
    mkl_free(output_f32_BM);
    mkl_free(output_f32_BM2);
    mkl_free(output_f32_ICDF);
    mkl_free(output_fp16_BM);
    mkl_free(output_fp16_BM2);
    mkl_free(output_fp16_ICDF);

    return 0;
}

