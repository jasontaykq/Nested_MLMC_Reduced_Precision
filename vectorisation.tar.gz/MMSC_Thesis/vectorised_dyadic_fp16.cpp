//vectorised_dyadic_fp16.cpp
#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <ctime>
#include <algorithm>
#include <immintrin.h>
#include <mkl.h>
#include "dyadic_lut.h"  // DYADIC_LUT_A_FP16[13], DYADIC_LUT_B_FP16[13]


#define N_SAMPLES    10000000u

// Convert FP16 array to FP32 for stats output
void fp16_to_fp32(const _Float16* h, float* f, size_t n) {
    for (size_t i = 0; i < n; ++i)
        f[i] = static_cast<float>(h[i]);
}

// Welford's algorithm
void compute_stats(const float* x, size_t n, float& mean, float& var) {
    double m = 0.0, s = 0.0;
    for (size_t i = 0; i < n; ++i) {
        double delta = x[i] - m;
        m += delta / (i + 1);
        s += delta * (x[i] - m);
    }
    mean = static_cast<float>(m);
    var  = (n > 1) ? static_cast<float>(s / (n - 1)) : 0.0f;
}


// High-resolution timer
double get_time() {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + ts.tv_nsec * 1e-9;
}


// Vectorised dyadic FP16 using permute in-register lookups
void dyadic_poly_fp16_avx512_permute(unsigned int n, const _Float16* __restrict in, _Float16* __restrict out) {
    const unsigned int VECTOR_LENGTH = 32u;
    const unsigned int n_iters = n / VECTOR_LENGTH;

    // Load LUT registers (expanded to 32 lanes)
    alignas(64) _Float16 LUT_A32[32] = {0}, LUT_B32[32] = {0};
    for (int i = 0; i < 13; ++i) {
        LUT_A32[i] = DYADIC_LUT_A_FP16[i];
        LUT_B32[i] = DYADIC_LUT_B_FP16[i];
    }

    __m512h Areg = _mm512_load_ph(LUT_A32);
    __m512h Breg = _mm512_load_ph(LUT_B32);

    const __m512 vhalf   = _mm512_set1_ps(0.5f);
    const __m512 veps_lo = _mm512_set1_ps(1e-7f);
    const __m512 veps_hi = _mm512_set1_ps(1.0f - 1e-7f);
    const __m512i vbias  = _mm512_set1_epi32(127);
    const __m512i voffs  = _mm512_set1_epi32((int)sizeof(DYADIC_U)/sizeof(float));
    const __m512 v_one   = _mm512_set1_ps(1.0f);
    const __m512 v_sign  = _mm512_set1_ps(-0.0f);

    for (unsigned int i = 0, off = 0; i < n_iters; ++i, off += VECTOR_LENGTH) {
        // Load 32 FP16 elements directly
        __m512h h32 = _mm512_loadu_ph(in + off);

        // Split to two FP32 vectors
        __m256h h_lo = _mm512_castph512_ph256(h32);
        __m256h h_hi = _mm256_castsi256_ph(_mm512_extracti64x4_epi64(_mm512_castph_si512(h32), 1));

        __m512 u_lo = _mm512_cvtph_ps(h_lo);
        __m512 u_hi = _mm512_cvtph_ps(h_hi);

        // Fold
        __mmask16 gt_lo = _mm512_cmp_ps_mask(u_lo, vhalf, _CMP_GT_OS);
        __mmask16 gt_hi = _mm512_cmp_ps_mask(u_hi, vhalf, _CMP_GT_OS);
        u_lo = _mm512_mask_sub_ps(u_lo, gt_lo, v_one, u_lo);
        u_hi = _mm512_mask_sub_ps(u_hi, gt_hi, v_one, u_hi);

        // Clamp
        u_lo = _mm512_max_ps(_mm512_min_ps(u_lo, veps_hi), veps_lo);
        u_hi = _mm512_max_ps(_mm512_min_ps(u_hi, veps_hi), veps_lo);

        // Index calculation
        auto idx_calc = [&](const __m512& u) {
            __m512i exponent_bits = _mm512_srli_epi32(_mm512_castps_si512(u), 23);
            __m512i j = _mm512_sub_epi32(vbias, exponent_bits);
            __m512i idx = _mm512_sub_epi32(voffs, j);
            // Clamp explicitly within correct LUT bounds [0,12]
            idx = _mm512_max_epi32(idx, _mm512_setzero_epi32());
            idx = _mm512_min_epi32(idx, _mm512_set1_epi32(12));
            return idx;
        };

        __m512i idx_lo = idx_calc(u_lo);
        __m512i idx_hi = idx_calc(u_hi);

        // Narrow indices explicitly for lower and upper half
        __m256i idx_lo16 = _mm512_cvtepi32_epi16(idx_lo);
        __m256i idx_hi16 = _mm512_cvtepi32_epi16(idx_hi);

        __m256i A_lo256 = _mm256_castph_si256(_mm512_castph512_ph256(Areg));
        __m256i B_lo256 = _mm256_castph_si256(_mm512_castph512_ph256(Breg));
        __m256i A_hi256 = _mm256_castph_si256(_mm256_castsi256_ph(
                            _mm512_extracti64x4_epi64(_mm512_castph_si512(Areg), 1)));
        __m256i B_hi256 = _mm256_castph_si256(_mm256_castsi256_ph(
                            _mm512_extracti64x4_epi64(_mm512_castph_si512(Breg), 1)));

        __m256h a_lo16 = _mm256_castsi256_ph(_mm256_permutexvar_epi16(idx_lo16, A_lo256));
        __m256h b_lo16 = _mm256_castsi256_ph(_mm256_permutexvar_epi16(idx_lo16, B_lo256));
        __m256h a_hi16 = _mm256_castsi256_ph(_mm256_permutexvar_epi16(idx_hi16, A_lo256));  // <-- Corrected to use lower LUT explicitly
        __m256h b_hi16 = _mm256_castsi256_ph(_mm256_permutexvar_epi16(idx_hi16, B_lo256));

        // Convert to FP32 and perform FMA
        __m512 a_lo = _mm512_cvtph_ps(a_lo16);
        __m512 a_hi = _mm512_cvtph_ps(a_hi16);
        __m512 b_lo = _mm512_cvtph_ps(b_lo16);
        __m512 b_hi = _mm512_cvtph_ps(b_hi16);

        __m512 z_lo = _mm512_fmadd_ps(b_lo, u_lo, a_lo);
        __m512 z_hi = _mm512_fmadd_ps(b_hi, u_hi, a_hi);

        // Sign adjustment
        z_lo = _mm512_mask_xor_ps(z_lo, gt_lo, v_sign, z_lo);
        z_hi = _mm512_mask_xor_ps(z_hi, gt_hi, v_sign, z_hi);

        // Convert back to FP16 and store
        __m256h out_lo = _mm512_cvtps_ph(z_lo, _MM_FROUND_TO_NEAREST_INT | _MM_FROUND_NO_EXC);
        __m256h out_hi = _mm512_cvtps_ph(z_hi, _MM_FROUND_TO_NEAREST_INT | _MM_FROUND_NO_EXC);

        _mm256_storeu_ph(out + off, out_lo);
        _mm256_storeu_ph(out + off + 16, out_hi);
    }


    // scalar tail
    for (unsigned int i = n_iters * VECTOR_LENGTH; i < n; ++i) {
        float uf = std::clamp(static_cast<float>(in[i]), 1e-7f, 1.0f - 1e-7f);
        bool gt = uf > 0.5f;
        if (gt) uf = 1.0f - uf;
        uint32_t e = (reinterpret_cast<uint32_t&>(uf) >> 23) & 0xFF;
        int j      = 127 - static_cast<int>(e);
        int idx    = std::clamp((int)(sizeof(DYADIC_U)/sizeof(float)) - j, 0, 12);
        float z    = DYADIC_LUT_A_FP32[idx] + DYADIC_LUT_B_FP32[idx] * uf;
        if (gt) z = -z;
        out[i] = static_cast<_Float16>(z);
    }
}

int main() {
    // allocate
    _Float16 *in_h  = (_Float16*)mkl_malloc(N_SAMPLES * sizeof(_Float16), 64);
    _Float16 *out_h = (_Float16*)mkl_malloc(N_SAMPLES * sizeof(_Float16), 64);
    float     *in_f = (float*)  mkl_malloc(N_SAMPLES * sizeof(float),    64);
    float     *output_mkl       = static_cast<float*>(mkl_malloc(N_SAMPLES * sizeof(float),    64));
    _Float16  *output_mkl_fp16  = static_cast<_Float16*>(mkl_malloc(N_SAMPLES * sizeof(_Float16), 64));
    
    float* out_mkl_fp32   = (float*)mkl_malloc(N_SAMPLES * sizeof(float), 64);
    float* approx_fp32    = (float*)mkl_malloc(N_SAMPLES * sizeof(float), 64);

    VSLStreamStatePtr st;
    vslNewStream(&st, VSL_BRNG_MT19937, 1234);
    vsRngUniform(VSL_RNG_METHOD_UNIFORM_STD, st, N_SAMPLES, in_f, 0.0f, 1.0f);
    for (unsigned i = 0; i < N_SAMPLES; ++i) in_h[i] = (_Float16)in_f[i];


    // Benchmark MKL Gaussian RNG (cast to fp16)
    double t0 = get_time();
    vsRngGaussian(VSL_RNG_METHOD_GAUSSIAN_BOXMULLER,
                  st,
                  N_SAMPLES,
                  output_mkl,
                  0.0f,
                  1.0f);
    for (unsigned int i = 0; i < N_SAMPLES; ++i) {
        output_mkl_fp16[i] = static_cast<_Float16>(output_mkl[i]);
    }
    double t1 = get_time();
    printf("MKL vsRngGaussian (FP16): %.3f ms for %u samples\n",
           1e3 * (t1 - t0), N_SAMPLES);


    // benchmark dyadic
    t0 = get_time();
    dyadic_poly_fp16_avx512_permute(N_SAMPLES, in_h, out_h);
    t1 = get_time();
    printf("Vectorised Dyadic (FP16): %.3f ms for %u samples\n",
           (t1 - t0) * 1e3, N_SAMPLES);



    const int N_REPEATS=4;
    double total_time_lut=0.0;

    // Steady-state runs
    for (int pass = 0; pass < N_REPEATS; ++pass) {
    // Benchmark MKL Gaussian RNG (cast to fp16)
    t0 = get_time();
    vsRngGaussian(VSL_RNG_METHOD_GAUSSIAN_BOXMULLER,
                  st,
                  N_SAMPLES,
                  output_mkl,
                  0.0f,
                  1.0f);
    for (unsigned int i = 0; i < N_SAMPLES; ++i) {
        output_mkl_fp16[i] = static_cast<_Float16>(output_mkl[i]);
    }
    t1 = get_time();
    printf("MKL vsRngGaussian (FP16): %.3f ms for %u samples\n",
           1e3 * (t1 - t0), N_SAMPLES);


    // benchmark dyadic
    t0 = get_time();
    dyadic_poly_fp16_avx512_permute(N_SAMPLES, in_h, out_h);
    t1 = get_time();
    double lut_time = 1e3 *(t1-t0); 
    printf("Vectorised Dyadic (FP16): %.3f ms for %u samples\n",
           (t1 - t0) * 1e3, N_SAMPLES);
    total_time_lut += lut_time;
    }


    printf("\n\n");
    printf("Vectorised Dyadic - Average Run Time (FP16):     %.3f ms per run\n", total_time_lut / N_REPEATS);


    fp16_to_fp32(output_mkl_fp16, out_mkl_fp32, N_SAMPLES);
    // Convert LUT FP16 → FP32
    fp16_to_fp32(out_h, approx_fp32, N_SAMPLES);

    float mkl_mean, mkl_var;
    float approx_mean, approx_var;

    compute_stats(out_mkl_fp32, N_SAMPLES, mkl_mean, mkl_var);
    compute_stats(approx_fp32, N_SAMPLES, approx_mean, approx_var);

    printf("\nMKL Gaussian (Reference):\n");
    printf("  Mean    = %+.6f\n", mkl_mean);
    printf("  Variance=  %.6f\n", mkl_var);

    printf("\nPiecewise Polynomial Approximation:\n");
    printf("  Mean    = %+.6f\n", approx_mean);
    printf("  Variance=  %.6f\n", approx_var);


    // Print first 10 LUT outputs
    printf("\nFirst 10 LUT approximations (fp16):\n");
    for (int i = 0; i < 10; ++i) {
        float u     = static_cast<float>(in_h[i]);
        float z_lut = static_cast<float>(out_h[i]);
        printf("  %2d) u = %.6f,   z_lut = %.6f\n",
               i+1, u, z_lut);
    }
    printf("\n");
    
    
    

    // cleanup
    vslDeleteStream(&st);
    mkl_free(in_h);
    mkl_free(out_h);
    mkl_free(in_f);
    mkl_free(out_mkl_fp32);
    mkl_free(approx_fp32);
    return 0;
}










