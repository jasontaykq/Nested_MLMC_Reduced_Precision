// non_vectorised_constant.cpp
#define _POSIX_C_SOURCE 199309L

#include <iostream>
#include <cstdint>
#include <cstdlib>
#include <ctime>
#include <iomanip>
#include <algorithm>
#include <cstdio>

#include "mkl.h"
#include "constant_lut_512.h"   // expects GAUSS_LUT (FP32) and GAUSS_LUT_FP16 (FP16)

// High-resolution timer
static double get_time() {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + ts.tv_nsec * 1e-9;
}

// ===================== Scalar LUT lookups (O(1) per sample) =====================

// FP32 scalar constant-uniform lookup (two-sided via mirror & sign)
void constant_lookup_fp32(const float* u_vals, int n, float* out) {
    constexpr int N = sizeof(GAUSS_LUT) / sizeof(GAUSS_LUT[0]);
    const float eps = 1e-7f;

    for (int i = 0; i < n; ++i) {
        float u = u_vals[i];
        // Clamp to avoid exact 0 or 1
        if (u < eps)            u = eps;
        if (u > 1.0f - eps)     u = 1.0f - eps;

        int   idx;
        float z;
        if (u < 0.5f) {
            // Lower half [0, 0.5): direct index
            idx = static_cast<int>(u * 2.0f * N);
            if (idx >= N) idx = N - 1;
            z = GAUSS_LUT[idx];
        } else {
            // Upper half (0.5, 1]: mirror & negate
            idx = static_cast<int>((1.0f - u) * 2.0f * N);
            if (idx >= N) idx = N - 1;
            z = -GAUSS_LUT[idx];
        }
        out[i] = z;
    }
}

// FP16 scalar constant-uniform lookup (index from FP32 u, LUT is FP16)
void constant_lookup_fp16(const float* u_vals, int n, _Float16* out) {
    constexpr int N16 = sizeof(GAUSS_LUT_FP16) / sizeof(GAUSS_LUT_FP16[0]);
    const float eps = 1e-7f;

    for (int i = 0; i < n; ++i) {
        float u = u_vals[i];
        if (u < eps)            u = eps;
        if (u > 1.0f - eps)     u = 1.0f - eps;

        int idx;
        _Float16 z16;
        if (u < 0.5f) {
            idx = static_cast<int>(u * 2.0f * N16);
            if (idx >= N16) idx = N16 - 1;
            // GAUSS_LUT_FP16 is assumed __fp16 in the header; cast to _Float16 for output buffer
            z16 = (_Float16)GAUSS_LUT_FP16[idx];
        } else {
            idx = static_cast<int>((1.0f - u) * 2.0f * N16);
            if (idx >= N16) idx = N16 - 1;
            z16 = (_Float16)(-GAUSS_LUT_FP16[idx]);
        }
        out[i] = z16;
    }
}

// =============================== Benchmark harness ===============================
int main() {
    const int nSamples   = 10'000'000;       // 10 million
    const int N_REPEATS  = 4;

    // Host buffers
    float    *u_vals     = static_cast<float*>(std::malloc(nSamples * sizeof(float)));
    float    *out_fp32   = static_cast<float*>(std::malloc(nSamples * sizeof(float)));
    _Float16 *out_fp16   = static_cast<_Float16*>(std::malloc(nSamples * sizeof(_Float16)));
    float    *out_mkl    = static_cast<float*>(mkl_malloc(nSamples * sizeof(float), 64));

    if (!u_vals || !out_fp32 || !out_fp16 || !out_mkl) {
        std::fprintf(stderr, "Allocation failed.\n");
        return 1;
    }

    // MKL RNG
    VSLStreamStatePtr stream;
    if (vslNewStream(&stream, VSL_BRNG_MT19937, 1234) != VSL_STATUS_OK) {
        std::fprintf(stderr, "Failed to create MKL RNG stream.\n");
        return 1;
    }

    // --- Baseline: Intel MKL Gaussian (FP32) ---
    double t0 = get_time();
    vsRngGaussian(VSL_RNG_METHOD_GAUSSIAN_BOXMULLER, stream,
                  nSamples, out_mkl, 0.0f, 1.0f);
    double t1 = get_time();
    std::cout << "Intel MKL vsRngGaussian (FP32): "
              << std::fixed << std::setprecision(3)
              << (1e3 * (t1 - t0)) << " ms for "
              << nSamples << " samples\n";

    // --- Prepare uniforms once (use MKL for speed and reproducibility) ---
    vsRngUniform(VSL_RNG_METHOD_UNIFORM_STD, stream, nSamples, u_vals, 0.0f, 1.0f);

    // --- Non-vectorised Constant LUT (FP32) ---
    t0 = get_time();
    constant_lookup_fp32(u_vals, nSamples, out_fp32);
    t1 = get_time();
    std::cout << "Non-Vectorised Constant (FP32): "
              << std::fixed << std::setprecision(3)
              << (1e3 * (t1 - t0)) << " ms for "
              << nSamples << " samples\n";

    // --- Non-vectorised Constant LUT (FP16) ---
    double t0_fp16 = get_time();
    constant_lookup_fp16(u_vals, nSamples, out_fp16);
    double t1_fp16 = get_time();
    std::cout << "Non-Vectorised Constant (FP16): "
              << std::fixed << std::setprecision(3)
              << (1e3 * (t1_fp16 - t0_fp16)) << " ms for "
              << nSamples << " samples\n";

    // --- Repeats to average timings ---
    double total_time_fp32 = 0.0;
    double total_time_fp16 = 0.0;

    for (int run = 0; run < N_REPEATS; ++run) {
        // Refresh uniforms (keeps same distribution; change seed if you want varied draws)
        vsRngUniform(VSL_RNG_METHOD_UNIFORM_STD, stream, nSamples, u_vals, 0.0f, 1.0f);

        // FP32 lookup
        double a0 = get_time();
        constant_lookup_fp32(u_vals, nSamples, out_fp32);
        double a1 = get_time();
        double dt32 = 1e3 * (a1 - a0);
        std::cout << "Non-Vectorised Constant (FP32): "
                  << std::fixed << std::setprecision(3)
                  << dt32 << " ms for "
                  << nSamples << " samples\n";
        total_time_fp32 += dt32;

        // FP16 lookup
        double b0 = get_time();
        constant_lookup_fp16(u_vals, nSamples, out_fp16);
        double b1 = get_time();
        double dt16 = 1e3 * (b1 - b0);
        std::cout << "Non-Vectorised Constant (FP16): "
                  << std::fixed << std::setprecision(3)
                  << dt16 << " ms for "
                  << nSamples << " samples\n";
        total_time_fp16 += dt16;
    }

    std::printf("\n\n");
    std::printf("Non-vectorised Constant - Average Run Time (FP32): %.3f ms per run\n",
                total_time_fp32 / N_REPEATS);
    std::printf("Non-vectorised Constant - Average Run Time (FP16): %.3f ms per run\n",
                total_time_fp16 / N_REPEATS);
    std::printf("\n");

    // --- Show a few sample outputs (from the latest run) ---
    std::cout << "Index |     u      |  z_fp32    |  z_fp16\n";
    for (int i = 0; i < 10; ++i) {
        std::cout << std::setw(5) << (i+1)
                  << std::setw(12) << std::fixed << std::setprecision(6) << u_vals[i]
                  << std::setw(12) << std::fixed << std::setprecision(6) << out_fp32[i]
                  << std::setw(12) << (double)out_fp16[i]   // cast to double for readable print
                  << "\n";
    }
    std::cout << "\n";

    // Cleanup
    vslDeleteStream(&stream);
    std::free(u_vals);
    std::free(out_fp32);
    std::free(out_fp16);
    mkl_free(out_mkl);
    return 0;
}

