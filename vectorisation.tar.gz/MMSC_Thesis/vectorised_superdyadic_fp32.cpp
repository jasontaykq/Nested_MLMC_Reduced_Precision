// vectorised_superdyadic_fp32.cpp

#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <ctime>
#include <immintrin.h>
#include <mkl.h>
#include <algorithm>
#include "superdyadic_lut_52.h"

#define VECTOR_LENGTH_32   16u
#define N_SAMPLES       10000000u

// derive counts from your LUT:
constexpr int NUM_BREAKS = sizeof(SUPERDYADIC_U) / sizeof(float);
constexpr int NUM_BINS   = NUM_BREAKS - 1;

// aligned coefficient buffers for gathers
alignas(64) float lutA[NUM_BINS];
alignas(64) float lutB[NUM_BINS];

// copy from the header arrays into our aligned buffers
void prepare_superdyadic_coefs() {
    for (int i = 0; i < NUM_BINS; ++i) {
        lutA[i] = SUPERDYADIC_LUT_A_FP32[i];
        lutB[i] = SUPERDYADIC_LUT_B_FP32[i];
    }
}

void piecewise_superdyadic_approx(const unsigned int n_samples,
                                 const float *input,
                                 int *segs,
                                 float *output)
{
    const unsigned int n_iters = n_samples / VECTOR_LENGTH_32;

    // constants
    const __m512  one_f     = _mm512_set1_ps(1.0f);
    const __m512  half      = _mm512_set1_ps(0.5f);
    const __m512  minus0    = _mm512_set1_ps(-0.0f);
    const __m512  eps       = _mm512_set1_ps(1e-7f);
    const __m512  one_eps   = _mm512_set1_ps(1.0f - 1e-7f);

    const __m512i zero_i    = _mm512_setzero_epi32();
    const __m512i one_i     = _mm512_set1_epi32(1);
    const __m512i tbl_max   = _mm512_set1_epi32(NUM_BINS - 1);

    // Load LUTs into registers (27 entries = 16 + 11)
    const __m512 lutA_0 = _mm512_load_ps(lutA);      // First 16 entries
    const __m512 lutA_1 = _mm512_load_ps(lutA + 16); // Next 11 entries (padding not needed)
    const __m512 lutB_0 = _mm512_load_ps(lutB);
    const __m512 lutB_1 = _mm512_load_ps(lutB + 16);

    for (unsigned int it = 0, off = 0; it < n_iters; ++it, off += VECTOR_LENGTH_32) {
        // load 16 inputs
        __m512 u = _mm512_loadu_ps(input + off);

        // fold into [0,0.5]
        __mmask16 gt = _mm512_cmp_ps_mask(u, half, _CMP_GT_OS);
        __m512 u0 = _mm512_mask_sub_ps(u, gt, one_f, u);

        // clamp like the scalar
        u0 = _mm512_max_ps(u0, eps);
        u0 = _mm512_min_ps(u0, one_eps);

        // build bin‐index by counting how many breakpoints < u0
        __m512i idx = zero_i;
        for (int b = 0; b < NUM_BREAKS; ++b) {
            __m512 bp = _mm512_set1_ps(SUPERDYADIC_U[b]);
            __mmask16 m = _mm512_cmp_ps_mask(u0, bp, _CMP_GT_OS);
            idx = _mm512_mask_add_epi32(idx, m, idx, one_i);
        }
        // clamp to valid bin range [0, NUM_BINS-1]
        idx = _mm512_min_epi32(idx, tbl_max);

        // Determine which entries come from which LUT part
        __mmask16 use_high = _mm512_cmpge_epi32_mask(idx, _mm512_set1_epi32(16));
        __m512i idx_adjusted = _mm512_mask_sub_epi32(idx, use_high, idx, _mm512_set1_epi32(16));

        // Fetch coefficients using permute
        __m512 c0_0 = _mm512_permutexvar_ps(idx, lutA_0);
        __m512 c0_1 = _mm512_permutexvar_ps(idx_adjusted, lutA_1);
        __m512 c0 = _mm512_mask_blend_ps(use_high, c0_0, c0_1);

        __m512 c1_0 = _mm512_permutexvar_ps(idx, lutB_0);
        __m512 c1_1 = _mm512_permutexvar_ps(idx_adjusted, lutB_1);
        __m512 c1 = _mm512_mask_blend_ps(use_high, c1_0, c1_1);

        // z = A + B * u0
        __m512 z = _mm512_fmadd_ps(c1, u0, c0);

        // restore sign
        z = _mm512_mask_xor_ps(z, gt, minus0, z);

        // store results
        _mm512_storeu_ps(output + off, z);
        // segments = idx+1
        __m512i segs_i = _mm512_add_epi32(idx, one_i);
        _mm512_storeu_si512(reinterpret_cast<void*>(segs + off), segs_i);
    }

    // Scalar Tail
    for (unsigned int i = n_iters * VECTOR_LENGTH_32; i < n_samples; ++i) {
        float u = input[i];
        bool gt = (u > 0.5f);
        float u0 = gt ? (1.0f - u) : u;
        u0 = std::clamp(u0, 1e-7f, 1.0f - 1e-7f);

        int idx = 0;
        for (int b = 0; b < NUM_BREAKS; ++b) {
            if (u0 > SUPERDYADIC_U[b]) idx++;
        }
        idx = std::min(idx, NUM_BINS - 1);

        float z = lutA[idx] + lutB[idx] * u0;
        if (gt) z = -z;

        output[i] = z;
        segs[i] = idx + 1;
    }
}

static double get_time() {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + ts.tv_nsec * 1e-9;
}


//Welford's Algorithm
void compute_mean_variance(const float* data, size_t n, float& mean, float& variance) {
    if (n == 0) {
        mean = 0.0f;
        variance = 0.0f;
        return;
    }

    double m = 0.0;
    double s = 0.0;
    for (size_t i = 0; i < n; ++i) {
        double x = data[i];
        double delta = x - m;
        m += delta / (i + 1);
        s += delta * (x - m);
    }

    mean = static_cast<float>(m);
    variance = (n > 1) ? static_cast<float>(s / (n - 1)) : 0.0f;
}


int main() {
    const int nSamples = N_SAMPLES;

    // allocate aligned buffers
    float *out_mkl     = static_cast<float*>(mkl_malloc(nSamples * sizeof(float), 64));
    float *out_super   = static_cast<float*>(mkl_malloc(nSamples * sizeof(float), 64));
    int   *segs        = static_cast<int*>(  mkl_malloc(nSamples * sizeof(int),   64));
    float *u_vals      = static_cast<float*>(mkl_malloc(nSamples * sizeof(float), 64));

    float mkl_mean, mkl_var;
    float approx_mean, approx_var;

    // init MKL RNG
    VSLStreamStatePtr stream;
    vslNewStream(&stream, VSL_BRNG_MT19937, 1234);

    // benchmark MKL Gaussian
    double t0 = get_time();
    vsRngGaussian(VSL_RNG_METHOD_GAUSSIAN_BOXMULLER,
                  stream, nSamples, out_mkl, 0.0f, 1.0f);
    double t1 = get_time();
    printf("MKL vsRngGaussian (FP32): %.3f ms for %d samples\n",
           1e3*(t1-t0), nSamples);

    // fill uniforms
    std::srand(1234);
    for (int i = 0; i < nSamples; ++i) {
        float u = std::rand() / (RAND_MAX + 1.0f);
        u_vals[i] = std::clamp(u, 1e-7f, 1.0f - 1e-7f);
    }

    // prep LUT
    prepare_superdyadic_coefs();

    // benchmark vectorised superdyadic
    t0 = get_time();
    piecewise_superdyadic_approx(nSamples, u_vals, segs, out_super);
    t1 = get_time();
    printf("Vectorised Superdyadic (FP32): %.3f ms for %d samples\n",
           1e3*(t1-t0), nSamples);



    const int N_REPEATS=4;
    double total_time_lut=0.0;

    // amortize startup
    for (int run = 0; run < N_REPEATS ; ++run) {
        t0 = get_time();
        vsRngGaussian(VSL_RNG_METHOD_GAUSSIAN_BOXMULLER,
                      stream, nSamples, out_mkl, 0.0f, 1.0f);
        t1 = get_time();
        printf("MKL vsRngGaussian (FP32): %.3f ms for %d samples\n",
               1e3*(t1-t0), nSamples);

        t0 = get_time();
        piecewise_superdyadic_approx(nSamples, u_vals, segs, out_super);
        t1 = get_time();
        double lut_time = 1e3 *(t1-t0); 
        printf("Vectorised Superdyadic (FP32): %.3f ms for %d samples\n",
               1e3*(t1-t0), nSamples);
        total_time_lut += lut_time;
    }
    
    
    printf("\n\n");
    printf("Vectorised Superdyadic - Average Run Time (FP32):     %.3f ms per run\n", total_time_lut / N_REPEATS);
    
    compute_mean_variance(out_mkl, N_SAMPLES, mkl_mean, mkl_var);
    compute_mean_variance(out_super, N_SAMPLES, approx_mean, approx_var);

    printf("\nMKL Gaussian (Reference):\n");
    printf("  Mean    = %+.6f\n", mkl_mean);
    printf("  Variance=  %.6f\n", mkl_var);

    printf("\nPiecewise Polynomial Approximation:\n");
    printf("  Mean    = %+.6f\n", approx_mean);
    printf("  Variance=  %.6f\n", approx_var);


    // print first 10 for sanity
    printf("\nFirst 10 results:\n idx |      u      | seg |   approx\n");
    for (int i = 0; i < 10; ++i) {
        printf("%4d | %10.6f | %3d | %10.6f\n",
               i+1, u_vals[i], segs[i], out_super[i]);
    }

    // cleanup
    vslDeleteStream(&stream);
    mkl_free(out_mkl);
    mkl_free(out_super);
    mkl_free(u_vals);
    mkl_free(segs);

    return 0;
}





