// vectorised_constant_fp16.cpp

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <immintrin.h>
#include <mkl.h>
#include "constant_lut_512.h"

#define N_SAMPLES     10000000u
#define VECTOR_LENGTH 32u
#define N_LUT         512u


// Convert FP16 array to FP32 for stats output
void fp16_to_fp32(const _Float16* h, float* f, size_t n) {
    for (size_t i = 0; i < n; ++i)
        f[i] = static_cast<float>(h[i]);
}

// Welford's algorithm
void compute_stats(const float* x, size_t n, float& mean, float& var) {
    double m = 0.0, s = 0.0;
    for (size_t i = 0; i < n; ++i) {
        double delta = x[i] - m;
        m += delta / (i + 1);
        s += delta * (x[i] - m);
    }
    mean = static_cast<float>(m);
    var  = (n > 1) ? static_cast<float>(s / (n - 1)) : 0.0f;
}

// High-resolution timer
double get_time() {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + ts.tv_nsec * 1e-9;
}

// Vectorised AVX-512 FP16 LUT via FP32 gather + pack
void lut_piecewise_constant_fp16_avx512(unsigned int n_samples,
                                        const _Float16 *input,
                                        _Float16       *output) {
    const unsigned int n_iters = n_samples / 32;  // Now processes 32 elements per iteration

    // Constants for index math (same as before)
    const float   scale_f32 = static_cast<float>(N_LUT) / 0.5f;
    const __m512  vscale    = _mm512_set1_ps(scale_f32);
    const __m512  vhalf     = _mm512_set1_ps(0.5f);
    const __m512  vone      = _mm512_set1_ps(1.0f);
    const __m512i vmax_idx  = _mm512_set1_epi32(N_LUT - 1);

    // FP32 clamps
    const __m512  veps_lo  = _mm512_set1_ps(1e-7f);
    const __m512  veps_hi  = _mm512_set1_ps(1.0f - 1e-7f);

    for (unsigned int it = 0; it < n_iters; ++it) {
        const _Float16 *in_ptr  = input  + it * 32;
        _Float16       *out_ptr = output + it * 32;

        // Load 32 FP16 elements (two AVX-512 FP16 vectors)
        __m256h u16_lo = _mm256_loadu_ph(in_ptr);
        __m256h u16_hi = _mm256_loadu_ph(in_ptr + 16);

        // Convert to FP32 (now two AVX-512 vectors)
        __m512 u_lo = _mm512_cvtph_ps(u16_lo);
        __m512 u_hi = _mm512_cvtph_ps(u16_hi);

        // Clamp both vectors to [eps_lo, eps_hi]
        u_lo = _mm512_max_ps(u_lo, veps_lo);
        u_hi = _mm512_max_ps(u_hi, veps_lo);
        u_lo = _mm512_min_ps(u_lo, veps_hi);
        u_hi = _mm512_min_ps(u_hi, veps_hi);

        // Compute masks for lower half-region (u < 0.5)
        __mmask16 m_lo_lo = _mm512_cmp_ps_mask(u_lo, vhalf, _CMP_LT_OS);
        __mmask16 m_lo_hi = _mm512_cmp_ps_mask(u_hi, vhalf, _CMP_LT_OS);

        // Select u or (1-u) based on mask
        __m512 u_sel_lo = _mm512_mask_blend_ps(m_lo_lo, _mm512_sub_ps(vone, u_lo), u_lo);
        __m512 u_sel_hi = _mm512_mask_blend_ps(m_lo_hi, _mm512_sub_ps(vone, u_hi), u_hi);

        // Compute LUT indices (scale and convert to int)
        __m512i idx_lo = _mm512_cvttps_epi32(_mm512_mul_ps(u_sel_lo, vscale));
        __m512i idx_hi = _mm512_cvttps_epi32(_mm512_mul_ps(u_sel_hi, vscale));
        idx_lo = _mm512_min_epi32(idx_lo, vmax_idx);
        idx_hi = _mm512_min_epi32(idx_hi, vmax_idx);

        // Gather LUT values (two independent gathers)
        __m512 z_f_lo = _mm512_i32gather_ps(idx_lo, GAUSS_LUT, sizeof(float));
        __m512 z_f_hi = _mm512_i32gather_ps(idx_hi, GAUSS_LUT, sizeof(float));

        // Apply sign based on region
        __m512 z_signed_lo = _mm512_mask_blend_ps(m_lo_lo, _mm512_sub_ps(_mm512_setzero_ps(), z_f_lo), z_f_lo);
        __m512 z_signed_hi = _mm512_mask_blend_ps(m_lo_hi, _mm512_sub_ps(_mm512_setzero_ps(), z_f_hi), z_f_hi);

        // Convert back to FP16 and store
        __m256h z_h_lo = _mm512_cvtps_ph(z_signed_lo, _MM_FROUND_TO_NEAREST_INT | _MM_FROUND_NO_EXC);
        __m256h z_h_hi = _mm512_cvtps_ph(z_signed_hi, _MM_FROUND_TO_NEAREST_INT | _MM_FROUND_NO_EXC);
        _mm256_storeu_ph(out_ptr, z_h_lo);
        _mm256_storeu_ph(out_ptr + 16, z_h_hi);
    }

    // Scalar tail (process remaining 0-31 elements)
    unsigned int tail_start = n_iters * 32;
    for (unsigned int i = tail_start; i < n_samples; ++i) {
        float u = static_cast<float>(input[i]);
        if (u < 1e-7f) u = 1e-7f;
        if (u > 1.0f - 1e-7f) u = 1.0f - 1e-7f;

        int idx;
        float z;
        if (u < 0.5f) {
            idx = static_cast<int>(u * scale_f32);
            z   = GAUSS_LUT[idx];
        } else {
            idx = static_cast<int>((1.0f - u) * scale_f32);
            z   = -GAUSS_LUT[idx];
        }
        output[i] = static_cast<_Float16>(z);
    }
}

int main() {
    // Allocate aligned buffers
    float     *uniforms         = static_cast<float*>(mkl_malloc(N_SAMPLES * sizeof(float),    64));
    _Float16  *uniforms_fp16    = static_cast<_Float16*>(mkl_malloc(N_SAMPLES * sizeof(_Float16), 64));
    _Float16  *output_lut       = static_cast<_Float16*>(mkl_malloc(N_SAMPLES * sizeof(_Float16), 64));
    float     *output_mkl       = static_cast<float*>(mkl_malloc(N_SAMPLES * sizeof(float),    64));
    _Float16  *output_mkl_fp16  = static_cast<_Float16*>(mkl_malloc(N_SAMPLES * sizeof(_Float16), 64));


    float* out_mkl_fp32   = (float*)mkl_malloc(N_SAMPLES * sizeof(float), 64);
    float* approx_fp32    = (float*)mkl_malloc(N_SAMPLES * sizeof(float), 64);

    // Initialize MKL RNG
    VSLStreamStatePtr stream;
    vslNewStream(&stream, VSL_BRNG_MT19937, 1234);

    // Generate uniform floats [0,1)
    vsRngUniform(VSL_RNG_METHOD_UNIFORM_STD,
                 stream,
                 N_SAMPLES,
                 uniforms,
                 0.0f,
                 1.0f);

    // Convert to half-precision
    for (unsigned int i = 0; i < N_SAMPLES; ++i) {
        uniforms_fp16[i] = static_cast<_Float16>(uniforms[i]);
    }

    const int N_REPEATS=4;
    double total_time_lut=0.0;
    
    for (int pass = 0; pass < N_REPEATS; ++pass) {
        // Benchmark MKL Gaussian RNG (cast to fp16)
        double t0 = get_time();
        vsRngGaussian(VSL_RNG_METHOD_GAUSSIAN_BOXMULLER,
                      stream,
                      N_SAMPLES,
                      output_mkl,
                      0.0f,
                      1.0f);
        for (unsigned int i = 0; i < N_SAMPLES; ++i) {
            output_mkl_fp16[i] = static_cast<_Float16>(output_mkl[i]);
        }
        double t1 = get_time();
        printf("Intel MKL vsRngGaussian (FP16): %.3f ms for %u samples\n",
               1e3 * (t1 - t0), N_SAMPLES);

        // Benchmark LUT method
        t0 = get_time();
        lut_piecewise_constant_fp16_avx512(N_SAMPLES, uniforms_fp16, output_lut);
        t1 = get_time();
        double lut_time = 1e3 *(t1-t0); 
        printf("Vectorised Constant (FP16): %.3f ms for %u samples\n",
               1e3 * (t1 - t0), N_SAMPLES);
        total_time_lut += lut_time;
    }


    printf("\n\n");
    printf("Vectorised Constant - Average Run Time (FP16):     %.3f ms per run\n", total_time_lut / N_REPEATS);


    fp16_to_fp32(output_mkl_fp16, out_mkl_fp32, N_SAMPLES);
    // Convert LUT FP16 → FP32
    fp16_to_fp32(output_lut, approx_fp32, N_SAMPLES);

    float mkl_mean, mkl_var;
    float approx_mean, approx_var;

    compute_stats(out_mkl_fp32, N_SAMPLES, mkl_mean, mkl_var);
    compute_stats(approx_fp32, N_SAMPLES, approx_mean, approx_var);

    printf("\nMKL Gaussian (Reference):\n");
    printf("  Mean    = %+.6f\n", mkl_mean);
    printf("  Variance=  %.6f\n", mkl_var);

    printf("\nPiecewise Constant Approximation:\n");
    printf("  Mean    = %+.6f\n", approx_mean);
    printf("  Variance=  %.6f\n", approx_var);



    // Print first 10 LUT outputs
    printf("\nFirst 10 LUT approximations (fp16):\n");
    for (int i = 0; i < 10; ++i) {
        float u     = static_cast<float>(uniforms_fp16[i]);
        float z_lut = static_cast<float>(output_lut[i]);
        printf("  %2d) u = %.6f,   z_lut = %.6f\n",
               i+1, u, z_lut);
    }
    printf("\n");

    // Cleanup
    vslDeleteStream(&stream);
    mkl_free(uniforms);
    mkl_free(uniforms_fp16);
    mkl_free(output_lut);
    mkl_free(output_mkl);
    mkl_free(output_mkl_fp16);

    return 0;
}

