//vectorised_constant_fp16gather.cpp

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <immintrin.h>
#include <mkl.h>

#include "constant_lut_512.h" 
#include "avx512_lut_constant.h"
#include "fp16x32.h"          // provides fp16x32 and gather_fp16(const _Float16*, __m512i)

#define N_SAMPLES     10000000u
#define N_LUT         512u

// Convert FP16 array to FP32 for stats output
void fp16_to_fp32(const _Float16* h, float* f, size_t n) {
    for (size_t i = 0; i < n; ++i)
        f[i] = static_cast<float>(h[i]);
}

// Welford's algorithm
void compute_stats(const float* x, size_t n, float& mean, float& var) {
    double m = 0.0, s = 0.0;
    for (size_t i = 0; i < n; ++i) {
        double delta = x[i] - m;
        m += delta / (i + 1);
        s += delta * (x[i] - m);
    }
    mean = static_cast<float>(m);
    var  = (n > 1) ? static_cast<float>(s / (n - 1)) : 0.0f;
}

// High-resolution timer
double get_time() {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + ts.tv_nsec * 1e-9;
}


int main() {
    // Allocate aligned buffers
    float     *uniforms             = static_cast<float*>(mkl_malloc(N_SAMPLES * sizeof(float),    64));
    _Float16  *uniforms_fp16        = static_cast<_Float16*>(mkl_malloc(N_SAMPLES * sizeof(_Float16), 64));
    _Float16  *output_lut_fp16   = static_cast<_Float16*>(mkl_malloc(N_SAMPLES * sizeof(_Float16), 64));
    float     *output_mkl           = static_cast<float*>(mkl_malloc(N_SAMPLES * sizeof(float),    64));
    _Float16  *output_mkl_fp16      = static_cast<_Float16*>(mkl_malloc(N_SAMPLES * sizeof(_Float16), 64));

    float* out_mkl_fp32   = (float*)mkl_malloc(N_SAMPLES * sizeof(float), 64);
    float* approx_fp32    = (float*)mkl_malloc(N_SAMPLES * sizeof(float), 64);


    // Build duplicated FP16 LUT from float LUT
    uint32_t* GAUSS_LUT_FP16_DUP = static_cast<uint32_t*>(mkl_malloc(N_LUT * sizeof(uint32_t), 64));
    build_fp16_duplicated_lut(GAUSS_LUT_FP16_DUP, GAUSS_LUT, N_LUT);

    // Initialize MKL RNG
    VSLStreamStatePtr stream;
    vslNewStream(&stream, VSL_BRNG_MT19937, 1234);

    // Generate uniform floats [0,1)
    vsRngUniform(VSL_RNG_METHOD_UNIFORM_STD,
                 stream,
                 N_SAMPLES,
                 uniforms,
                 0.0f,
                 1.0f);

    // Vectorized conversion to half-precision (16 at a time)
    for (unsigned int i = 0; i < N_SAMPLES; i += 16) {
        __m512 f = _mm512_load_ps(uniforms + i);
        __m256h h = _mm512_cvtps_ph(f, _MM_FROUND_TO_NEAREST_INT | _MM_FROUND_NO_EXC);
        _mm256_storeu_ph(uniforms_fp16 + i, h);
    }

    // Warm-up runs (not timed) to mitigate cold-cache effects
    lut_piecewise_constant_fp16_avx512(N_SAMPLES, uniforms, output_lut_fp16, GAUSS_LUT_FP16_DUP);
    vsRngGaussian(VSL_RNG_METHOD_GAUSSIAN_BOXMULLER,
                  stream,
                  N_SAMPLES,
                  output_mkl,
                  0.0f,
                  1.0f);
    for (unsigned int i = 0; i < N_SAMPLES; ++i) {
        output_mkl_fp16[i] = static_cast<_Float16>(output_mkl[i]);
    }

    // Benchmark MKL Gaussian RNG (cast to fp16)
    double t0 = get_time();
    vsRngGaussian(VSL_RNG_METHOD_GAUSSIAN_BOXMULLER,
                  stream,
                  N_SAMPLES,
                  output_mkl,
                  0.0f,
                  1.0f);
    for (unsigned int i = 0; i < N_SAMPLES; ++i) {
        output_mkl_fp16[i] = static_cast<_Float16>(output_mkl[i]);
    }
    double t1 = get_time();
    printf("Intel MKL vsRngGaussian (FP16): %.3f ms for %u samples\n",
           1e3 * (t1 - t0), N_SAMPLES);

    // Benchmark FP16-LUT path
    t0 = get_time();
    lut_piecewise_constant_fp16_avx512(N_SAMPLES, uniforms, output_lut_fp16, GAUSS_LUT_FP16_DUP);
    t1 = get_time();
    printf("Vectorised FP16-LUT (gather_fp16): %.3f ms for %u samples\n",
           1e3 * (t1 - t0), N_SAMPLES);

    const int N_REPEATS=4;
    double total_time_lut=0.0;

    // Steady-state runs
    for (int pass = 0; pass < N_REPEATS; ++pass) {
        // MKL
        t0 = get_time();
        vsRngGaussian(VSL_RNG_METHOD_GAUSSIAN_BOXMULLER,
                      stream,
                      N_SAMPLES,
                      output_mkl,
                      0.0f,
                      1.0f);
        for (unsigned int i = 0; i < N_SAMPLES; ++i) {
            output_mkl_fp16[i] = static_cast<_Float16>(output_mkl[i]);
        }
        t1 = get_time();
        printf("Intel MKL vsRngGaussian (FP16): %.3f ms for %u samples\n",
               1e3 * (t1 - t0), N_SAMPLES);

        // FP16-LUT
        t0 = get_time();
        lut_piecewise_constant_fp16_avx512(N_SAMPLES, uniforms, output_lut_fp16, GAUSS_LUT_FP16_DUP);
        t1 = get_time();
        double lut_time = 1e3 *(t1-t0);
        printf("Vectorised Constant (gather_fp16): %.3f ms for %u samples\n",
               lut_time, N_SAMPLES);
        total_time_lut += lut_time;
    }

    printf("\n\n");
    printf("Vectorised Constant (gather_fp16) - Average Run Time (FP16): %.3f ms per run\n", total_time_lut / N_REPEATS);



    fp16_to_fp32(output_mkl_fp16, out_mkl_fp32, N_SAMPLES);
    // Convert LUT FP16 → FP32
    fp16_to_fp32(output_lut_fp16, approx_fp32, N_SAMPLES);

    float mkl_mean, mkl_var;
    float approx_mean, approx_var;

    compute_stats(out_mkl_fp32, N_SAMPLES, mkl_mean, mkl_var);
    compute_stats(approx_fp32, N_SAMPLES, approx_mean, approx_var);

    printf("\nMKL Gaussian (Reference):\n");
    printf("  Mean    = %+.6f\n", mkl_mean);
    printf("  Variance=  %.6f\n", mkl_var);

    printf("\nPiecewise Constant Approximation:\n");
    printf("  Mean    = %+.6f\n", approx_mean);
    printf("  Variance=  %.6f\n", approx_var);



    // Print first 10 LUT outputs (from the FP16-LUT path)
    printf("\nFirst 10 FP16-LUT approximations (fp16):\n");
    for (int i = 0; i < 10; ++i) {
        float u     = static_cast<float>(uniforms_fp16[i]);
        float z_lut = static_cast<float>(output_lut_fp16[i]);
        printf("  %2d) u = %.6f,   z_lut = %.6f\n",
               i+1, u, z_lut);
    }
    printf("\n");

    // Cleanup
    vslDeleteStream(&stream);
    mkl_free(uniforms);
    mkl_free(uniforms_fp16);
    mkl_free(output_lut_fp16);
    mkl_free(output_mkl);
    mkl_free(output_mkl_fp16);
    mkl_free(GAUSS_LUT_FP16_DUP);

    return 0;
}




