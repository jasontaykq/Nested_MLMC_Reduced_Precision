// conversion_test_constant.cpp

#include <iostream>
#include <cstdint>
#include <cstdlib>
#include <ctime>
#include <iomanip>

#include "constant_lut_512.h"

int main() {
    // N = half-range LUT size (for u in [0,0.5))
    const int N = sizeof(GAUSS_LUT) / sizeof(GAUSS_LUT[0]);

    std::cout << "Uniform grid test (FP32):\n";
    float u_test[101];
    for (int i = 0; i <= 100; ++i) {
        u_test[i] = i * 0.01f;
    }

    std::cout << "Sample | Uniform | LUT Index | LUT Gaussian Output\n";
    for (int i = 0; i <= 100; ++i) {
        float u = u_test[i];
        if (u < 1e-7f)        u = 1e-7f;
        if (u > 1.0f - 1e-7f) u = 1.0f - 1e-7f;

        int idx;
        float z;
        if (u < 0.5f) {
            idx = static_cast<int>(u * 2.0f * N);  // corrected indexing
            if (idx >= N) idx = N - 1;
            z = GAUSS_LUT[idx];
        } else {
            idx = static_cast<int>((1.0f - u) * 2.0f * N);  // reflect and scale
            if (idx >= N) idx = N - 1;
            z = -GAUSS_LUT[idx];
        }

        std::cout
            << std::setw(5) << i << " | "
            << std::fixed << std::setprecision(5) << u << " | "
            << std::setw(5) << (idx + 1) << " | "
            << std::fixed << std::setprecision(5) << z
            << "\n";
    }
    
    /*
    // ----------------------
    // FP16 Uniform Grid Test
    // ----------------------
    const int NFP16 = sizeof(GAUSS_LUT_FP16) / sizeof(GAUSS_LUT_FP16[0]);

    std::cout << "\nUniform grid test (FP16):\n";
    _Float16 u_test16[101];
    for (int i = 0; i <= 100; ++i) {
        u_test16[i] = static_cast<_Float16>(i * 0.01f);
    }

    std::cout << "Sample |    u    | LUT Index |   z (FP16)\n";
    for (int i = 0; i <= 100; ++i) {
        _Float16 u = u_test16[i];
        const _Float16 eps16 = static_cast<_Float16>(1e-7f);
        if (u < eps16)              u = eps16;
        if (u > static_cast<_Float16>(1.0f) - eps16)
            u = static_cast<_Float16>(1.0f) - eps16;

        int idx;
        _Float16 z16;
        if (u < static_cast<_Float16>(0.5f)) {
            idx = static_cast<int>(u * static_cast<_Float16>(2.0f) * NFP16);
            if (idx >= NFP16) idx = NFP16 - 1;
            z16 = GAUSS_LUT_FP16[idx];
        } else {
            idx = static_cast<int>((static_cast<_Float16>(1.0f) - u)
                                   * static_cast<_Float16>(2.0f) * NFP16);
            if (idx >= NFP16) idx = NFP16 - 1;
            z16 = -GAUSS_LUT_FP16[idx];
        }

        // Cast back to float for printing
        std::cout
            << std::setw(6) << i << " | "
            << std::fixed << std::setprecision(5) << static_cast<float>(u) << " | "
            << std::setw(9) << (idx + 1) << " | "
            << std::fixed << std::setprecision(5) << static_cast<float>(z16)
            << "\n";
    }
*/


    std::cout << "\n\n";
    return 0;
}

